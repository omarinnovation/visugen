# Utilisation

## Lancer le programme

Dans un terminal, changer de dossier pour aller dans `dev-be-chantier/VisuGenerator`. Puis exécuter la commande suivante :
`python mainallGUI.pyw`

## Fonctionnement

Se référer à la documentation sur le Wiki : [Documentation](https://hagergroup.sharepoint.com/sites/Eficia/SitePages/G%C3%A9n%C3%A9ration-de-visualisations-Harmony.aspx)
