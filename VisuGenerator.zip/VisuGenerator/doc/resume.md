# VisuGenerator : détections automatiques

Ce document a pour but de rassembler et décrire les différentes méthodes utilisées afin de détecter et ajouter automatiquement les objets nécessaires aux différentes pages de visualisation.

## Pilotages divers

### Type de pilotage

| **Catégorie**        | **Mots-clés ou Patterns**                                                                                     |
| -------------------- | ------------------------------------------------------------------------------------------------------------- |
| **CVC**              | `rac`, `chauffage`, `convecteur`, `clim`, `aerotherme`, `vmc`, `extracteur`, `destrat`, `chaufferie`, `pompe` |
| **Autres Pilotages** | `Nom ne contenant pas d'élément de la liste ci-dessus`                                                        |

<br>

### Pré-remplissage des emplacements

_Cette étape concerne uniquement pour les sites qui possèdent des pages d'implantation (tous sauf Carrefour, Fnac, Cultura, Darty et similaires)_

| **Emplacement**    | **Mots-clés ou Patterns**                                                                                 |
| ------------------ | --------------------------------------------------------------------------------------------------------- |
| **Jardin**         | `jardin`                                                                                                  |
| **Bâti**           | `bati`, `show`, `decoupe`                                                                                 |
| **Extérieur**      | `parking`, `exterieur`, `ext`, `facade`, `auvent`, `enseigne`                                             |
| **Réserve**        | `reserve`, `reception`, `meuniserie`, `srm`, `zrm`, `sav`                                                 |
| **Locaux sociaux** | `bureau`, `r+`, `rdc`, `loc soc`, `locaux sociaux`, `sanitaire`, `local`                                  |
| **SDV**            | `sdv`, `vente`, `sas`, `canalis`, `entree`, `caisse`, `sortie`, `magasin`, `agencement`, `power`, `track` |

_Les emplacements détectés durant cette étape sont de toute façon toujours modifiables manuellement par l'utilisateur avant de passer à l'étape suivante._

<br>

## Pages de chaufferies

### Températures

| **Critère**                             | **Description**                                        |
| --------------------------------------- | ------------------------------------------------------ |
| **Adresse KNX**                         | L'adresse doit commencer par `3/` ou `4/`.             |
| **Température de départ détectée si :** | Le nom contient "depart", "départ" ou "aller".         |
| **Température de retour détectée si :** | Le nom contient "retour", ainsi que "temp" ou "sonde". |

_Si plusieurs objets sont détectés, l'utilisateur est averti par un message dans la console et le programme choisira le premier élément trouvé._

### Pilotages

| **Critère**        | **Fragments ou Mot-Clé**                                           | **Description**                                                                                                                     |
| ------------------ | ------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------- |
| **Nom de l'objet** | "pompe", "chaufferie", "chaudiere", "chaudière", " eau", "bruleur" | Si le nom de l'objet contient au moins un de ces fragments, il est automatiquement ajouté à la page des pilotages de la chaufferie. |

<br>
