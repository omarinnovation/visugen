# Process Mise à jour visualisations Argan

## 1 - Mettre à jour ressources graphiques

### CSS personnalisé

Il faut ajouter certains éléments afin que la visualisation s'affiche correctement.

<center>

![](.\img_maj_argan\1.png)

![](.\img_maj_argan\2.png)

Cliquer sur [ce lien](http://217.181.132.218:55556/scada-main/main/editor?id=css) pour récupérer le contenu a coller dans la fenêtre.

**Remplacer** le contenu de cette fenêtre par le nouveau, puis cliquer sur **Sauvegardez et fermez**
![](.\img_maj_argan\css.png)

</center>

### Polices

Il faut également uploader sur l'harmony certaines polices si elles ne sont pas déjà présentes.

Vous pouvez récupérer ces polices sur [cette page](https://fonts.google.com/specimen/Poppins) et les télécharger comme ceci :

![](.\img_maj_argan\3.png)

Parmi toutes les polices seules 3 nous intéressent :

![](.\img_maj_argan\4.png)

Pour les ajouter sur l'automate, il suffit de se rendre dans l'onglet **"Graphiques" > Polices**

<center>

![](.\img_maj_argan\5.png)

Puis Ajouter les polices une par une (pas moyen de les ajouter ensemble malheureusement)

![](.\img_maj_argan\6.png)

</center>

C'est bon pour cette étape, on peut passer aux modifications sur l'automate.

## 2 - Normaliser les données de l'automate

### Noms d'objets

Les noms d'objets situés dans des cellules doivent clairement contenir le numéro / nom de la cellule.

#### Formalisme des noms :

- Doit finir par le mot "cellule" suivi du numéro / nom de cellule (attention aux objets nommés **"celluleS X"**)
- Un objet ne peut contenir plusieurs numéros ou noms de cellule (si c'est le cas, mettre les noms en trop entre parenthèses)
- Ne doit pas contenir de texte après le numéro / nom de cellule **sauf** du texte entre parenthèses

#### Exemple

<table>
  <tr>
    <th>Nom d'objet
    <th>Correct ?
    <th>Cause
  </tr>
  <tr>
  <tr>
    <td><code>Aérotherme cellule 4
    <td>✔️
    <td>_______
  </tr>
  <tr>
    <td><code>Aérotherme Cellule H
    <td>✔️
    <td>_______
  </tr>
  <tr>
    <td><code>Cellule 4 Aérotherme
    <td>❌
    <td>Ne finit pas par "cellule X"
  </tr>
  <tr>
    <td><code>Aérothermes cellules 2
    <td>❌
    <td>"cellules" au lieu de "cellule"
  </tr>
  <tr>
    <td><code>Aérotherme Cellule 4 5
    <td>❌
    <td>2 numéros de cellule
  </tr>
  <tr>
    <td><code>Aérothermes Cellule 4 (Contacteur K32 HS)
    <td>✔️
    <td>_______
  </tr>

</table>

## 3 - Générer la nouvelle visualisation

Générer puis importer la nouvelle visualisation

## 4 - Faire les modifications nécessaires pour reproduire l'ancienne

- Mettre les mêmes fonds de plan

- Déplacer les objets aux bons emplacements

- **Passer sur toutes les pages** et corriger tout ce qui paraît anormal

- Mettre la nouvelle visualisation en première position dans l'onglet **"Structure de la visualisation"**
