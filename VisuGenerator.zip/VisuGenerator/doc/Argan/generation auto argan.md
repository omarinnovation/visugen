# Génération de visus automatique pour les sites Argan

_Version 2024.01.17_

Voici les informations à connaître pour que la génération se déroule sans problèmes.

## Cellules

> Ces règles concernent les objets de pilotages mais aussi les **températures** et **défauts** correspondant à une cellule.

Une cellule peut être identifiée par un **nombre** ou bien une **chaine de caractères**, mais cet identifiant doit être identique pour chaque objet afin qu'ils soient ajoutés à la même page.

#### Formalisme noms d'objets

- Doit finir par le mot "cellule" suivi du numéro / identifiant de cellule
- Ne doit pas contenir de texte après le numéro / identifiant de cellule **sauf** du texte entre parenthèses

#### Exemple

<table>
  <tr>
    <th>Nom d'objet
    <th>Correct ?
    <th>Cause
  </tr>
  <tr>
  <tr>
    <td><code>Aérotherme cellule 4
    <td>✔️
    <td>_______
  </tr>
  <tr>
    <td><code>Aérotherme Cellule H
    <td>✔️
    <td>_______
  </tr>
  <tr>
    <td><code>Cellule 4 Aérotherme
    <td>❌
    <td>Ne finit pas par "cellule X"
  </tr>
  <tr>
    <td><code>Aérothermes cellules 2
    <td>❌
    <td>"cellules" au lieu de "cellule"
  </tr>
  <tr>
    <td><code>Aérotherme Cellule 4 5
    <td>❌
    <td>2 numéros de cellule
  </tr>
  <tr>
    <td><code>Aérothermes Cellule 4 (Contacteur K32 HS)
    <td>✔️
    <td>_______
  </tr>

</table>

#### Informations

- Les textes entre parenthèses ne seront pas affichés sur les noms d'objets
- Le type (pilotage ou CVC) est détecté automatiquement
- Les 4 pages de cellules (pilotage, CVC, températures et défauts) seront toujours créées même si un seul objet (de pilotage par exemple) est détecté

#### Exemple

<table>
  <tr>
    <th>Nom réel
    <th>Nom sur la visu
  </tr>
  <tr>
    <td><code>Aérotherme (K123) Cellule H (ne fonctionne pas)
    <td><code>Aérotherme Cellule H
  </tr>
</table>

## Bureaux

Il est possible grâce à un tag de créer des pages spécifiques et d'y ajouter des objets.

#### Informations

- Le tag `VISUB_xxxx` permet de créer une page au nom `xxxx` et d'y ajouter tous les objets qui portent ce tag.
- Les espaces doivent être remplacés par des underscore `_` dans le tag.
- Un lien vers cette page sera ajouté à la page `Détail des bureaux`

#### Exemple

<table>
  <tr>
    <th>Tag
    <th>Nom de la page
    <th>Correct ?
  </tr>
  <tr>
    <td><code>VISUB_Bureaux_étage
    <td><code>Bureaux étage
    <td>✔️
  </tr>
  <tr>
    <td><code>VISUB_Bureaux étage
    <td align="center"><code>___
    <td>❌
  </tr>
</table>

## Locaux Techniques

Le fonctionnement est le même que pour les Bureaux avec un tag différent : `VISULT_xxxx`. Seul un lien sur le plan du site sera ajouté pour chaque local technique.

## Chaufferies

> La génération des pages de chaufferies est automatique.
> Plusieurs chaufferies peuvent être détectées si le numéro de la chaufferie est ajouté.

#### Création

- Si un objet contient "chaufferie" dans son nom
- Si un objet contient un des tags de cette liste: `VISU_CHO, KING_CHAUFFERIE, TEMP_DEPART, HVAC_CHAUFFERIE`

_Pour créer plusieurs pages de chaufferies:_

- Chaque nom d'objet doit finir par le mot `chaufferie` suivi du numéro de la chaufferie

#### Objets ajoutés

- Défauts (contenant `chaufferie` dans leur nom)
- Pilotages (contenant `chaufferie` dans leur nom)
- Températures départ (tag `TEMP_DEPART` ou par le nom)
- Températures retour (par le nom)

## Extérieurs

Les pilotages sont ajoutés sur la page "Extérieur" s'ils possèdent au moins un des tags suivants: `PARKING, NUIT, RONDE, ENSEIGNE`

## Consignes CVC

Les consignes Smart CVC sont ajoutées automatiquement sur les pages de Cellules - CVC.

> **Attention**, il faut pour cela que le nom de la zone (objet `PARAM_Zone_Name_ZONE_X`) soit le même que le celui de la cellule (Cellule 1 par exemple s'il s'agit de cette zone)
