# Documentation des chaufferies sur VisuGenerator

## Détection et Ajout de Liens

### Détection de Chaufferie:

- Les pages de chaufferies sont automatiquement générées si au moins un objet contient un de ces tags : `VISU_CHO`, `KING_CHAUFFERIE`, `TEMP_DEPART`, `HVAC_CHAUFFERIE`.

- Elles sont aussi crées si un objet contient le mot `chaufferie` dans son nom.

- Les objets dont le nom commence par `chaufferie` sont traités pour extraire le numéro de la chaufferie, s’il existe, afin de gérer les sites avec plusieurs chaufferies.
- Un lien est créé entre les chaufferies détectées et les plans nommés `Locaux techniques` ou `Plan du site`.

### Ajout de Liens:

- Pour chaque chaufferie détectée, un lien textuel est ajouté au plan `Menu CVC`. Si ce plan n'est pas trouvé, le lien est ajouté au plan `Plan du site`.
- Les coordonnées du lien ajouté sont calculées en fonction du numéro de la chaufferie pour assurer un placement cohérent sur le plan.

## Gestion des Pilotages

Afin d'être ajoutés en tant que pilotages de chaufferie, les objets doivent avoir un tag parmi les suivants : `KING_CHAUFFERIE`, `HVAC_CHAUFFERIE_...`, et pour les ajouter manuellement il est possible de placer le tag `VISU_CHO`.

## Gestion des Températures

### Température départ

- Pour chaque chaufferie, le logiciel tente de trouver et d’ajouter des informations sur les températures de départ et de retour.
- Les températures sont recherchées dans les tags associés aux objets. Si un tag correspond à `TEMP_DEPART`, l’adresse de cet objet est notée.
- Si aucune température de départ n’est trouvée via les tags, une recherche supplémentaire est effectuée parmi les objets dont les adresses commencent par `3/` ou `4/` et dont le nom contient les termes `départ` ou `aller`.

### Température retour

- De même pour la température retour qui est trouvée parmi les objets dont les adresses commencent par `3/` ou `4/` et dont le nom contient le terme `retour`.

## Conditions d’Ajout et Limitations

- Les objets sont ajoutés seulement s’ils correspondent à des critères prédéfinis (comme les adresses KNX spécifiques, le nom, ou les tags).
- Si l'espace sur le plan est insuffisant pour afficher tous les objets détectés, un message est produit pour indiquer que certains objets n’ont pas été ajoutés et doivent être gérés manuellement.
