# Instructions d'installation

## Installer Python
Installer Python >= 3.11 sur votre ordinateur : https://www.python.org/downloads/

## Installer pip
Installer pip (gestionnaire de packages Python) sur votre ordinateur : https://pip.pypa.io/en/stable/installation/

## Installer les dépendances
Le but de cette étape, est, avec pip, d'installer tous les packages Python nécessaires au fonctionnement de `VisuGenerator/mainallGUI.pyw`. Dans un terminal, changer de dossier pour aller dans `dev-be-chantier/VisuGenerator`. Puis exécuter la commande suivante :
```pip install -r requirements.txt```

## Tester le fonctionnement
Dans un terminal, changer de dossier pour aller dans `dev-be-chantier/VisuGenerator`. Puis exécuter la commande suivante :
```python mainallGUI.pyw```
