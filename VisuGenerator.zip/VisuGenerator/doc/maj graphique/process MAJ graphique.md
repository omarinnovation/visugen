# Process mise à jour graphique

## CSS personnalisé

Il faut ajouter certains éléments afin que la visualisation s'affiche correctement.

Dans l'archive **"maj_graphique.zip"** fournie avec cette doc, vous trouverez le fichier nécessaire :

<center>

![](.\img_maj_argan\7.png)

</center>

Suivez ensuite les étapes suivantes :

<center>

![](.\img_maj_argan\1.png)

![](.\img_maj_argan\2.png)

**Remplacer** le contenu de cette fenêtre par le nouveau, puis cliquer sur **Sauvegardez et fermez**
![](.\img_maj_argan\css.png)

</center>

## Polices

Il faut également uploader sur l'harmony certaines polices si elles ne sont pas déjà présentes.

Vous pouvez récupérer ces polices dans l'archive :

![](.\img_maj_argan\8.png)

Pour les ajouter sur l'automate, il suffit de se rendre dans l'onglet **"Graphiques" > Polices**

<center>

![](.\img_maj_argan\5.png)

Puis Ajouter les polices une par une (pas moyen de les ajouter ensemble malheureusement)

![](.\img_maj_argan\6.png)

</center>

> Si après cela les mises à jour ne sont pas visibles, vous pouvez exporter toute la visualisation, la supprimer et l'importer à nouveau, cela devrait résoudre le problème
