# -*- coding: utf-8 -*-
"""
Created on Fri Jan 13 15:42:30 2023

@author: RobinBourgeon
"""
import sys
import PySimpleGUI as sg
import os
import tarfile
import json
import re
import requests
from requests.auth import HTTPBasicAuth
from eficia_utils.utils import clean_url
from unidecode import unidecode


VIS_OBJECTS = {
    "temp": [
        {
            "size": 18,
            "color": "#1ba3ef",
            "font": "Poppins Medium",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 65,
            "height": 64,
            "icon_default": "thermo-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "light": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 80,
            "height": 80,
            "icon_on": "light_solo_off.svg",
            "icon_off": "light_solo_on.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "light-NI": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 80,
            "height": 80,
            "icon_on": "light_solo_on.svg",
            "icon_off": "light_solo_off.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "fan": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 80,
            "height": 80,
            "icon_on": "fan_off.svg",
            "icon_off": "fan_on.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "fan-BLD-simple": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 44,
            "height": 44,
            "icon_on": "fan_off.svg",
            "icon_off": "fan_on.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "fan-BLD": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 74,
            "height": 54,
            "icon_on": "fan_info_off.png",
            "icon_off": "fan_info_on.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "fan-NI": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 80,
            "height": 80,
            "icon_on": "fan_on.svg",
            "icon_off": "fan_off.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "text": [
        {
            "size": 22,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
        },
        0,
    ],
    "text_bigger": [
        {
            "size": 25,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
        },
        0,
    ],
    "link_retour": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": None,
            "height": None,
            "displaymode": "icon",
            "icon": "chevron-up-FFFFFF-0091EA.svg",
            "icon_active": "",
        },
        0,
    ],
    "link_loc_soc": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 80,
            "height": 94,
            "displaymode": "icon",
            "icon": "Locauxsociaux.png",
            "icon_active": "",
        },
        0,
    ],
    "lien_texte": [
        {
            "size": 25,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 233,
            "height": 33,
            "displaymode": "value",
        },
        0,
    ],
    "icone_pilotage": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 22,
            "height": 21,
            "icon_on": "icone_off.svg",
            "icon_off": "icone_on.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "icone_pilotage_NI": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 22,
            "height": 21,
            "icon_on": "icone_on.svg",
            "icon_off": "icone_off.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "texte_pilotage": [
        {
            "size": 16,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": None,
            "height": None,
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_TEXT": [
        {
            "size": 20,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": None,
            "height": None,
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "icone_entrees": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 41,
            "height": 41,
            "icon_on": "cloche_on.svg",
            "icon_off": "cloche_off.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "icone_entrees_NI": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 45,
            "height": 45,
            "icon_on": "cloche_off.svg",
            "icon_off": "cloche_on.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "texte_entrees": [
        {
            "size": 20,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": None,
            "height": None,
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "cadenas_alarme": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 56,
            "height": 56,
            "icon_on": "lock-383838-0091EA.svg",
            "icon_off": "unlock-383838-0091EA.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "cloche_intrusion": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 56,
            "height": 56,
            "icon_on": "bell-D50000-0091EA.svg",
            "icon_off": "bell-383838-0091EA.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "text_20": [
        {
            "size": 20,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
        },
        1,
    ],
    "texte_bleu": [
        {
            "size": 22,
            "color": "#006B99",
            "font": "Poppins",
            "bold": 1,
            "italic": 0,
            "underline": 0,
            "width": None,
            "height": None,
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "CO2_texte_small": [
        {
            "size": 18,
            "color": "#1ba3ef",
            "font": "Poppins Medium",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 50,
            "height": 50,
            "icon_default": "nuage-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "humidite_texte_small": [
        {
            "size": 18,
            "color": "#1ba3ef",
            "font": "Poppins Medium",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 50,
            "height": 50,
            "icon_default": "goutte-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "temperature_texte_small": [
        {
            "size": 18,
            "color": "#1ba3ef",
            "font": "Poppins Medium",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 50,
            "height": 50,
            "icon_default": "thermo-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "CO2_texte": [
        {
            "size": 18,
            "color": "#1ba3ef",
            "font": "Poppins Medium",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 64,
            "height": 62,
            "icon_default": "nuage-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "humidite_texte": [
        {
            "size": 18,
            "color": "#1ba3ef",
            "font": "Poppins Medium",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 64,
            "height": 62,
            "icon_default": "goutte-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "temperature_texte": [
        {
            "size": 18,
            "color": "",
            "font": "Poppins Medium",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 64,
            "height": 62,
            "icon_default": "thermo-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "temperature_texte_jaune": [
        {
            "size": 18,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 64,
            "height": 62,
            "icon_default": "temperature-degrees-F7FF00-0091EA.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "icone_eco": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 100,
            "height": 100,
            "icon_on": "finger-54EB00-0091EA.svg",
            "icon_off": "finger-383838-0091EA.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "text_25": [
        {
            "size": 25,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
        },
        1,
    ],
    "toggle": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 132,
            "height": 44,
            "icon_on": "ToggleOFFgrey.png",
            "icon_off": "ToggleONblue.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "toggle_ni": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 132,
            "height": 44,
            "icon_off": "ToggleOFFgrey.png",
            "icon_on": "ToggleONblue.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "defaut": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 43,
            "height": 43,
            "icon_on": "alarm-D50000-0091EA.svg",
            "icon_off": "alarm-383838-0091EA.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_TOGGLE": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 143,
            "height": 44,
            "icon_on": "ToggleONblue.png",
            "icon_off": "ToggleOFFgrey.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "ROOF_CONS_ETE": [
        {
            "size": 20,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 76,
            "height": 78,
            "icon_default": "ConsigneEt.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "ROOF_CONS_HIVER": [
        {
            "size": 20,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 76,
            "height": 78,
            "icon_default": "ConsigneHiver.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        0,
    ],
    "ROOF_DEFAUT": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 76,
            "height": 78,
            "icon_on": "AlarmaOn.png",
            "icon_off": "AlarmaOff.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_EXTRACT": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 95,
            "height": 70,
            "icon_on": "entree-air-crop.gif",
            "icon_off": "Carrevide.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_REPRISE": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 20,
            "height": 63,
            "icon_on": "reprise-air-crop.gif",
            "icon_off": "Carrevide.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_SOUFFL": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 20,
            "height": 68,
            "icon_on": "sortie-air-crop.gif",
            "icon_off": "Carrevide.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_VENTIL": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 114,
            "height": 126,
            "icon_on": "Ventilateurcentrifuge.gif",
            "icon_off": "Carrevide.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_CONDENS_TOP": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 94,
            "height": 16,
            "icon_on": "Ventilateuraxial.gif",
            "icon_off": "Carrevide.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_CONDENS_ARROW": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 87,
            "height": 19,
            "icon_on": "entree-condenseur-crop.gif",
            "icon_off": "Carrevide.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ROOF_COMP": [
        {
            "size": "",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 58,
            "height": 94,
            "icon_on": "Compresseur.gif",
            "icon_off": "Carrevide.png",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "pincode": "",
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
    "ProgHor": [
        {
            "source": "schedulers",
            "width": "1198",
            "height": "614",
            "refresh": "",
            "persist": 0,
        },
        0,
    ],
    "Temp_FNAC": [
        {
            "size": 16,
            "color": "",
            "font": "Poppins",
            "bold": 0,
            "italic": 0,
            "underline": 0,
            "width": 55,
            "height": 55,
            "icon_default": "thermo-bleu.svg",
            "icon_touch": "",
            "icons_add": [],
            "displaymode": "icon-value",
            "showcontrol": 0,
            "fixedvalue": "",
            "update": False,
            "widget": None,
            "backdrop": 0,
        },
        1,
    ],
}

VIS_OBJECTS_V2 = {
    "objet_dali": [
        {
            "type_objet": "icone_valeur",
            "size": 47,
            "icone_on": "bulb-FFFFFF-0091EA.svg",
            "fontsize": 20,
        },
        1,
    ],
    "BigDefautFNAC": [
        {
            "size": 56,
            "icone_on": "alarm-D50000-0091EA.svg",
            "icone_off": "alarm-54EB00-0091EA.svg",
        },
        1,
    ],
    "DefautFNAC": [
        {
            "size": 36,
            "icone_on": "alarm-D50000-0091EA.svg",
            "icone_off": "alarm-54EB00-0091EA.svg",
        },
        1,
    ],
    "PilotageFanFNAC": [
        {
            "size": 52,
            "icone_on": "fan_off.svg",
            "icone_off": "fan_on.svg",
        },
        1,
    ],
    "PilotageLightFNAC": [
        {
            "size": 52,
            "icone_on": "light_solo_off.svg",
            "icone_off": "light_solo_on.svg",
        },
        1,
    ],
    "Defaut_roof": [
        {"size": 22, "icone_on": "bell_on.svg", "icone_off": "bell_off.svg"},
        1,
    ],
}


def knx_to_id(knx):
    """
    Convert knx adress into id for visualisation data.
    :param knx: knx adress.
    :return: Object id relative to the knx adress.
    """
    knx_array = knx.split("/")
    object_id = int(knx_array[0]) * 2048 + int(knx_array[1]) * 256 + int(knx_array[2])
    return object_id


def centered_on(coord_x, name, ppc=11):  # ppc = pixels per character (11 is default)
    """Centrer horizontalement un texte sur une coordonnée en fonction de sa longueur"""
    return (coord_x) - (ppc * len(name) / 2)


def gen_parameters_v2(
    type_objet="onoff",
    size=10,
    width=None,
    height=None,
    icone_on="",
    icone_off="",
    fontsize=18,
    bold=0,
    readonly=None,
    icones_add: list = None,
    # de la forme : [[valeur_min1, valeur_max1, "icone1.png"],[valeur_min2, valeur_max2, "icone2.png"]
    # possible de spécifier seulement une valeur qui sera la même pour min et max
    icone_default="",
    url=None,
    font="Poppins",
    color="",
    send_fixed_value="",
):
    """Improved version of object parameter generation"""
    if not width and not height:
        width = size
        height = size
    if type_objet == "onoff":
        param = (
            f'{{"size":"","bold":0,"italic":0,"underline":0,"width":{width},"height":{height},'
            f'"icon_on":"{icone_on}","icon_off":"{icone_off}","icon_touch":"","icons_add":[],'
            f'"displaymode":"icon","showcontrol":0,"fixedvalue":"{send_fixed_value}","update":false,"widget":null,'
            f'"backdrop":0}}'
        )
    elif type_objet == "lien":
        param = (
            f'{{"size":"","bold":0,"italic":0,"underline":0,"width":{width},"height":{height},'
            f'"displaymode":"icon","icon":"{icone_on}","icon_active":""}}'
        )

    elif type_objet == "lien_texte":
        param = (
            f'{{"size":{fontsize},"color":"{color}","font":"{font}","bold":{bold},"italic":0,'
            f'"underline":0,"width":{width},"height":{height},"displaymode":"value"}}'
        )
    elif type_objet == "valeur":
        param = (
            f'{{"size":{fontsize},"color":"{color}","font":"{font}","bold":{bold},"italic":0,'
            f'"underline":0,"width":null,"height":null,"icon_touch":"","icons_add":[],'
            f'"displaymode":"value","showcontrol":0,"fixedvalue":"","update":false,"widget":null,'
            f'"backdrop":0}}'
        )
    elif type_objet == "icone_valeur":
        param = (
            f'{{"size":{fontsize},"color":"{color}","font":"{font}","bold":0,"italic":0,'
            f'"underline":0,"width":{width},"height":{height},"icon_default":"{icone_on}",'
            f'"icon_touch":"","icons_add":[],"displaymode":"icon-value","showcontrol":0,'
            f'"fixedvalue":"","update":false,"widget":null,"backdrop":0}}'
        )
    elif type_objet == "url":
        param = f'{{"source":"url","url":"{url}","width":"{width}","height":"{height}","refresh":"","persist":0}}'
    elif type_objet == "icones_add":
        params_add = ""
        for index, icone in enumerate(icones_add):
            virgule = "," if index < len(icones_add) - 1 else ""
            if len(icone) < 3:
                valeur_min = icone[0]
                valeur_max = icone[0]
                icone_supplementaire = icone[1]
            else:
                valeur_min = icone[0]
                valeur_max = icone[1]
                icone_supplementaire = icone[2]

            params_add += f'{{"min":{valeur_min},"max":{valeur_max},"icon":"{icone_supplementaire}"}}{virgule}'

        param = (
            f'{{"size":"","bold":0,"italic":0,"underline":0,"width":{width},"height":{height},'
            f'"icon_default":"{icone_default}","icon_touch":"","icons_add":[{params_add}],'
            f'"displaymode":"icon","showcontrol":0,"fixedvalue":"","update":false,"widget":null,'
            f'"backdrop":0}}'
        )

    else:
        raise ValueError("Invalid type_objet")
    if readonly is not None:
        return [param, readonly]
    else:
        return param


def gen_parameters(type_objet):
    """
    Génération automatique d'objets de visualisation en fonction
    du type d'objet.
    :param type_objet: str
    type d'objet pour la visualisation
    :return: params: list
    paramètres à retourner (liste de 2 éléments)
    params[0] = str
        paramètres de l'objet pour la visu
    params[1] = int
        ??????
    """
    if not type_objet:
        raise ValueError
    if type_objet in VIS_OBJECTS:
        params = [json.dumps(VIS_OBJECTS[type_objet][0]), VIS_OBJECTS[type_objet][1]]

    elif type_objet in VIS_OBJECTS_V2:
        params = [
            gen_parameters_v2(**VIS_OBJECTS_V2[type_objet][0]),
            VIS_OBJECTS_V2[type_objet][1],
        ]

    return params


def find_duplicates(liste=list):
    """
    Renvoie les doublons d'une liste
    """
    seen = set(liste)
    for element in seen:
        liste.remove(element)
    return liste


def atof(text):
    """str to float"""
    try:
        retval = float(text)
    except ValueError:
        retval = text
    return retval


def natural_keys(text):
    """
    Permet de trier des strings par ordre croissant des chiffres contenus dans cette string
    (et pas par ordre alphabétique soit 1,10,11,2,21,etc...)
    """
    return [atof(c) for c in re.split(r"[+-]?([0-9]+(?:[.][0-9]*)?|[.][0-9]+)", text)]


def clean_single_rt_name(nom=""):
    """Extract Rooftop location from device name"""
    return " ".join(nom.split("_")[3:-1])


def clean_rt_name(liste_noms):
    """Extract Rooftop location from list of device names"""
    true_list_final = []
    for nom_roof in liste_noms:
        nom_final = clean_single_rt_name(nom_roof)
        true_list_final.append(nom_final)
    return true_list_final


def is_obj_boolean(datatype: int) -> bool:
    """
    Vérifie si un objet est un booléen selon son datatype

    Args:
        datatype (int): Type de donnée

    Returns:
        bool: Vrai si datatype = 1 ou 100x...
    """
    return datatype == 1 or (datatype <= 2000 and str(datatype).startswith("1"))


def process_name(name: str):
    """
    Process the given name string and extract relevant information.

    Args:
        name (str): The name string to be processed.

    Returns:
        str: The extracted relevant information.
    """
    name = name.split(" - ")[0]
    liste = name.split("_")
    if len(liste) < 6:
        return " ".join(liste[2:-1])
    else:
        return " ".join(liste[3:-1])


def remove_parentheses(text):
    """
    Remove parentheses from the given text string.

    Args:
        text (str): The input text string containing parentheses.

    Returns:
        str: The text string with all parentheses removed.
    """
    return re.sub(r"\([^()]*\)", "", text)


def generate_grid_coordinates(num_items, spacing=150, max_width=1100):
    """
    Calculates the x and y coordinates of an item in a grid layout given the number of items,
    spacing between items, and the maximum width of the grid.

    Parameters:
    - num_items (int): The total number of items in the grid.
    - spacing (int): The spacing between each item in the grid. Default is 150.
    - max_width (int): The maximum width of the grid. Default is 1100.

    Returns:
    - x (int): The x coordinate of the item.
    - y (int): The y coordinate of the item.
    """
    # Calculate the number of items per row
    items_per_row = max_width // spacing

    # Calculate the row and column position of the last item
    row = (num_items - 1) // items_per_row
    col = (num_items - 1) % items_per_row

    # Calculate the x and y coordinates
    x = 150 + col * spacing
    y = 250 + row * spacing

    return x, y


def upload_visu(ip, username, password, filepath):
    print("\nDébut de l'upload de la visualisation sur l'automate...")
    url = f"http://{clean_url(ip)}/scada-main/vis/import"  # Remplacez par l'URL à laquelle vous souhaitez envoyer la requête

    with open(filepath, "rb") as stream:
        # Les données textuelles
        payload = {"mode": "keep", "id": 0, "ptype": ""}
        files = {"file": stream}

        # L'en-tête de la requête
        headers = {
            "X-Requested-With": "XMLHttpRequest",
        }

        try:
            # Envoi de la requête POST
            response = requests.post(
                url,
                headers=headers,
                data=payload,
                files=files,
                timeout=30,
                auth=HTTPBasicAuth(username, password),
            )
        except Exception as e:
            print(f"Erreur : {e}")
            return False

    result = json.loads(response.text)
    return result["success"]


def upload_font(ip, username, password, filepath):
    """
    Uploads a font file to a specified server using HTTP POST.

    Parameters:
    ip (str): The IP address of the server where the font is to be uploaded.
    username (str): The username for HTTP basic authentication.
    password (str): The password for HTTP basic authentication.
    filepath (str): The file path of the font file to be uploaded.

    Returns:
    bool: True if the font was successfully uploaded, False otherwise.

    """
    url = f"http://{clean_url(ip)}/scada-main/visgraphics/font-save"

    with open(filepath, "rb") as stream:
        files = {"file": stream}

        # L'en-tête de la requête
        headers = {
            "X-Requested-With": "XMLHttpRequest",
        }

        # Envoi de la requête POST
        try:
            response = requests.post(
                url,
                headers=headers,
                files=files,
                timeout=15,
                auth=HTTPBasicAuth(username, password),
            )
        except Exception:
            return False

    result = json.loads(response.text)
    return result["success"]


def detect_location(name: str = ""):
    formatted_name = unidecode(name.lower())
    keyword_lists = {
        "jardin": ["jardin"],
        "bati": ("bati", "show", "decoupe"),
        "exterieur": ("parking", "exterieur", "ext", "facade", "auvent", "enseigne"),
        "reserve": ("reserve", "reception", "meuniserie", "srm", "zrm", "sav"),
        "loc_soc": (
            "bureau",
            "r+",
            "rdc",
            "loc soc",
            "locaux sociaux",
            "sanitaire",
            "local",
        ),
        "sdv": (
            "sdv",
            "vente",
            "sas",
            "canalis",
            "entree",
            "caisse",
            "sortie",
            "magasin",
            "agencement",
            "power",
            "track",
        ),
        "cvc": (
            "rac",
            "chauffage",
            "convecteur",
            "clim",
            "aerotherme",
            "vmc",
            "extracteur",
            "ecs",
            "destrat",
            "chaufferie",
            "pompe",
            "chaudiere",
        ),
    }
    # Jardin
    if any([mot in formatted_name for mot in keyword_lists["jardin"]]):
        tag = "VISU_JAR"
    # BAT
    elif any([mot in formatted_name for mot in keyword_lists["bati"]]):
        tag = "VISU_BAT"
    # EXT
    elif any([mot in formatted_name for mot in keyword_lists["exterieur"]]):
        tag = "VISU_EXT"
    # RES
    elif any([mot in formatted_name for mot in keyword_lists["reserve"]]) or re.findall(
        r"\bem\b", formatted_name
    ):
        tag = "VISU_RES"
    # LOC
    elif any([mot in formatted_name for mot in keyword_lists["loc_soc"]]):
        tag = "VISU_LOC"
    # SDV
    elif any([mot in formatted_name for mot in keyword_lists["sdv"]]):
        tag = "VISU_SDV"
    else:
        tag = "???"

    if any([mot in formatted_name for mot in keyword_lists["cvc"]]) and tag != "VISU_?":
        tag += "_CVC"

    return tag


def send_feedback(user, password, content_to_add):
    url = "http://217.181.132.218:55556/user/eficia_requests.lp"
    auth = (user, password)
    params = {"resource": "Store-values", "params": f'{{"content":"{content_to_add}"}}'}

    try:
        response = requests.post(url, params=params, auth=auth, timeout=5)
    except:
        print("Impossible d'envoyer le feedback.")
        return 1

    if response.status_code == 200:
        return 0
    else:
        print(response)
        return 1


def tardir(files, tar_name):
    """
    This function makes tar compression.
    :param files: Files to be compressed. (array with all paths)
    :param tar_name: Output's name. (end with .tar)
    """
    with tarfile.open(tar_name, "w:") as tar_handle:
        for file in files:
            tar_handle.add(os.path.join(file))
        tar_handle.close()


def window_info(text="", scrollable=False):
    """
    Crée une fenêtre simple pour afficher des éléments
    """
    titre = f"VisuGenerator"
    if scrollable:
        layout_info = [[sg.Text(text)]]
        colonne = [
            [sg.Column(layout=layout_info, scrollable=True, size=(600, 600))],
            [sg.Push(), sg.OK(), sg.Push()],
        ]
        fenetre = sg.Window(titre, colonne, resizable=True)
        event_info = fenetre.read()
        if event_info == sg.WIN_CLOSED:
            sys.exit()
        fenetre.close()
    else:
        layout_info = [[sg.Text(text)], [sg.Push(), sg.OK(), sg.Push()]]
        fenetre = sg.Window(titre, layout_info, resizable=True)
        event_info = fenetre.read()
        if event_info == sg.WIN_CLOSED:
            sys.exit()
        fenetre.close()


def choose_directory(version):
    """
    Fenêtre de sélection du dossier de destination de la visu
    """
    titre = f"VisuGenerator - {version}"
    left_col = [
        [sg.Text("Sélectionner le dossier de destination\n")],
        [sg.In(size=(45, 1), enable_events=True, key="-FOLDER-"), sg.FolderBrowse()],
    ]
    layout_dir = [[sg.Column(left_col, element_justification="c")], [sg.Ok()]]
    window_directory = sg.Window(
        titre, layout_dir, resizable=True, element_justification="c"
    )
    folder_destination = ""
    while True:
        event_dir, values_dir = window_directory.read()
        if event_dir in (sg.WIN_CLOSED, "Exit", "Ok"):
            break
        if event_dir == "-FOLDER-":
            folder_destination = values_dir["-FOLDER-"]
    window_directory.close()
    if event_dir == sg.WIN_CLOSED:
        sys.exit()
    if folder_destination == "":
        sg.popup("Erreur", "Renseigner un dossier de destination")
        sys.exit()
    else:
        return str(folder_destination)


def window_location(adresses, noms, tags):
    # Dropdown options
    tag = [
        "",
        "VISU_SDV",
        "VISU_SDV_CVC",
        "VISU_RES",
        "VISU_RES_CVC",
        "VISU_LOC",
        "VISU_LOC_CVC",
        "VISU_BAT",
        "VISU_BAT_CVC",
        "VISU_EXT",
        "VISU_EXT_CVC",
        "VISU_JAR",
        "VISU_JAR_CVC",
        "???",
        "???_CVC",
        "PARKING",
        "ENSEIGNE",
    ]

    name = [
        "Ne pas afficher",
        "Surface de vente",
        "CVC - Surface de vente",
        "Réserve",
        "CVC - Réserve",
        "Locaux sociaux",
        "CVC - Locaux sociaux",
        "Bâti",
        "CVC - Bâti",
        "Extérieur",
        "CVC - Extérieur",
        "Jardin",
        "CVC - Jardin",
        "???",
        "???",
        "Extérieur",
        "Extérieur",
    ]

    dropdown = name[0:-3]
    tag_to_name = {tag[i]: name[i] for i in range(len(tag))}
    name_to_tag = {name[i]: tag[i] for i in range(len(tag))}

    # Ensure max name length is limited to 75 characters
    max_name_length = min(max(len(name) for name in noms), 75)
    max_location_length = max(len(location) for location in name)
    scrollable_layout = []  # This will contain the scrollable content

    # Define column widths for alignment
    col_widths = {"adresse": 8, "nom": max_name_length, "tag": max_location_length}

    # Use a unique key for each ComboBox
    combobox_keys = [f"combo_{i}" for i, _ in enumerate(tags)]

    for i, (adresse, nom, tag) in enumerate(zip(adresses, noms, tags)):
        row = [
            sg.Text(adresse, size=(col_widths["adresse"], 1)),
            sg.Text(nom, size=(col_widths["nom"], 1)),
            sg.Combo(
                dropdown,
                default_value=tag_to_name[tag],  # transformer en nom full
                size=(col_widths["tag"], 1),
                readonly=True,
                key=combobox_keys[i],
            ),
        ]
        scrollable_layout.append(row)

    # Wrap the scrollable_layout in a Column element to make it scrollable
    scrollable_column = sg.Column(
        scrollable_layout, scrollable=True, vertical_scroll_only=True, size=(None, 300)
    )

    layout = [
        [scrollable_column],
        [sg.Push(), sg.Button("Valider et continuer", key="-VALIDATE-"), sg.Push()],
    ]

    # Create the window with the layout
    window = sg.Window("Localisation des pilotages", layout, resizable=True)

    # Event loop
    while True:
        event, values = window.read()

        if event == sg.WIN_CLOSED:
            window.close()
            print("Programme interrompu.")
            exit()

        if event == "-VALIDATE-":
            locations = [name_to_tag[values[key]] for key in combobox_keys]
            if "???" in locations:
                window_info("Attention il reste des pilotages sans localisation.")
            else:
                window.close()
                return locations


def most_common(liste):
    """Returns most common element in liste"""
    if len(liste) > 0:
        return max(set(liste), key=liste.count)
    return ""


def is_only_alarm_dependent(obj):
    """
    Check if the object is only dependent on alarm and not schedulers nor a combination of both
    """
    for tag in obj.tags:
        if tag in ("STOCKLIGHT", "STOCKLIGHT-NI", "ALARMEOFF") and "+" not in tag:
            return True
    return False
