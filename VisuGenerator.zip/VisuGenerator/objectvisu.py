# -*- coding: utf-8 -*-
"""
Created on Fri Jan 13 15:44:17 2023

@author: RobinBourgeon
"""


class Object:
    def __init__(
        self,
        object=8449,
        visparams="",
        name="",
        id=1,
        params="",
        sortorder=1,
        cls="",
        nobg=1,
        statusobject=8449,
        readonly=0,
        locy=100,
        type=1,
        locx=100,
        floor=1,
        notouch=0,
    ):
        # ID du Plan sur lequel link si type = 2 (Link Object)
        self.object = object
        self.visparams = visparams
        self.name = name
        self.id = id
        self.params = params
        self.sortorder = sortorder
        self.cls = cls
        self.nobg = nobg
        self.statusobject = statusobject
        self.readonly = readonly
        self.locy = locy
        self.type = type
        self.locx = locx
        self.floor = floor  # ID du plan sur lequel l'objet se trouve
        self.notouch = notouch


class Image:
    def __init__(
        self, id=1, params="", cls="", nobg=1, locy=100, type=1, locx=100, floor=1
    ):
        self.id = id
        self.params = params
        self.cls = cls
        self.nobg = nobg
        self.locy = locy
        self.type = type
        self.locx = locx
        self.floor = floor
