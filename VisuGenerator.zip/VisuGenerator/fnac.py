# -*- coding: utf-8 -*-
"""
Created on Fri Jan 13 16:13:06 2023

@author: RobinBourgeon
"""
from level import Level
from objectvisu import Object
from utils import gen_parameters, knx_to_id
from visualisation import Visualisation


class VisualisationFNAC(Visualisation):
    """Classe de visualisation pour les sites FNAC"""

    def __init__(
        self, name, nomdusite, harmony, dali_philips, dali_lon_bacnet, data_translated
    ):
        super().__init__(
            client="Fnac",
            name=name,
            nomdusite=nomdusite,
            harmony=harmony,
            dali_philips=dali_philips,
            dali_lon_bacnet=dali_lon_bacnet,
            data_translated=data_translated,
        )
        self.id = 1
        self.levels = []
        self.plans = []
        self.lws = []
        self.levels.append(Level(name=name))
        self.create_plan(name="Menu", parent=name, background="MenuFNACDARTY.png")
        self.create_plan(name=self.data_translated["programmes_horaires"], parent=name)
        self.create_plan(name=data_translated["menu_rt"], parent=name)
        self.create_plan(name=data_translated["temperatures"], parent=name)
        for plan in self.plans:
            if plan.name == data_translated["temperatures"]:
                plan.former()

    def create_object(
        self,
        parent="",
        other=False,
        typeOther=None,
        knx="1/1/1",
        locx=100,
        locy=100,
        type=None,
        readonly=1,
    ):
        for plan in self.plans:
            if plan.name == parent:
                id = len(plan.objects) + 1
                if not other:
                    plan.objects.append(
                        Object(
                            object=knx_to_id(knx),
                            statusobject=knx_to_id(knx),
                            id=id,
                            floor=plan.id,
                            locx=locx,
                            locy=locy,
                            params=gen_parameters(type)[0],
                            readonly=readonly,
                        )
                    )
                else:
                    plan.objects.append(
                        Object(
                            object=other,
                            id=id,
                            floor=plan.id,
                            type=typeOther,
                            locx=locx,
                            locy=locy,
                            params=gen_parameters(type)[0],
                        )
                    )
