# -*- coding: utf-8 -*-
"""
Created on Fri Jan 13 15:39:59 2023

@author: RobinBourgeon
"""


class Level:
    """Représente un niveau de visualisation"""

    def __init__(self, id=1, name="", description=""):
        self.id = id
        self.name = name
        self.sortorder = 1
        self.parent = 0
        self.description = description
