# -*- coding: utf-8 -*-
"""
Created on Fri Jan 13 15:41:29 2023

@author: RobinBourgeon
"""
import re
import json
from operator import itemgetter
from unidecode import unidecode

from objectvisu import Object
from utils import (
    centered_on,
    gen_parameters,
    knx_to_id,
    gen_parameters_v2,
    clean_single_rt_name,
    is_obj_boolean,
    remove_parentheses,
    detect_location,
    most_common,
    is_only_alarm_dependent,
)


def exclude_data(obj):
    keys_to_exclude = ["visualisation"]
    dic = {}
    for key, value in obj.__dict__.items():
        if not keys_to_exclude or key not in keys_to_exclude:
            dic[key] = value
    return dic


class Plan:
    """Représente une page de visualisation"""

    def __init__(
        self,
        visualisation,
        id=1,
        name="",
        width=1360,
        height=768,
        locx="",
        locy="",
        background="",
        bgrepeat=0,
        bgfixed=0,
        bgcolor="",
        touch_bgcolor="",
        background_add="",
        sortorder=1,
        building=1,
        touch_param="",
        usermode_param="",
        pincode="",
        layout=0,
    ):
        self.visualisation = visualisation
        self.id = id
        self.name = name
        self.width = width
        self.height = height
        self.locx = locx
        self.locy = locy
        self.background = background
        self.bgrepeat = bgrepeat
        self.bgfixed = bgfixed
        self.bgcolor = bgcolor
        self.touch_bgcolor = touch_bgcolor
        self.background_add = background_add
        self.sortorder = sortorder
        self.building = building  # ID du Level Parent
        self.touch_param = touch_param
        self.usermode_param = usermode_param
        self.pincode = pincode
        self.layout = layout
        self.objects = []

    # def to_json(self):
    #     """
    #     Traduit au format JSON la structure de données de la Visualisation afin
    #     de pouvoir l'importer sur l'automate.
    #     """
    #     content = json.dumps(self, default=exclude_data, sort_keys=True, indent=4)
    #     return content

    def to_json(self):
        """
        Traduit au format JSON la structure de données de la Visualisation afin
        de pouvoir l'importer sur l'automate.
        """
        plan_structure = {"plan": self}
        content = json.dumps(
            plan_structure, default=exclude_data, sort_keys=True, indent=4
        )
        return content

    def ajout_temperatures(self, liste_temperatures: list):
        """Ajout des températures sur plusieurs pages si nécessaire"""
        if self.visualisation.client in ("Cultura"):
            comm_check = True
            liste_comm_check = []
            for objet in self.visualisation.objets:
                if "COMM_CHECK" in objet.tags:
                    liste_comm_check.append(objet)
        else:
            comm_check = False
        # détection du plan actuel
        NOM_DU_PLAN = self.visualisation.data_translated["temperatures"]
        plans_temperature = []
        for plan in self.visualisation.plans:
            if plan.name.startswith(NOM_DU_PLAN):
                plans_temperature.append(plan.name)
        plan_actuel = NOM_DU_PLAN + " " + str(len(plans_temperature) + 1)

        nb_temperatures = len(liste_temperatures)
        OBJ_PAR_COLONNE = 6
        new_liste_temperatures = liste_temperatures[3 * OBJ_PAR_COLONNE :]
        liste_temperatures = liste_temperatures[: 3 * OBJ_PAR_COLONNE]
        INCREMENT_LIGNE = 100
        locy_icone_origine = 110
        locy_texte_origine = locy_icone_origine + 10

        if nb_temperatures <= OBJ_PAR_COLONNE:  # 1 colonne
            locx_icone_origine = 475
            locx_texte_origine = locx_icone_origine + 75

        if nb_temperatures <= 2 * OBJ_PAR_COLONNE:  # 2 colonnes
            locx_icone_origine = 275
            locx_texte_origine = locx_icone_origine + 75
            INCREMENT_COLONNE = 500

        else:  # 3 colonnes
            locx_icone_origine = 25
            locx_texte_origine = 101
            INCREMENT_COLONNE = 450

        locx_icone = locx_icone_origine
        locy_icone = locy_icone_origine
        locx_texte = locx_texte_origine
        locy_texte = locy_texte_origine

        params = ""
        for objet in self.visualisation.objets:
            if objet.adresse in liste_temperatures:
                for tag in objet.tags:
                    if tag == "TEMPERATURE":
                        params = gen_parameters_v2(
                            type_objet="icone_valeur",
                            size=50,
                            icone_on="thermo-bleu.svg",
                            fontsize=18,
                            font="Poppins Medium",
                            color="#1BA3EF",
                        )
                    elif tag == "HUMIDITE":
                        params = gen_parameters_v2(
                            type_objet="icone_valeur",
                            size=50,
                            icone_on="goutte-bleu.svg",
                            fontsize=18,
                            font="Poppins Medium",
                            color="#1BA3EF",
                        )
                    elif tag == "CO2":
                        params = gen_parameters_v2(
                            type_objet="icone_valeur",
                            size=50,
                            icone_on="nuage-bleu.svg",
                            fontsize=18,
                            font="Poppins Medium",
                            color="#1BA3EF",
                        )

                # Ajout de l'objet
                self.objects.append(
                    Object(
                        object=objet.address,
                        statusobject=objet.address,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=locx_icone,
                        locy=locy_icone,
                        params=params,
                        readonly=1,
                    )
                )

                # Ajout du texte
                # Traitement du texte
                nom_clean = objet.name.replace("_", " ").capitalize()
                self.visualisation.create_text(
                    parent=self.name,
                    text=nom_clean,
                    locx=locx_texte,
                    locy=locy_texte,
                    size=20,
                )

                # Ajout de l'objet de verification de communication
                if comm_check:
                    for comm in liste_comm_check:
                        if any(tag in comm.tags for tag in objet.tags):
                            self.objects.append(
                                Object(
                                    object=comm.address,
                                    statusobject=comm.address,
                                    id=len(self.objects) + 1,
                                    floor=self.id,
                                    locx=locx_texte - 21,
                                    locy=locy_texte + 6,
                                    params=gen_parameters_v2(
                                        type_objet="onoff",
                                        size=17,
                                        icone_on="ok.svg",
                                        icone_off="nok.svg",
                                    ),
                                    readonly=1,
                                )
                            )
                            break

                locy_icone += INCREMENT_LIGNE
                locy_texte += INCREMENT_LIGNE

                if locy_icone > 620:
                    locx_icone += INCREMENT_COLONNE
                    locx_texte += INCREMENT_COLONNE
                    locy_icone = locy_icone_origine
                    locy_texte = locy_texte_origine
        if comm_check:
            self.visualisation.create_image(
                parent=self.visualisation.data_translated["temperatures"],
                locx=27,
                locy=714,
                image="ok.svg",
                width=21,
                height=21,
            )
            self.visualisation.create_image(
                parent=self.visualisation.data_translated["temperatures"],
                locx=27,
                locy=744,
                image="nok.svg",
                width=21,
                height=21,
            )
            self.visualisation.create_text(
                parent=self.visualisation.data_translated["temperatures"],
                text="Données à jour",
                locx=58,
                locy=715,
                size=14,
            )
            self.visualisation.create_text(
                parent=self.visualisation.data_translated["temperatures"],
                text="Données anciennes (> 1h)",
                locx=58,
                locy=744,
                size=14,
            )

        if len(new_liste_temperatures) > 0:
            self.visualisation.create_plan(  # nouvelle page
                name=plan_actuel,
                parent=self.visualisation.name,
            )

            # lien de la page actuelle vers la précédente
            self.visualisation.create_link(
                parent=plan_actuel,
                target=plans_temperature[-1],
                locx=487,
                locy=692,
                genparams=True,
                params_to_use=gen_parameters_v2(
                    type_objet="lien",
                    size=50,
                    icone_on="retour_bleu.svg",
                ),
            )
            self.visualisation.create_text(
                parent=plan_actuel,
                text=self.visualisation.data_translated["page_precedente"],
                locx=455,
                locy=747,
                size=16,
                color="#1ba3ef",
            )

            # lien de la page précédente vers l'actuelle
            self.visualisation.create_link(
                parent=plans_temperature[-1],
                target=plan_actuel,
                locx=775,
                locy=692,
                genparams=True,
                params_to_use=gen_parameters_v2(
                    type_objet="lien",
                    size=50,
                    icone_on="retour_bleu_invert.svg",
                ),
            )
            self.visualisation.create_text(
                parent=plans_temperature[-1],
                text=self.visualisation.data_translated["page_suivante"],
                locx=745,
                locy=747,
                size=16,
                color="#1ba3ef",
            )

            # retour menu
            for plan in self.visualisation.plans:
                if plan.name == plan_actuel:
                    print("Création du plan " + plan.name)
                    plan.ajout_temperatures(new_liste_temperatures)

    def placer_liste(
        self,
        liste: list,
        obj_type: str,
        x: int = None,
        y: int = None,
        page_name: str = None,
    ):
        """
        Place a list of objects on one or more global pages.

        Args:
            liste (list): The list of objects to be placed.
            obj_type (str): The type of objects being placed.
            x (int, optional): The x-coordinate of the placement location. Defaults to None.
            y (int, optional): The y-coordinate of the placement location. Defaults to None.
        """
        ORIGINE_ICONE_Y = y or 150
        BORNE_MAX_Y = 627
        locy_icone = ORIGINE_ICONE_Y
        nb = len(liste)
        flag_more_objects = False

        if obj_type == "pilotages":
            NOM_DU_PLAN = self.visualisation.data_translated["detail_pilotages"]
            INCREMENT = 30
            OBJ_PAR_COLONNE = 17
            INCREMENT_X_TEXTE = 40  # Décalage en x du texte par rapport à l'icone
            INCREMENT_Y_TEXTE = 0  # Décalage en x du texte par rapport à l'icone
            DECALAGE_ICONE_TEXTE = -4

        elif obj_type == "entrees":
            NOM_DU_PLAN = self.visualisation.data_translated["detail_entrees"]
            INCREMENT = 60
            OBJ_PAR_COLONNE = 9
            INCREMENT_X_TEXTE = 50  # Décalage en x du texte par rapport à l'icone
            INCREMENT_Y_TEXTE = 10  # Décalage en y du texte par rapport à l'icone
            DECALAGE_ICONE_TEXTE = 0

        elif obj_type == "dali":
            NOM_DU_PLAN = "Salle de Vente - Dali"
            INCREMENT = 90
            OBJ_PAR_COLONNE = 6
            INCREMENT_X_TEXTE = 60  # Décalage en x du texte par rapport à l'icone
            INCREMENT_Y_TEXTE = 10  # Décalage en y du texte par rapport à l'icone
            DECALAGE_ICONE_TEXTE = 0

        elif obj_type == "defaut_rt":
            NOM_DU_PLAN = page_name
            INCREMENT = 40
            OBJ_PAR_COLONNE = 13
            INCREMENT_X_TEXTE = 40
            INCREMENT_Y_TEXTE = 0
            DECALAGE_ICONE_TEXTE = 0

        else:
            print("Placer_liste : le type d'objet choisi n'existe pas.")

        if nb > 3 * OBJ_PAR_COLONNE:  # + de 3 colonnes
            flag_more_objects = True
            new_liste = liste[3 * OBJ_PAR_COLONNE :]
            liste = liste[: 3 * OBJ_PAR_COLONNE]

        if x:
            locx_icone = x
            locx_texte = locx_icone + INCREMENT_X_TEXTE
        else:
            if nb <= OBJ_PAR_COLONNE:
                locx_icone = 565
                locx_texte = locx_icone + INCREMENT_X_TEXTE

            elif nb <= 2 * OBJ_PAR_COLONNE:  # Si 2 colonnes
                locx_icone = 342
                locx_texte = locx_icone + INCREMENT_X_TEXTE

            else:  # Si 3 colonnes
                locx_icone = 60
                locx_texte = locx_icone + INCREMENT_X_TEXTE
        flag_legende = True
        for element in liste:
            for objet in self.visualisation.objets:
                if objet.adresse == element:
                    knx = element

                    # Detection d'inversion dans le nom de l'objet
                    flag_ni = False
                    search_ni = re.findall(r"\bNI\b", objet.name)
                    search_no = re.findall(r"\bNO\b", objet.name)
                    search_nc = re.findall(r"\bNC\b", objet.name)
                    search_tag_ni = False
                    flag_prog_hor = is_only_alarm_dependent(objet)
                    for tag in objet.tags:
                        if tag.endswith("-NI"):
                            search_tag_ni = True
                            break

                    if obj_type == "pilotages":
                        params = gen_parameters_v2(
                            type_objet="onoff",
                            size=33,
                            icone_on="new-toggle-off.svg",
                            icone_off="new-toggle-on.svg",
                            readonly=0,
                        )
                    elif obj_type == "entrees":
                        params = gen_parameters(type_objet="icone_entrees")
                    elif obj_type == "dali":
                        params = [
                            gen_parameters_v2(
                                type_objet="icone_valeur",
                                size=47,
                                icone_on="weather-sun-FFFFFF-0091EA.svg",
                                fontsize=16,
                            ),
                            0,
                        ]
                    elif obj_type == "defaut_rt":
                        params = gen_parameters_v2(
                            type_objet="onoff",
                            size=22,
                            icone_on="bell_on.svg",
                            icone_off="bell_off.svg",
                            readonly=1,
                        )

                    for tag_sortie in objet.tags:
                        if tag_sortie.find("-NI") != -1:  # si pilotage inversé
                            flag_ni = True
                    if flag_ni or search_nc or search_ni or search_no or search_tag_ni:
                        print("Une entrée inversée a été détectée : " + objet.name)
                        if obj_type == "pilotages":
                            params = gen_parameters_v2(
                                type_objet="onoff",
                                size=33,
                                icone_on="new-toggle-on.svg",
                                icone_off="new-toggle-off.svg",
                                readonly=0,
                            )
                        if obj_type == "entrees":
                            params = gen_parameters(type_objet="icone_entrees_NI")

                    if (
                        self.visualisation.client == "Leroy Merlin"
                        or obj_type == "entrees"
                    ):
                        params[1] = 1  # Lecture seule pour Leroy merlin

                    self.objects.append(
                        Object(
                            object=knx_to_id(knx),
                            statusobject=knx_to_id(knx),
                            id=len(self.objects) + 1,
                            floor=self.id,
                            locx=locx_icone,
                            locy=locy_icone + DECALAGE_ICONE_TEXTE,
                            params=params[0],
                            readonly=params[1],
                        )
                    )
                    # ajout de l'indicateur de pilotage sur prog horaires pour Carrefour :
                    if flag_prog_hor and self.visualisation.client == "Carrefour":
                        self.visualisation.create_image(
                            parent=self.name,
                            locx=locx_icone - 30,
                            locy=locy_icone + 6 + DECALAGE_ICONE_TEXTE,
                            image="DISPLAYS_ICONS_INFO_BLUE_32.png",
                            width=20,
                            height=20,
                        )
                        if flag_legende:
                            self.visualisation.create_text(
                                parent=self.name,
                                text="Pilotage dépendant de l'alarme du site.",
                                locx=110,
                                locy=720,
                                size=16,
                            )
                            self.visualisation.create_image(
                                parent=self.name,
                                locx=80,
                                locy=720,
                                image="DISPLAYS_ICONS_INFO_BLUE_32.png",
                                width=20,
                                height=20,
                            )
                            flag_legende = False

                    # Ajout du texte
                    if obj_type == "pilotages":
                        params = gen_parameters(type_objet="texte_pilotage")
                    elif obj_type == "entrees":
                        params = gen_parameters_v2(
                            type_objet="valeur", fontsize=16, readonly=1
                        )
                    elif obj_type == "defaut_rt":
                        params = gen_parameters_v2(
                            type_objet="valeur", fontsize=18, readonly=1
                        )
                    adresse = knx.split("/")

                    if obj_type == "pilotages":
                        knx = "9/1/" + adresse[2]
                    elif obj_type == "entrees":
                        knx = "9/3/" + adresse[2]

                    if obj_type == "defaut_rt":
                        self.visualisation.create_text(
                            parent=self.name,
                            text=" ".join(objet.name.split(" - ")[1:]),
                            locx=locx_texte,
                            locy=locy_icone + INCREMENT_Y_TEXTE,
                            size=16,
                        )

                    elif obj_type != "dali":
                        self.objects.append(
                            Object(
                                object=knx_to_id(knx),
                                statusobject=knx_to_id(knx),
                                id=len(self.objects) + 1,
                                floor=self.id,
                                locx=locx_texte,
                                locy=locy_icone + INCREMENT_Y_TEXTE,
                                params=params[0],
                                readonly=params[1],
                            )
                        )

                    else:  # Dali
                        # Traitement du nom

                        if objet.name.find(" - ") != -1:
                            objet.name = objet.name.split(" - ")[1]

                        numero_zone = re.findall(r"\d+", objet.name)
                        nom_clean = re.sub(r"CMD_Dali_Command_\d+", "", objet.name)
                        nom_clean = (
                            re.sub(r"^[^éëêa-zA-Z]+", "", nom_clean)
                            .replace("Cmd_dali_command_", "")
                            .capitalize()
                            .replace("_", " ")
                        )
                        if not nom_clean:
                            nom_clean = f"Zone {numero_zone[0]}"

                        self.visualisation.create_text(
                            parent=self.name,
                            text=nom_clean,
                            locx=locx_texte,
                            locy=locy_icone + INCREMENT_Y_TEXTE,
                            size=16,
                        )

                    if locy_icone > BORNE_MAX_Y:
                        locy_icone = ORIGINE_ICONE_Y
                        locx_icone += 500
                        locx_texte += 500  # +=90
                    else:
                        locy_icone += INCREMENT

        if flag_more_objects:
            # nouvelle page
            liste_plans = []
            for plan in self.visualisation.plans:
                if plan.name.startswith(NOM_DU_PLAN):
                    liste_plans.append(plan.name)

            self.visualisation.create_plan(
                name=NOM_DU_PLAN + " " + str(len(liste_plans) + 1),
                parent=self.visualisation.name,
            )

            # lien de la page actuelle vers la précédente
            self.visualisation.create_link(
                parent=NOM_DU_PLAN + " " + str(len(liste_plans) + 1),
                target=liste_plans[-1],
                locx=487,
                locy=692,
                genparams=True,
                params_to_use=gen_parameters_v2(
                    type_objet="lien",
                    size=50,
                    icone_on="retour_bleu.svg",
                ),
            )
            self.visualisation.create_text(
                parent=NOM_DU_PLAN + " " + str(len(liste_plans) + 1),
                text=self.visualisation.data_translated["page_precedente"],
                locx=455,
                locy=747,
                size=16,
                color="#1ba3ef",
            )

            # lien de la page précédente vers l'actuelle
            self.visualisation.create_link(
                parent=liste_plans[-1],
                target=NOM_DU_PLAN + " " + str(len(liste_plans) + 1),
                locx=775,
                locy=692,
                genparams=True,
                params_to_use=gen_parameters_v2(
                    type_objet="lien",
                    size=50,
                    icone_on="retour_bleu_invert.svg",
                ),
            )
            self.visualisation.create_text(
                parent=liste_plans[-1],
                text=self.visualisation.data_translated["page_suivante"],
                locx=745,
                locy=747,
                size=16,
                color="#1ba3ef",
            )

            # retour menu
            for plan in self.visualisation.plans:
                if plan.name == NOM_DU_PLAN + " " + str(len(liste_plans) + 1):
                    print("Ajout des objets sur la page créée : " + plan.name)
                    plan.placer_liste(new_liste, obj_type, x, y, NOM_DU_PLAN)

    def get_sorties_cvc(self):
        liste_cvc = []
        for objet in self.visualisation.objets:
            if objet.adresse.startswith("1/1/") and is_obj_boolean(objet.datatype):
                if (
                    not objet.name.startswith(
                        self.visualisation.data_translated["sortie"] + " #"
                    )
                    and "libre" not in objet.name.lower()
                    and "coupure bridge" not in objet.name.lower()
                    and "coupure dali" not in objet.name.lower()
                    and "MasterRelay_1" not in objet.tags
                    and "DALI_POWER-NI" not in objet.tags
                    and "DALI_POWER" not in objet.tags
                ):
                    adresseknx = objet.adresse.split("/")
                    if detect_location(objet.name).endswith("CVC"):
                        liste_cvc.append(int(adresseknx[2]))
        liste_cvc.sort()  # tri par adresse croissante
        liste_cvc = ["1/1/" + str(element) for element in liste_cvc]

        return liste_cvc

    def get_sorties(self):
        liste_sorties = []
        for objet in self.visualisation.objets:
            if objet.adresse.startswith("1/1/") and is_obj_boolean(objet.datatype):
                if (
                    not objet.name.startswith(
                        self.visualisation.data_translated["sortie"] + " #"
                    )
                    and "coupure bridge" not in objet.name
                    and "MasterRelay_1" not in objet.tags
                    and "coupure dali" not in objet.name.lower()
                    and "DALI_POWER-NI" not in objet.tags
                    and "DALI_POWER" not in objet.tags
                    and not re.match(r"\d+-DO\s?\d", objet.name)
                ):
                    adresseknx = objet.adresse.split("/")
                    if self.visualisation.client in (
                        "Carrefour",
                        "Cultura",
                        "Bricoman",
                    ):
                        if not detect_location(objet.name).endswith("CVC"):
                            liste_sorties.append(int(adresseknx[2]))
                    else:
                        liste_sorties.append(int(adresseknx[2]))
        liste_sorties.sort()  # tri par adresse croissante
        liste_sorties = ["1/1/" + str(element) for element in liste_sorties]

        return liste_sorties

    def get_defauts(self):
        dic_entrees = {}
        incr = 0
        dic_synthese_rt = []
        for objet in self.visualisation.objets:
            for tag in objet.tags:
                if tag in ("DEFAUT_TECH", "DEFAUT_TECH-NI"):
                    dic_entrees[incr] = {}
                    dic_entrees[incr]["adresse"] = objet.adresse
                    dic_entrees[incr]["name"] = objet.name
                    # Détection de l'inversion de l'objet (NO ou NI) dans le nom
                    search_ni = re.findall(r"\bNI\b", objet.name)
                    search_no = re.findall(r"\bNO\b", objet.name)
                    search_nc = re.findall(r"\bNC\b", objet.name)
                    if len(search_ni) > 0 or len(search_no) > 0 or len(search_nc) > 0:
                        dic_entrees[incr]["inverted"] = 1
                        print("Une entrée inversée a été détectée : " + objet.name)
                    else:
                        dic_entrees[incr]["inverted"] = 0
                    incr += 1
                    break

                elif tag == "ENSLG_ROOF_DEFAUT" or tag == "HVACSDV1_ALARME_SYNTHESE":
                    if objet.name.find("ETT") != -1 or objet.name.find("LENNOX") != -1:
                        dic = dict.fromkeys(["adresse", "nom", "datatype", "numero"])
                        dic["adresse"] = objet.adresse
                        dic["nom"] = objet.name
                        dic["datatype"] = objet.datatype

                        # récupère l'id du device modbus pour le trier par ordre croissant
                        dic["numero"] = re.findall(r"\d+", objet.name)[-1]
                        dic_synthese_rt.append(dic)
                        break

        # Tri par ordre de rooftop croissant (numero=id modbus)
        dic_synthese_rt = sorted(dic_synthese_rt, key=itemgetter("numero"))

        # On se retrouve avec : dicEntrees - un dict contenant l'adresse
        # de chaque defaut_tech et un entier (0 ou 1) indiquant si l'état
        # de l'objet est inversé dicSyntheseRT - une liste de dict
        # contenant l'adresse et le nom des synthèses défaut RT
        return dic_entrees, dic_synthese_rt

    def get_entrees(self):
        liste_entrees = []
        for objet in self.visualisation.objets:
            if objet.adresse.startswith("3/1/"):
                # N'ajoute pas les objets d'alarme différents du 3/1/1 ni override
                if (
                    objet.adresse == "3/1/1"
                    or not "simulation" in objet.name.lower()
                    and not "relance" in objet.name.lower()
                    and not "libre" in objet.name.lower()
                    and not "override" in objet.name.lower()
                ):
                    if (
                        not objet.name.startswith(
                            self.visualisation.data_translated["entree"] + " #"
                        )
                        and "dry contact" not in objet.name.lower()
                    ):
                        liste_entrees.append(int(objet.adresse.split("/")[2]))

        liste_entrees.sort()  # tri par adresse croissante
        liste_entrees = ["3/1/" + str(element) for element in liste_entrees]
        return liste_entrees

    def former(
        self,
        id_entrees=None,
        id_pilotages=None,
        id_temp_cvc=None,
        id_pds=None,
        id_prog_hor=None,
        retour="",
    ):
        if self.name == "Warning":
            self.background = "bordel.png"
            self.visualisation.create_link(
                parent=self.name, target="Menu", locx=632, locy=481, type="vide"
            )

        # Menu
        if self.name == "Menu":
            if self.visualisation.client == "Brico Dépôt":
                self.background = "BDmenuvierge.png"
            elif self.visualisation.client == "Castorama":
                self.background = "menucastofinal.png"
            elif self.visualisation.client == "Carrefour":
                self.background = "background_carrefour.png"
            elif self.visualisation.client == "Bricoman":
                self.background = "background_bricoman.png"
            elif self.visualisation.client == "Leroy Merlin":
                self.background = "VisuLeroyMerlin.png"
            elif self.visualisation.client == "NOZ":
                self.background = "menu_NOZ.png"
            elif self.visualisation.client == "Ahorramas":
                self.background = "MenuAhorramas.png"
            elif self.visualisation.client == "Argan":
                self.background = "MenuArgan.png"
            elif self.visualisation.client == "SNCF":
                self.background = "MenuSNCF.png"
            elif self.visualisation.client == "Cultura":
                self.background = "fond_cultura.png"
            else:
                self.background = ""
            # Ajout du nom du site
            if self.visualisation.client in ("Carrefour", "Cultura", "Bricoman"):
                locy_titre = 245
            else:
                locy_titre = 185
            if self.visualisation.client not in ("Argan", "NOZ"):
                self.visualisation.create_text(
                    parent="Menu",
                    text=self.visualisation.nomdusite,
                    locx=centered_on(
                        coord_x=self.width / 2,
                        name=self.visualisation.nomdusite,
                        ppc=10,
                    ),
                    locy=locy_titre,
                    size=25,
                )

            if self.visualisation.client in ("Carrefour", "Cultura", "Bricoman"):
                self.visualisation.create_text(
                    parent="Menu",
                    text=self.visualisation.data_translated["detail_pilotages"],
                    locx=38,
                    locy=435,
                    size=23,
                )
                self.visualisation.create_text(
                    parent="Menu",
                    text=self.visualisation.data_translated["detail_entrees"],
                    locx=298,
                    locy=435,
                    size=23,
                )
                self.visualisation.create_text(
                    parent="Menu",
                    text=self.visualisation.data_translated["temp"],
                    locx=546,
                    locy=435,
                    size=23,
                )
                self.visualisation.create_link(
                    parent="Menu",
                    target=self.visualisation.data_translated[
                        "detail_pilotages"
                    ],  # Ampoule pour pilotages
                    locx=90,
                    locy=335,
                    nobg=1,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien", size=90, icone_on="bulb-FFFFFF-0091EA.svg"
                    ),
                )
                self.visualisation.create_link(
                    parent="Menu",
                    target=self.visualisation.data_translated["detail_entrees"],
                    locx=350,
                    locy=335,
                    nobg=1,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien", size=90, icone_on="bell-FFFFFF-0091EA.svg"
                    ),
                )
                self.visualisation.create_link(
                    parent="Menu",
                    target=self.visualisation.data_translated["temperatures"],
                    locx=600,
                    locy=335,
                    nobg=1,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien",
                        size=90,
                        icone_on="temperature-degrees-FFFFFF-0091EA.svg",
                    ),
                )

                self.visualisation.create_text(
                    parent="Menu",
                    text="Besoin d'assistance au pilotage ?",
                    locx=520,
                    locy=577,
                    size=20,
                )
                self.visualisation.create_text(
                    parent="Menu",
                    text="Envoyez un mail à : energycenter@eficia.com",
                    locx=472,
                    locy=606,
                    size=20,
                )
                self.visualisation.create_text(
                    parent="Menu", text="01 83 640 640", locx=619, locy=636, size=17
                )
                self.visualisation.create_text(
                    parent="Menu",
                    text=self.visualisation.data_translated["to_prog_horaires"],
                    locx=786,
                    locy=435,
                    size=23,
                )
                self.visualisation.create_link(  # Programmes horaires
                    parent="Menu",
                    target=self.visualisation.data_translated["programmes_horaires"],
                    locx=858,
                    locy=335,
                    nobg=1,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien", size=90, icone_on="scheduler.svg"
                    ),
                )
                self.visualisation.create_link(  # Menu CVC
                    parent="Menu",
                    target=self.visualisation.data_translated["menu_rt"],
                    locx=1110,
                    locy=335,
                    nobg=1,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien", size=90, icone_on="fan-FFFFFF-0091EA.svg"
                    ),
                )
                self.visualisation.create_text(
                    parent="Menu",
                    text=self.visualisation.data_translated["to_menu_rt"],
                    locx=1080,
                    locy=435,
                    size=23,
                )
            elif self.visualisation.client in ("Cultura"):
                self.visualisation.create_link(  # Menu CVC
                    parent="Menu",
                    target=self.visualisation.data_translated["menu_rt"],
                    locx=858,
                    locy=335,
                    nobg=1,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien", size=90, icone_on="fan-FFFFFF-0091EA.svg"
                    ),
                )
                self.visualisation.create_text(
                    parent="Menu",
                    text=self.visualisation.data_translated["to_menu_rt"],
                    locx=817,
                    locy=435,
                    size=23,
                )

            elif self.visualisation.client not in ("Argan", "NOZ"):
                # Ajout des liens du menu sous forme de texte
                params = gen_parameters(type_objet="lien_texte")
                if self.visualisation.client not in ("SNCF"):
                    self.objects.append(
                        Object(
                            object=id_pds,
                            name=self.visualisation.data_translated["plan_du_site"],
                            type=2,
                            id=len(self.objects) + 1,
                            floor=self.id,
                            locx=578,
                            locy=280,
                            params=params[0],
                            nobg=1,
                        )
                    )

                if self.visualisation.client not in [
                    "Leroy Merlin",
                    "Bauhaus",
                    "Ahorramas",
                ]:
                    self.objects.append(
                        Object(
                            object=id_prog_hor,
                            name=self.visualisation.data_translated[
                                "programmes_horaires"
                            ],
                            type=2,
                            id=len(self.objects) + 1,
                            floor=self.id,
                            locx=527,
                            locy=520,
                            params=params[0],
                            nobg=1,
                        )
                    )

                self.objects.append(
                    Object(
                        object=id_temp_cvc,
                        name=self.visualisation.data_translated["temperatures"],
                        type=2,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=569,
                        locy=340,
                        params=params[0],
                        nobg=1,
                    )
                )

                if self.visualisation.client not in ("SNCF"):
                    self.objects.append(
                        Object(
                            object=id_entrees,
                            name=self.visualisation.data_translated["detail_defauts"],
                            type=2,
                            id=len(self.objects) + 1,
                            floor=self.id,
                            locx=545,
                            locy=400,
                            params=params[0],
                            nobg=1,
                        )
                    )

                self.objects.append(
                    Object(
                        object=id_pilotages,
                        name=self.visualisation.data_translated["detail_pilotages"],
                        type=2,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=537,
                        locy=460,
                        params=params[0],
                        nobg=1,
                    )
                )

        # Smart Dali Lon Bacnet
        if self.name == "Salle de Vente - Dali":
            # Detection type dali
            flag_break = False
            for objet in self.visualisation.objets:
                for tag in objet.tags:
                    if tag == "DELTADORE_MODE_ALL":
                        self.visualisation.dali_lon_bacnet = True
                        print("Détection du type de dali : Dali Deltadore")
                        flag_break = True
                        break
                    if tag.find("PHILIPS") != -1:
                        self.visualisation.dali_philips = True
                        print("Détection du type de dali : Dali Philips")
                        flag_break = True
                        break
                if flag_break:
                    break

            liste_dali = []
            liste_zones = []

            if self.visualisation.dali_philips or self.visualisation.dali_lon_bacnet:
                for objet in self.visualisation.objets:
                    if (
                        "DALI_CMD" in objet.tags
                        and "SMART_DALI" in objet.tags
                        and not re.match(r"^CMD_Dali_Command_\d+$", objet.name)
                    ):
                        for tag in objet.tags:
                            if tag.startswith("ZONE_"):
                                liste_zones.append(tag)
                        liste_dali.append(objet.adresse)
            if self.visualisation.client in ("Carrefour", "Bricoman"):
                self.placer_liste(liste_dali, "dali", 60, 150)
            else:
                self.placer_liste(liste_dali, "dali")
            zone_principale = most_common(liste_zones)
            print("zone_principale", zone_principale)
            params = [
                gen_parameters_v2(
                    type_objet="icone_valeur",
                    size=47,
                    icone_on="weather-sun-FFFFFF-0091EA.svg",
                    fontsize=16,
                ),
                0,
            ]
            for obj in self.visualisation.objets:
                if zone_principale in obj.tags and "DALI_STOCKLIGHT" in obj.tags:
                    self.visualisation.create_text(
                        parent=self.name,
                        text="Seuil bas d'intensité (heures silencieuses et personnel)",
                        locx=780,
                        locy=160,
                        size=20,
                    )
                    self.visualisation.create_object(
                        parent=self.name,
                        type_other=1,
                        knx=obj.adresse,
                        locx=990,
                        locy=200,
                        params_to_use=gen_parameters_v2(
                            type_objet="icone_valeur",
                            font="Poppins",
                            fontsize=20,
                            icone_on="weather-sun-FFFFFF-0091EA.svg",
                            width=56,
                            height=56,
                        ),
                        other=True,
                        readonly=0,
                    )
                elif zone_principale in obj.tags and "DALI_TRADELIGHT" in obj.tags:
                    self.visualisation.create_text(
                        parent=self.name,
                        text="Seuil haut d'intensité (heures client)",
                        locx=840,
                        locy=390,
                        size=20,
                    )
                    self.visualisation.create_object(
                        parent=self.name,
                        type_other=1,
                        knx=obj.adresse,
                        locx=990,
                        locy=430,
                        params_to_use=gen_parameters_v2(
                            type_objet="icone_valeur",
                            font="Poppins",
                            fontsize=20,
                            icone_on="weather-sun-FFFFFF-0091EA.svg",
                            width=56,
                            height=56,
                        ),
                        other=True,
                        readonly=0,
                    )

        if self.name == self.visualisation.data_translated["detail_pilotages"]:
            if self.visualisation.client in (
                "Carrefour",
                "Fnac",
                "Cultura",
                "Bricoman",
            ):
                liste_cvc = self.get_sorties_cvc()
                for plan in self.visualisation.plans:
                    if plan.name == "Menu CVC":
                        plan.placer_liste(liste=liste_cvc, obj_type="pilotages")
                        break
            if self.visualisation.client not in ("SNCF"):
                liste_sorties = self.get_sorties()
                self.placer_liste(liste=liste_sorties, obj_type="pilotages")
            else:
                self.placer_liste(
                    liste=liste_sorties, obj_type="pilotages", x=160, y=150
                )
                liste_entrees = self.get_entrees()
                self.placer_liste(liste=liste_entrees, obj_type="entrees", x=550, y=150)

        if self.name == self.visualisation.data_translated["detail_defauts"]:
            dic_entrees, dic_synthese_rt = self.get_defauts()

            locx_icone = 90
            locy_icone = 120
            locx_texte = locx_icone + 35
            locy_texte = locy_icone - 3
            increment = 30

            params = None
            for defaut in dic_entrees.values():
                if defaut["inverted"] == 0:
                    # icone classique cloche
                    params = [
                        gen_parameters_v2(
                            size=22, icone_on="bell_on.svg", icone_off="bell_off.svg"
                        ),
                        1,
                    ]

                elif defaut["inverted"] == 1:
                    params = [
                        gen_parameters_v2(
                            size=22, icone_on="bell_off.svg", icone_off="bell_on.svg"
                        ),
                        1,
                    ]  # icone inversée

                else:
                    params = [
                        gen_parameters_v2(
                            size=22, icone_on="bell_on.svg", icone_off="bell_off.svg"
                        ),
                        1,
                    ]  # icones normales

                # ajout de l'icone
                self.objects.append(
                    Object(
                        object=knx_to_id(defaut["adresse"]),
                        statusobject=knx_to_id(defaut["adresse"]),
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=locx_icone,
                        locy=locy_icone,
                        params=params[0],
                        readonly=params[1],
                    )
                )

                # ajout du nom
                self.visualisation.create_text(
                    parent=self.name,
                    text=defaut["name"],
                    locx=locx_texte,
                    locy=locy_texte,
                    size=18,
                )

                if locy_icone < 485:
                    locy_icone += increment
                    locy_texte += increment
                else:
                    locy_icone = 120
                    locy_texte = locy_icone - 3
                    locx_icone += 640  # distance horizontale entre 2 colonnes
                    locx_texte += 640  # distance horizontale entre 2 colonnes

            if len(dic_synthese_rt) > 0:  # si des syntheses RT sont trouvées
                cpt = 1
                locx_icone = 90
                locy_icone = 600
                locx_texte = locx_icone + 35
                locy_texte = locy_icone - 3
                increment = 40

                self.visualisation.create_text(
                    parent=self.name,
                    text="Synthèses défaut Rooftop",
                    locx=90,
                    locy=540,
                    size=22,
                )

                for synthese in dic_synthese_rt:
                    if synthese["datatype"] == 1:
                        params = [
                            gen_parameters_v2(
                                size=22,
                                icone_on="bell_off.svg",
                                icone_off="bell_on.svg",
                            ),
                            1,
                        ]
                    else:
                        params = (
                            gen_parameters_v2(
                                type_objet="icones_add",
                                width=22,
                                height=22,
                                icone_default="bell_off.svg",
                                icones_add=[
                                    [0, "bell_off.svg"],
                                    [1, "bell_on.svg"],
                                ],
                            ),
                            1,
                        )
                    # ajout de l'icone
                    self.objects.append(
                        Object(
                            object=knx_to_id(synthese["adresse"]),
                            statusobject=knx_to_id(synthese["adresse"]),
                            id=len(self.objects) + 1,
                            floor=self.id,
                            locx=locx_icone,
                            locy=locy_icone,
                            params=params[0],
                            readonly=params[1],
                        )
                    )

                    # ajout du nom
                    self.visualisation.create_text(
                        parent=self.name,
                        text=clean_single_rt_name(synthese["nom"]),
                        locx=locx_texte,
                        locy=locy_texte,
                        size=18,
                    )

                    cpt += 1

                    if locy_icone < 715:
                        locy_icone += increment
                        locy_texte += increment
                    else:
                        locx_icone = 90
                        locy_icone = 600
                        locx_texte = locx_icone + 35
                        locy_texte = locy_icone - 3
                        locx_icone += 500
                        locx_texte += 500

        if self.name == self.visualisation.data_translated["detail_entrees"]:
            liste_entrees = self.get_entrees()
            self.placer_liste(liste=liste_entrees, obj_type="entrees")

        if self.name == self.visualisation.data_translated["plan_du_site"]:
            if self.visualisation.client not in ("Argan", "NOZ", "Bils-Deroo"):
                self.visualisation.create_text(
                    parent=self.visualisation.data_translated["plan_du_site"],
                    text="Alarme MES/MHS",
                    size=20,
                    locx=1117,
                    locy=286,
                )
                # Ajout des objets Alarme et Intrusion et le texte correspondant
                # Icone cloche alarme
                params = gen_parameters(type_objet="cloche_intrusion")
                knx = "3/1/1"
                self.objects.append(
                    Object(
                        object=knx_to_id(knx),
                        statusobject=knx_to_id(knx),
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=1047,
                        locy=274,
                        params=params[0],
                        readonly=params[1],
                    )
                )

                # Icone cadenas intrusion
                params = gen_parameters(type_objet="cadenas_alarme")
                knx = "3/1/2"
                self.objects.append(
                    Object(
                        object=knx_to_id(knx),
                        statusobject=knx_to_id(knx),
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=1047,
                        locy=336,
                        params=params[0],
                        readonly=params[1],
                    )
                )

                params = gen_parameters(type_objet="text_20")  # Texte Intrusion
                self.objects.append(
                    Object(
                        name="Intrusion",
                        type=6,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=1117,
                        locy=351,
                        params=params[0],
                        nobg=1,
                    )
                )

                # Ajout de l'image du cadre pour les éclairages
                parent = self.visualisation.data_translated["plan_du_site"]
                self.visualisation.create_image(
                    parent=parent,
                    locx=1060,
                    locy=410,
                    image="cadre-allumage-new.png",
                    width=279,
                    height=221,
                )

                # Objet delta coucher/lever soleil
                self.visualisation.create_object(
                    parent=parent,
                    type_other=1,
                    knx="6/1/37",
                    locx=1124,
                    locy=494,
                    params_to_use=gen_parameters_v2(
                        type_objet="valeur",
                        font="Poppins Medium",
                        fontsize=20,
                        color="#1BA3EF",
                    ),
                    other=True,
                    readonly=0,
                )

                self.visualisation.create_object(
                    parent=parent,
                    type_other=1,
                    knx="6/1/39",
                    locx=1148,
                    locy=574,
                    params_to_use=gen_parameters_v2(
                        type_objet="valeur",
                        font="Poppins Medium",
                        fontsize=20,
                        color="#1BA3EF",
                    ),
                    other=True,
                    readonly=0,
                )

            # Détermine la liste des plans pour lesquels il faut ajouter un
            # lien sur le menu

            listetotale = []
            listeremove = [
                "Warning",
                "Menu",
                self.visualisation.data_translated["plan_du_site"],
                self.visualisation.data_translated["detail_entrees"],
                self.visualisation.data_translated["detail_defauts"],
                self.visualisation.data_translated["detail_pilotages"],
                self.visualisation.data_translated["temperatures"],
                "Salle de Vente - Dali",
                self.visualisation.data_translated["programmes_horaires"],
                self.visualisation.data_translated["menu_rt"],
            ]
            if self.visualisation.client in ("Argan", "NOZ"):
                listeremove.append(self.visualisation.data_translated["exterieur"])
            for plan2 in self.visualisation.plans:
                listetotale.append(plan2.name)

            listeraccourcis = [
                raccourci
                for raccourci in listetotale
                if raccourci.find("CVC") == -1
                and raccourci not in listeremove
                and not re.findall(r"\d+", raccourci)
            ]
            locx = 70
            locy = 300
            for raccourci in listeraccourcis:
                nomcut = raccourci.split(" - ")[0]

                self.visualisation.create_link(
                    parent=self.visualisation.data_translated["plan_du_site"],
                    cls="",
                    target=raccourci,
                    locy=locy,
                    locx=locx,
                    type="lien_texte",
                    nobg=0,
                    nom_custom=nomcut,
                )
                if locx > 760:
                    locx = 70
                    locy += 130
                else:
                    locx += 170

        if self.name == self.visualisation.data_translated["temperatures"]:
            liste_temperatures = []

            for objet in self.visualisation.objets:
                for tag in objet.tags:
                    if tag in ["TEMPERATURE", "HUMIDITE", "CO2"]:
                        liste_temperatures.append(objet.adresse)

            self.ajout_temperatures(liste_temperatures)

        if self.name.startswith("Chaufferie"):
            # ajout du lien
            result = re.findall(r"\d+", self.name)
            if result:
                numero = int(result[-1])
            else:
                numero = 1
            flag_ajout_lien = False
            for plan in self.visualisation.plans:
                if plan.name == "Locaux techniques":
                    flag_ajout_lien = True
                    params = gen_parameters(type_objet="lien_texte")
                    plan.objects.append(
                        Object(
                            object=self.id,
                            cls="",
                            type=2,
                            id=len(self.objects) + 1,
                            floor=plan.id,
                            locx=150 * numero,
                            locy=668,
                            params=params[0],
                            nobg=0,
                        )
                    )

            if not flag_ajout_lien:
                for plan in self.visualisation.plans:
                    if plan.name == "Plan du site":
                        params = gen_parameters_v2(type_objet="lien_texte", fontsize=20)
                        plan.objects.append(
                            Object(
                                object=self.id,
                                cls="",
                                type=2,
                                id=len(self.objects) + 1,
                                floor=plan.id,
                                locx=150 * numero,
                                locy=668,
                                params=params,
                                nobg=0,
                            )
                        )

            nom_chaufferie = (
                self.name.lower().split("chaufferie")[1].capitalize().strip()
            )
            # ajout de lien vers la page Menu CVC
            self.visualisation.create_link(
                parent=self.visualisation.data_translated["menu_rt"],
                target=self.name,
                locx=80,
                locy=180,
                type="Chaufferie",
                nobg=0,
            )
            self.visualisation.create_link(
                parent=self.name,
                target=self.visualisation.data_translated["menu_rt"],
                locx=24,
                locy=15,
                genparams=True,
                params_to_use=gen_parameters_v2(
                    type_objet="lien", width=17, height=32, icone_on="retour.svg"
                ),
            )
            listedepart = []
            listeretour = []
            flag_temp_depart = False
            for objet in self.visualisation.objets:
                # Cherche le numéro ou nom de la chaufferie
                if nom_chaufferie in objet.name.lower():
                    # Cherche le tag TEMP_DEPART
                    for tag in objet.tags:
                        if tag == "TEMP_DEPART":
                            print(f"{nom_chaufferie} - Température départ ajoutée")
                            listedepart.append(objet.adresse)
                            flag_temp_depart = True

                if not flag_temp_depart:
                    # Cherche les objets en 3/*/* ou 4/*/* dont le nom
                    # contient 'départ' ou 'depart' de façon case insensitive.
                    if (
                        objet.adresse.startswith("3/") or objet.adresse.startswith("4/")
                    ) and nom_chaufferie in objet.name.lower():
                        if (
                            re.search("depart", objet.name, re.IGNORECASE)
                            or re.search("départ", objet.name, re.IGNORECASE)
                            or re.search("aller", objet.name, re.IGNORECASE)
                        ):
                            listedepart.append(objet.adresse)
                            print(
                                f"{nom_chaufferie} - Température départ potentielle ajoutée"
                            )
                            retour += (
                                "\nChaufferie - Température départ potentielle ajoutée"
                            )

                if (
                    objet.adresse.startswith("3/") or objet.adresse.startswith("4/")
                ) and nom_chaufferie in objet.name.lower():
                    if re.search("retour", objet.name, re.IGNORECASE) and (
                        re.search("temp", objet.name, re.IGNORECASE)
                        or re.search("sonde", objet.name, re.IGNORECASE)
                    ):
                        listeretour.append(objet.adresse)
                        print(
                            f"{nom_chaufferie} - Température retour potentielle ajoutée"
                        )
                        retour += (
                            "\nChaufferie - Température retour potentielle ajoutée"
                        )

            # Cas souhaitable, l'objet a été trouvé
            if len(listedepart) >= 1:
                # Ajout de l'icone et description de l'objet température départ
                params = gen_parameters(type_objet="temperature_texte")
                self.objects.append(
                    Object(
                        object=knx_to_id(listedepart[0]),
                        statusobject=knx_to_id(listedepart[0]),
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=112,
                        locy=300,
                        params=params[0],
                        readonly=1,
                    )
                )
                params = gen_parameters(type_objet="text_20")
                self.objects.append(
                    Object(
                        name="Température départ",
                        type=6,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=46,
                        locy=260,
                        params=params[0],
                        nobg=1,
                    )
                )

                if len(listedepart) > 1:
                    print("\nPlusieurs objets de température aller ont été détectés : ")
                    retour += (
                        "\nPlusieurs objets de température aller ont été détectés : "
                    )
                    for objet in listedepart:
                        print(" - " + str(objet))
                        retour += f"\n - {str(objet)}"

                    print(
                        "le premier a été mis sur la visualisation"
                        + "mais vérifier qu'il s'agit du bon."
                    )
                    retour += "\nle premier a été mis sur la visualisation mais vérifier qu'il s'agit du bon."

            # Aucun objet trouvé selon les critères de recherche.
            elif len(listedepart) == 0:
                print(
                    f"{nom_chaufferie} - Aucun objet de température aller n'a été trouvé,"
                    "regarder sur l'harmony et l'ajouter manuellement s'il existe."
                )
                retour += (
                    "\nChaufferie - Aucun objet de température aller n'a été trouvé,"
                    "regarder sur l'harmony et l'ajouter manuellement s'il existe."
                )

            # Idem pour température retour

            if len(listeretour) >= 1:
                # Ajout de l'icone et description de l'objet température retour
                params = gen_parameters(type_objet="temperature_texte")
                self.objects.append(
                    Object(
                        object=knx_to_id(listeretour[0]),
                        statusobject=knx_to_id(listeretour[0]),
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=112,
                        locy=450,
                        params=params[0],
                        readonly=1,
                    )
                )
                params = gen_parameters(type_objet="text_20")
                self.objects.append(
                    Object(
                        name="Température retour",
                        type=6,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=50,
                        locy=410,
                        params=params[0],
                        nobg=1,
                    )
                )

                if len(listeretour) > 1:
                    print(
                        f"{nom_chaufferie} - Plusieurs objets de température retour ont été détectés : "
                    )
                    retour += "\nChaufferie - Plusieurs objets de température retour ont été détectés : "
                    for objet in listeretour:
                        print(" - " + str(objet))
                        retour += "\n - " + str(objet)
                    print(
                        "le premier a été mis sur la visualisation mais vérifier qu'il s'agit du bon."
                    )
                    retour += "le premier a été mis sur la visualisation mais vérifier qu'il s'agit du bon."
            elif len(listeretour) == 0:
                print(
                    f"{nom_chaufferie} - Aucun objet de température retour n'a été trouvé,"
                    "regarder sur l'harmony et l'ajouter manuellement s'il existe."
                )
                retour += (
                    "\nChaufferie - Aucun objet de température retour n'a été trouvé,"
                    "regarder sur l'harmony et l'ajouter manuellement s'il existe."
                )

            # Ajout des pilotages sur la page chaufferie
            listepilotages = []
            listeremontees = []
            for objet in self.visualisation.objets:
                if nom_chaufferie in objet.name.lower() and any(
                    word in unidecode(objet.name.lower())
                    for word in (
                        "pompe",
                        "chaufferie",
                        "chaudiere",
                        "chaudière",
                        " eau",
                        "bruleur",
                    )
                ):
                    if objet.adresse.startswith("1/"):
                        listepilotages.append(objet)
                    elif objet.adresse.startswith("3/"):
                        listeremontees.append(objet)

            # Ajout des pilotages
            locx_icone = 495
            locy_icone = 166
            locx_texte = locx_icone
            locy_texte = 142
            decalage_valeur_not_bool = locx_icone + 35

            for obj in listepilotages:
                # Icone pilotage
                if is_obj_boolean(obj.datatype):
                    params = gen_parameters(type_objet="toggle")
                    locx_icone = 495
                else:
                    params = gen_parameters(type_objet="ROOF_TEXT")
                    locx_icone = decalage_valeur_not_bool
                self.objects.append(
                    Object(
                        object=obj.address,
                        statusobject=obj.address,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=locx_icone,
                        locy=locy_icone,
                        params=params[0],
                        readonly=0,
                    )
                )

                # Texte pilotage
                params = gen_parameters(type_objet="text_20")
                self.objects.append(
                    Object(
                        name=remove_parentheses(obj.name),
                        type=6,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=centered_on(
                            coord_x=562, name=remove_parentheses(obj.name), ppc=10
                        ),
                        locy=locy_texte,
                        params=params[0],
                        nobg=1,
                    )
                )
                if locy_icone <= 700:
                    if len(listepilotages) < 4:
                        locy_icone += 100
                        locy_texte += 100
                    else:
                        locy_icone += 80
                        locy_texte += 80
                else:
                    print(
                        "\nChaufferie - Manque d'espace pour ajouter plus de pilotages,"
                        "veuillez régler ce problème manuellement."
                    )
                    retour += (
                        "\nChaufferie - Manque d'espace pour ajouter plus de pilotages,"
                        "veuillez régler ce problème manuellement."
                    )

                    break

            # Ajout des remontees
            locx_icone = 845
            locy_icone = 130
            locx_texte = 900
            locy_texte = 138

            for obj in listeremontees:
                # Icone remontee
                params = gen_parameters(type_objet="icone_entrees")
                self.objects.append(
                    Object(
                        object=obj.address,
                        statusobject=obj.address,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=locx_icone,
                        locy=locy_icone,
                        params=params[0],
                        readonly=1,
                    )
                )

                # Texte remontee
                params = gen_parameters(type_objet="text_20")
                self.objects.append(
                    Object(
                        name=remove_parentheses(obj.name),
                        type=6,
                        id=len(self.objects) + 1,
                        floor=self.id,
                        locx=locx_texte,
                        locy=locy_texte,
                        params=params[0],
                        nobg=1,
                    )
                )
                if locy_icone <= 700:
                    locy_icone += 60
                    locy_texte += 60
                else:
                    print(
                        "\nChaufferie - Manque d'espace pour ajouter plus de pilotages,"
                        "veuillez régler ce problème manuellement."
                    )
                    retour += "\nChaufferie - Manque d'espace pour ajouter \
                    plus de pilotages, veuillez régler ce problème manuellement."
                    break

        if self.name == self.visualisation.data_translated["exterieur"]:
            for objet in self.visualisation.objets:
                if objet.adresse.startswith("1/1/"):
                    for tag in objet.tags:
                        if (
                            tag == "PARKING"
                            or tag == "ENSEIGNE"
                            or tag.find("NUIT") != -1
                        ):
                            print(
                                "Extérieur - Ajout automatique de l'objet "
                                + objet.adresse
                                + " à partir du tag "
                                + tag
                            )
                            retour += (
                                "\nExtérieur - Ajout automatique de l'objet "
                                + objet.adresse
                                + " à partir du tag "
                                + tag
                            )
                            self.visualisation.create_object(
                                parent=self.name,
                                knx=objet.adresse,
                                name=True,
                                type="light",
                            )
                            break
