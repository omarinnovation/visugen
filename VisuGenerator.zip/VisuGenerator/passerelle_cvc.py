"""Module contenant les classes représentant les passerelles de climatisation connectées
à un Harmony."""
import math
from eficia_utils.harmony.connected_device import ConnectedDevice, DeviceModbus


class PasserelleCVC:
    """Représente une passerelle de climatisation connectée à un Harmony."""

    def __init__(
        self, device: ConnectedDevice, type_passerelle: str, units_per_page: int = 10
    ):
        self.device = device
        self.type_passerelle = type_passerelle
        self.units_per_page = units_per_page
        self.units = self.get_units()
        self.num_pages = (len(self.units) - 1) // self.units_per_page + 1

    def get_units(self) -> list:
        return []


class CoolMasterNet(PasserelleCVC):
    """Représente une passerelle CoolMasterNet connectée à un Harmony."""

    def __init__(self, device: DeviceModbus, **kwargs):
        super().__init__(device, type_passerelle="COOLMASTERNET", **kwargs)

    def get_units(self):
        registres = set(
            ligne.mb_reg_addr
            for ligne in self.device.mapping
            if ligne.device == self.device and ligne.mb_reg_addr is not None
        )
        unites = set(registre // 16 for registre in registres)
        toreturn = [UniteCoolMaster(self, num_unit) for num_unit in unites]
        return toreturn


class Panasonic_SG_1050(PasserelleCVC):
    """Représente une passerelle Panasonic SG-1050 connectée à un Harmony."""

    def __init__(self, device: DeviceModbus, **kwargs):
        super().__init__(device, type_passerelle="PANASONIC_SG_1050", **kwargs)

    def get_units(self):
        registres = set(
            ligne.mb_reg_addr
            for ligne in self.device.harmony.mapping
            if ligne.device == self.device and ligne.mb_reg_addr is not None
        )
        unites = set(registre // 100 for registre in registres)
        print(unites)
        toreturn = [UnitPanasonicSG1050(self, num_unit) for num_unit in unites]
        return toreturn


class DaikinDIIINet(PasserelleCVC):
    """Représente une passerelle Daikin DIII-NET connectée à un Harmony."""

    def __init__(self, device: DeviceModbus, **kwargs):
        super().__init__(device, type_passerelle="DAIKIN DIII-NET", **kwargs)

    def get_units(self):
        units = []
        for ligne in self.device.mapping:
            if (
                ligne.modbus_type == "inputregister"
                and ligne.mb_reg_addr >= 1
                and ligne.mb_reg_addr <= 4
            ):
                upper_address = ligne.mb_reg_addr
                lower_address = int(math.log2(ligne.value_bitmask))
                new_unit = UniteDaikinDIIINet(self, upper_address, lower_address)
                units.append(new_unit)
        return units


class UniteCoolMaster:
    """Représente une unité de climatisation connectée à une passerelle CoolMasterNet"""

    # REFERENCE: https://www.coolautomation.wiki/index.php?title=Modbus_IP
    # https://coolautomation.com/wp-content/uploads/sites/2/2021/04/Modbus-guidelines.pdf
    registres_coolmaster = [
        {"modbus_type": "register", "offset": 0, "description": "Operation Mode"},
        {"modbus_type": "register", "offset": 1, "description": "Fan Speed"},
        {"modbus_type": "register", "offset": 2, "description": "Set temperature"},
        {"modbus_type": "register", "offset": 4, "description": "Filter Sign"},
        {"modbus_type": "register", "offset": 5, "description": "Swing"},
        {"modbus_type": "register", "offset": 6, "description": "Room temperature"},
        {
            "modbus_type": "register",
            "offset": 7,
            "description": "HVAC Malfunction Code",
        },
        {
            "modbus_type": "register",
            "offset": 8,
            "description": "Local Wall Controller",
        },
        {
            "modbus_type": "register",
            "offset": 9,
            "description": "Set temperature limits",
        },
        {"modbus_type": "inputregister", "offset": 0, "description": "UID Ln.XYY"},
        {
            "modbus_type": "inputregister",
            "offset": 1,
            "description": "Room temperature",
        },
        {
            "modbus_type": "inputregister",
            "offset": 2,
            "description": "HVAC Malfunction code 1",
        },
        {
            "modbus_type": "inputregister",
            "offset": 3,
            "description": "HVAC Malfunction code 2",
        },
        {
            "modbus_type": "inputregister",
            "offset": 4,
            "description": "Set temperature (read)",
        },
        {"modbus_type": "inputregister", "offset": 13, "description": "Analog Input 1"},
        {"modbus_type": "inputregister", "offset": 14, "description": "Analog Input 2"},
        {"modbus_type": "coil", "offset": 0, "description": "On/Off"},
        {"modbus_type": "coil", "offset": 1, "description": "Filter Sign"},
        {
            "modbus_type": "coil",
            "offset": 2,
            "description": "External Terminals Status (read only)",
        },
        {"modbus_type": "coil", "offset": 3, "description": "Inhibit"},
        {"modbus_type": "coil", "offset": 9, "description": "Digital Output 1"},
        {"modbus_type": "coil", "offset": 10, "description": "Digital Output 2"},
        {"modbus_type": "coil", "offset": 11, "description": "Digital Output 3"},
        {"modbus_type": "coil", "offset": 12, "description": "Digital Output 4"},
        {"modbus_type": "coil", "offset": 13, "description": "Digital Output 5"},
        {"modbus_type": "coil", "offset": 14, "description": "Digital Output 6"},
        {
            "modbus_type": "discreteinput",
            "offset": 0,
            "description": "Therm ON / Demand status",
        },
        {
            "modbus_type": "discreteinput",
            "offset": 1,
            "description": "Indoor communication failure",
        },
        {"modbus_type": "discreteinput", "offset": 9, "description": "Digital Input 1"},
        {
            "modbus_type": "discreteinput",
            "offset": 10,
            "description": "Digital Input 2",
        },
        {
            "modbus_type": "discreteinput",
            "offset": 11,
            "description": "Digital Input 3",
        },
        {
            "modbus_type": "discreteinput",
            "offset": 12,
            "description": "Digital Input 4",
        },
        {
            "modbus_type": "discreteinput",
            "offset": 13,
            "description": "Digital Input 5",
        },
        {
            "modbus_type": "discreteinput",
            "offset": 14,
            "description": "Digital Input 6",
        },
    ]

    def __init__(self, coolmaster: CoolMasterNet, num_unit: int):
        self.coolmaster = coolmaster
        self.num_unit = num_unit
        self.registres = [self.num_unit * 16 + i for i in range(16)]

        self.registres = []
        for base_register in self.registres_coolmaster:
            new_register = {
                "mb_reg_addr": self.num_unit * 16 + base_register["offset"],
                "modbus_type": base_register["modbus_type"],
                "description": base_register["description"],
            }
            self.registres.append(new_register)


class UnitPanasonicSG1050:
    """Représente une unité de climatisation connectée à une passerelle Panasonic SG-1050"""

    registres_panasonic_sg_1050 = [
        {"modbus_type": "register", "offset": 0, "description": "On/Off"},
        {"modbus_type": "register", "offset": 1, "description": "Operation Mode"},
        {"modbus_type": "register", "offset": 2, "description": "Fan Speed"},
        {"modbus_type": "register", "offset": 4, "description": "Set temperature"},
        {"modbus_type": "register", "offset": 5, "description": "Room temperature"},
        {
            "modbus_type": "register",
            "offset": 19,
            "description": "HVAC Malfunction Code",
        },
    ]

    def __init__(self, panasonic_sg_1050: Panasonic_SG_1050, num_unit: int):
        self.panasonic_sg_1050 = panasonic_sg_1050
        self.num_unit = num_unit
        self.registres = [self.num_unit * 100 + i for i in range(100)]

        self.registres = []
        for base_register in self.registres_panasonic_sg_1050:
            new_register = {
                "mb_reg_addr": self.num_unit * 100 + base_register["offset"],
                "modbus_type": base_register["modbus_type"],
                "description": base_register["description"],
            }
            self.registres.append(new_register)


class UniteDaikinDIIINet:
    """Représente une unité de climatisation connectée à une passerelle Daikin DIII-NET"""

    # REFERENCE: https://ecogtb365.sharepoint.com/sites/EFICIA/Documents%20partages/Forms/AllItems.aspx?id=%2Fsites%2FEFICIA%2FDocuments%20partages%2FChantier%5FField%20works%2FBureau%20d%27Etudes%5FDesign%20department%2FHarmony%2FModbus%2FModbus%20par%20script%2FDevices%20Modbus%20%28tables%20Excel%29%2FDaikin%20DIII%20%28Dk%20Grolee%29%2FModbus%20Interface%20III%20Design%20guide%5F4P357732%2D1%5FData%20books%5FEnglish%2Epdf&viewid=531be7ac%2D2464%2D42e9%2Da900%2D00f807315bea&parent=%2Fsites%2FEFICIA%2FDocuments%20partages%2FChantier%5FField%20works%2FBureau%20d%27Etudes%5FDesign%20department%2FHarmony%2FModbus%2FModbus%20par%20script%2FDevices%20Modbus%20%28tables%20Excel%29%2FDaikin%20DIII%20%28Dk%20Grolee%29
    registres_diii_net = [
        {
            "modbus_type": "register",
            "value_bitmask": 1,
            "step": 3,
            "offset": 2000,
            "description": "On/Off",
        },
        {
            "modbus_type": "register",
            "value_bitmask": 15,
            "step": 3,
            "offset": 2001,
            "description": "Operation Mode",
        },
        {
            "modbus_type": "register",
            "value_bitmask": 28672,
            "step": 3,
            "offset": 2000,
            "description": "Fan Speed",
        },
        {
            "modbus_type": "register",
            "value_bitmask": None,
            "step": 3,
            "offset": 2002,
            "description": "Set temperature",
        },
        {
            "modbus_type": "inputregister",
            "value_bitmask": None,
            "step": 6,
            "offset": 2004,
            "description": "Room temperature",
        },
        {
            "modbus_type": "inputregister",
            "value_bitmask": 65280,
            "step": 2,
            "offset": 3600,
            "description": "HVAC Malfunction Code",
        },
    ]

    def __init__(
        self, daikin_diii: DaikinDIIINet, upper_address: int, lower_address: int
    ):
        self.daikin_diii = daikin_diii
        self.upper_address = upper_address
        self.lower_address = lower_address
        self.unit_code = f"{self.upper_address}-{self.lower_address:02}"
        # internal number used for calculations : 1-00 -> 0, 1-01 -> 1, ..., 4-15 -> 63
        self.internal_number = 16 * (self.upper_address - 1) + self.lower_address
        self.num_unit = (
            self.internal_number + 1
        )  # 1-00 -> 1, 1-01 -> 2, ..., 4-15 -> 64
        self.registres = []
        for base_register in self.registres_diii_net:
            new_register = {
                "mb_reg_addr": self.internal_number * base_register["step"]
                + base_register["offset"],
                "modbus_type": base_register["modbus_type"],
                "description": base_register["description"],
                "value_bitmask": base_register["value_bitmask"],
            }
            self.registres.append(new_register)
