# -*- coding: utf-8 -*-
"""
Created on Fri Jan 13 15:38:45 2023

@author: RobinBourgeon
"""
import json
import re

from level import Level
from objectvisu import Object, Image
from passerelle_cvc import CoolMasterNet, Panasonic_SG_1050, DaikinDIIINet
from regin.bois_guillaume.regin_double_loop import DATA_BG
from regin.bois_guillaume.primaire import DATA_PRIMAIRE_BG
from regin.bois_guillaume.secondaire import DATA_SECONDAIRE_BG
from regin.fraize.regin_simple_loop import DATA_FRAIZE
from regin.fraize.primaire import DATA_PRIMAIRE_FRAIZE
from regin.fraize.secondaire import DATA_SECONDAIRE_FRAIZE
from regin.ham.regin_ham import DATA_HAM
from regin.ham.primaire import DATA_PRIMAIRE_HAM
from regin.ham.secondaire import DATA_SECONDAIRE_HAM
from regin.gargenville.regin_gargenville import DATA_GARGENVILLE
from regin.gargenville.secondaire import DATA_SECONDAIRE_GARGENVILLE
from plan import Plan
from utils import (
    gen_parameters,
    knx_to_id,
    gen_parameters_v2,
    find_duplicates,
    natural_keys,
    clean_rt_name,
    is_obj_boolean,
    process_name,
    generate_grid_coordinates,
    detect_location,
    window_location,
)


def exclude_data(obj):
    if isinstance(obj, Plan):
        keys_to_exclude = ["visualisation"]
    elif isinstance(obj, Visualisation):
        keys_to_exclude = [
            "client",
            "nomdusite",
            "rooftops_names",
            "name",
            "objets",
            "harmony",
            "dali_philips",
            "dali_lon_bacnet",
        ]
    else:
        keys_to_exclude = []
    dic = {}
    for key, value in obj.__dict__.items():
        if not keys_to_exclude or key not in keys_to_exclude:
            dic[key] = value
    return dic


class Visualisation:
    """Représente la visualisation à générer."""

    def __init__(
        self,
        name,
        client,
        nomdusite,
        harmony,
        dali_philips,
        dali_lon_bacnet,
        data_translated,
        regin_single_loop,
        regin_double_loop,
        regin_ham,
        regin_gargenville,
    ):
        self.id = 1
        self.client = client
        self.nomdusite = nomdusite
        self.name = name
        self.harmony = harmony
        self.dali_philips = dali_philips
        self.dali_lon_bacnet = dali_lon_bacnet
        self.data_translated = data_translated
        self.regin_single_loop = regin_single_loop
        self.regin_double_loop = regin_double_loop
        self.regin_ham = regin_ham
        self.regin_gargenville = regin_gargenville
        self.levels = []
        self.plans = []
        self.lws = []
        self.rooftops_names = []
        self.levels.append(Level(name=name))
        indexes_to_remove = []
        for index, obj in enumerate(self.harmony.objects):
            if obj.name is None:
                indexes_to_remove.append(index)
        self.objets = [
            obj
            for index, obj in enumerate(self.harmony.objects)
            if index not in indexes_to_remove
        ]
        self.create_plan(name="Menu", parent=name)
        self.create_plan(name=data_translated["detail_pilotages"], parent=name)
        if self.client not in (
            "Fnac",
            "Bils-Deroo",
            "Carrefour",
            "SNCF",
            "Cultura",
            "Bricoman",
        ):
            self.create_plan(name=data_translated["plan_du_site"], parent=name)
        self.create_plan(name=data_translated["temperatures"], parent=name)

        if self.client in (
            "Carrefour",
            "Bricoman",
            "Argan",
            "NOZ",
            "Leroy Merlin",
            "Fnac",
            "Cultura",
        ):
            if self.client != "Carrefour":
                self.create_plan(name=data_translated["detail_defauts"], parent=name)
            else:
                self.create_plan(name=data_translated["detail_entrees"], parent=name)
            self.create_plan(name=data_translated["menu_rt"], parent=name)
            if self.client not in ("Carrefour", "NOZ", "Argan", "Cultura", "Bricoman"):
                self.create_link(
                    parent="Menu",
                    target=data_translated["menu_rt"],
                    locx=587,
                    locy=510,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien_texte", fontsize=25
                    ),
                )
            elif client in ("NOZ", "Argan"):
                # TODO ajouter les liens vers le menu CVC
                ...
        if self.client not in ("Fnac", "Bils-Deroo", "SNCF", "Carrefour"):
            self.create_plan(name=data_translated["detail_entrees"], parent=name)
        if self.client not in ["Bauhaus", "Ahorramas"]:
            self.create_plan(name=data_translated["programmes_horaires"], parent=name)

    def to_json(self):
        """
        Traduit au format JSON la structure de données de la Visualisation afin
        de pouvoir l'importer sur l'automate.
        """
        return json.dumps(self, default=exclude_data, sort_keys=True, indent=4)

    def create_plan(
        self, name="", parent="", width=1360, background="page.png", add_return=True
    ):
        """Ajoute un objet de classe Plan à la visualisation"""
        for level in self.levels:
            if level.name == parent:
                building = level.id
                id = len(self.plans) + 1
                self.plans.append(
                    Plan(
                        visualisation=self,
                        id=id,
                        name=name,
                        building=building,
                        width=width,
                        background=background,
                    )
                )
                # new ajout du titre du plan
                for plan in self.plans:
                    if plan.name == name:
                        # Ajout du bouton retour et des textes (sauf sur les
                        # pages warning, Menu et Rooftops) Ne pas utiliser le
                        # motif classique pour les noms de
                        # plans précisés ici.
                        if plan.name != "Warning" and plan.name != "Menu":
                            if add_return:
                                # Ajout lien menu principal icone maison
                                self.create_link(
                                    parent=name,
                                    target="Menu",
                                    locx=1275,
                                    locy=9,
                                    genparams=True,
                                    params_to_use=gen_parameters_v2(
                                        type_objet="lien",
                                        width=47,
                                        height=45,
                                        icone_on="home.svg",
                                    ),
                                )
                            # Ajout du titre
                            locx_text = 84
                            if "Défauts Rooftop" not in plan.name:  # Tout
                                # sauf pages de défauts RT qui a un titre
                                # particulier
                                if (
                                    "Rooftop" in plan.name
                                    and plan.name != self.data_translated["menu_rt"]
                                ):
                                    rt_number = int(re.findall(r"\d+", plan.name)[0])
                                    name = (
                                        plan.name.split("Visu ")[1]
                                        + " : "
                                        + self.rooftops_names[rt_number - 1]
                                    )

                                self.create_text(
                                    parent=plan.name,
                                    text=name,
                                    locx=locx_text,
                                    locy=8,
                                    size=32,
                                    color="#FFFFFF",
                                    font="Poppins Medium",
                                )
                            else:
                                rt_number = int(re.findall(r"\d+", plan.name)[0])
                                # 11 = nb de pixels par caractère
                                self.create_text(
                                    parent=plan.name,
                                    text=name
                                    + " : "
                                    + self.rooftops_names[rt_number - 1],
                                    locx=locx_text,
                                    locy=8,
                                    size=32,
                                    color="#FFFFFF",
                                    font="Poppins Medium",
                                )

                            # test du nom pour modifier la target du lien (
                            # Menu ou Plan du site selon les plans)
                            liste_retour_menu = [
                                self.data_translated["plan_du_site"],
                                self.data_translated["programmes_horaires"],
                                self.data_translated["menu_rt"],
                                "Pilotages bureaux",
                            ]
                            if (
                                plan.name in liste_retour_menu
                                or plan.name.startswith(
                                    self.data_translated["temperatures"]
                                )
                                or plan.name.startswith(
                                    self.data_translated["detail_defauts"]
                                )
                                or plan.name.startswith(
                                    self.data_translated["detail_entrees"]
                                )
                                or plan.name.startswith(
                                    self.data_translated["detail_pilotages"]
                                )
                            ):
                                self.create_link(
                                    parent=name,
                                    target="Menu",
                                    locx=24,
                                    locy=15,
                                    genparams=True,
                                    params_to_use=gen_parameters_v2(
                                        type_objet="lien",
                                        width=17,
                                        height=32,
                                        icone_on="retour.svg",
                                    ),
                                )

                            elif "Cellule" in plan.name and "Eclairage" in plan.name:
                                try:
                                    numero_plan = int(re.findall(r"\d+", plan.name)[-1])
                                except IndexError:
                                    numero_plan = 0
                                # Ajout du retour vers le plan du site
                                locx = (numero_plan * 150) % 970
                                retenue = int((numero_plan * 150) / 970)
                                locy = 470 + retenue * 50
                                self.create_link(
                                    parent=name,
                                    target=self.data_translated["plan_du_site"],
                                    locx=24,
                                    locy=15,
                                    genparams=True,
                                    params_to_use=gen_parameters_v2(
                                        type_objet="lien",
                                        width=17,
                                        height=32,
                                        icone_on="retour.svg",
                                    ),
                                )
                                # ajout de lien de la page vers le plan du site
                                self.create_link(
                                    parent=self.data_translated["plan_du_site"],
                                    cls="",
                                    target=name,
                                    locy=locy,
                                    locx=locx,
                                    type="lien_texte",
                                    nobg=0,
                                    nom_custom=plan.name.split(" - ")[0],
                                )
                            # cas spécifique des pages de défaut de rooftop
                            # dont le bouton retour renvoie vers la page du
                            # RT associé
                            elif plan.name.find("Défauts Rooftop") != -1:
                                rt_number = re.findall(r"\d+", plan.name)
                                self.create_link(
                                    parent=name,
                                    target="Visu Rooftop " + str(rt_number[0]),
                                    locx=24,
                                    locy=15,
                                    genparams=True,
                                    params_to_use=gen_parameters_v2(
                                        type_objet="lien",
                                        width=17,
                                        height=32,
                                        icone_on="retour.svg",
                                    ),
                                )

                            elif plan.name == "Salle de Vente - Dali":
                                if "Salle de Vente - Pilotages" in [
                                    plan.name for plan in self.plans
                                ]:
                                    target = "Salle de vente - Pilotages"
                                else:
                                    target = "Détail des pilotages"
                                self.create_link(
                                    parent=name,
                                    target=target,
                                    locx=24,
                                    locy=15,
                                    genparams=True,
                                    params_to_use=gen_parameters_v2(
                                        type_objet="lien",
                                        width=17,
                                        height=32,
                                        icone_on="retour.svg",
                                    ),
                                )

                            # Cas d'une page de localisation (SDV, Bati, etc)
                            elif add_return:
                                self.create_link(
                                    parent=name,
                                    target=self.data_translated["plan_du_site"],
                                    locx=24,
                                    locy=15,
                                    genparams=True,
                                    params_to_use=gen_parameters_v2(
                                        type_objet="lien",
                                        width=17,
                                        height=32,
                                        icone_on="retour.svg",
                                    ),
                                )

    def create_text(
        self,
        parent="",
        text="",
        locx=100,
        locy=100,
        size=12,
        gras=0,
        color=None,
        font="Poppins",
    ):
        """Placer un texte sur la visualisation"""
        if not color:
            params = (
                '{"size":'
                + str(size)
                + ',"color":"","font":"'
                + font
                + '","bold":'
                + str(gras)
                + ',"italic":0,"underline":0}'
            )
        else:
            params = (
                '{"size":'
                + str(size)
                + ',"color":"'
                + str(color)
                + '","font":"'
                + font
                + '","bold":'
                + str(gras)
                + ',"italic":0,"underline":0}'
            )
        for plan in self.plans:
            if plan.name == parent:
                plan.objects.append(
                    Object(
                        name=text,
                        type=6,
                        id=len(plan.objects) + 1,
                        floor=plan.id,
                        locx=locx,
                        locy=locy,
                        params=params,
                        nobg=1,
                    )
                )

    def create_image(
        self, parent="", locx=10, locy=10, image="", width=None, height=None
    ):
        """Ajoute une image à la visualisation"""
        for plan in self.plans:
            if plan.name == parent:
                params = (
                    '{"source":"local","src":"'
                    + image
                    + '","width":"'
                    + str(width)
                    + '","height":"'
                    + str(height)
                    + '","link":"","refresh":""}'
                )

                plan.objects.append(
                    Image(
                        type=7,
                        id=len(plan.objects) + 1,
                        floor=plan.id,
                        locx=locx,
                        locy=locy,
                        params=params,
                        nobg=1,
                    )
                )

    def create_object(
        self,
        parent="",
        knx="1/1/1",
        other=False,
        type=None,
        type_other=None,
        locx=100,
        locy=100,
        name=None,
        params_to_use=None,
        params=None,
        readonly=None,
        cls="",
    ):
        """Ajoute un objet à la visualisation"""
        if not other:
            for plan in self.plans:
                if plan.name == parent:
                    id = len(plan.objects) + 1
                    locx, locy = generate_grid_coordinates(id)
                    params = gen_parameters(type_objet=type)
                    if self.client == "Leroy Merlin":
                        # Forcage en lecture seule pour tous les objets sur
                        # les LM
                        params[1] = 1
                    plan.objects.append(
                        Object(
                            object=knx_to_id(knx),
                            statusobject=knx_to_id(knx),
                            id=id,
                            floor=plan.id,
                            locx=locx,
                            locy=locy,
                            params=params[0],
                            readonly=params[1],
                            cls=cls,
                        )
                    )
                    if name:
                        # (ajoute automatiquement l'objet de nommage en texte
                        # en 9/*/* correspondant sous l'icône)
                        if knx.startswith("1/1/"):
                            adresse = knx.split("/")
                            knx = "9/1/" + adresse[2]
                        if knx.startswith("3/1/"):
                            adresse = knx.split("/")
                            knx = "9/3/" + adresse[2]
                        plan.objects.append(
                            Object(
                                object=knx_to_id(knx),
                                statusobject=knx_to_id(knx),
                                id=id,
                                floor=plan.id,
                                locx=locx - 70,
                                locy=locy + 70,
                                nobg=1,
                                params=gen_parameters_v2(
                                    type_objet="valeur", fontsize=18
                                ),
                                readonly=1,
                                cls="fond",
                            )
                        )
        else:  # if other
            for plan in self.plans:
                if plan.name == parent:
                    id = len(plan.objects) + 1
                    if params_to_use is not None:
                        params = params_to_use
                    else:
                        params = gen_parameters(type)[0]
                    if not type_other:
                        print(
                            "create_object() : Il faut préciser une valeur de type_other"
                        )
                    plan.objects.append(
                        Object(
                            object=knx_to_id(knx),
                            statusobject=knx_to_id(knx),
                            id=id,
                            floor=plan.id,
                            type=type_other,
                            locx=locx,
                            locy=locy,
                            params=params,
                            readonly=readonly,
                            cls=cls,
                        )
                    )

    def create_link(
        self,
        parent,
        target,
        locx,
        locy,
        type=None,
        nobg=1,
        genparams=False,
        params_to_use="",
        cls="",
        nom_custom="",
    ):
        """Ajoute un lien entre 2 pages à la visualisation"""
        if genparams:
            params = params_to_use
        else:
            if type == "retour":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":56,"height":56,\
                    "displaymode":"icon","icon":"chevron-up-FFFFFF-0091EA.svg","icon_active":""}'
                nobg = 1

            elif type == "icone_dali":
                params = gen_parameters_v2(
                    type_objet="lien", size=47, icone_on="weather-sun-F7FF00-0091EA.svg"
                )

            elif type == "Locaux Sociaux":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":80,"height":94,\
                    "displaymode":"icon","icon":"Locauxsociaux.png","icon_active":""}'

            elif type == "bulb_on":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":null,"height":null,\
                    "displaymode":"icon","icon":"bulb_bleu.svg","icon_active":""}'

            elif type == "bulb_off":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":56,"height":56,\
                    "displaymode":"icon","icon":"bulb_gris.svg","icon_active":""}'

            elif type == "fan_on":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":56,"height":56,\
                    "displaymode":"icon","icon":"fan_bleu.svg","icon_active":""}'

            elif type == "fan_off":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":null,"height":null,\
                    "displaymode":"icon","icon":"fan_gris.svg","icon_active":""}'

            elif type == "alarm":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":null,"height":null,\
                    "displaymode":"icon","icon":"alarm-FFFFFF-0091EA.svg","icon_active":""}'

            elif type == "temp_jaune":
                params = '{"size":18,"color":"","font":"","bold":0,"italic":0,"underline":0,\
                    "width":64,"height":62,"icon_default":"temperature-degrees-F7FF00-0091EA.svg",\
                    "icon_touch":"","icons_add":[],"displaymode":"icon-value","showcontrol":0,\
                        "fixedvalue":"","update":false,"widget":null,"backdrop":0}'

            elif type == "temp":
                params = '{"size":18,"color":"","font":"","bold":0,"italic":0,"underline":0,\
                    "width":65,"height":64,"icon_default":"temperature-degrees-FFFFFF-0091EA.svg",\
                    "icon_touch":"","icons_add":[]],"displaymode":"icon-value","showcontrol":0,\
                        "fixedvalue":"","update":false,"widget":null,"backdrop":0}'

            elif type == "vide":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":null,"height":null,\
                    "displaymode":"icon","icon":"Carrevide.png","icon_active":""}'

            elif type == "Salle de Vente":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":145,"height":89,\
                    "displaymode":"icon","icon":"SDV.png","icon_active":""}'

            elif type == "Réserve":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":84,"height":74,\
                    "displaymode":"icon","icon":"reserve.png","icon_active":""}'

            elif type == "Locaux sociaux":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":80,"height":94,\
                    "displaymode":"icon","icon":"Locauxsociaux.png","icon_active":""}'

            elif type == "Bâti":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":72,"height":101,\
                    "displaymode":"icon","icon":"bati.png","icon_active":""}'

            elif type == "Chaufferie":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":105,"height":78,\
                    "displaymode":"icon","icon":"chaudire.png","icon_active":""}'

            elif type == "Jardin":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":92,"height":86,\
                    "displaymode":"icon","icon":"Jardin.png","icon_active":""}'

            elif type == "Extérieur_BLD":
                params = gen_parameters_v2(
                    type_objet="lien", size=47, icone_on="lamp-FFFFFF-0091EA.svg"
                )

            elif type == "Menu_CVC":
                params = gen_parameters_v2(
                    type_objet="lien", size=47, icone_on="fan-FFFFFF-0091EA.svg"
                )

            elif type == "Extérieur":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":94,"height":84,\
                    "displaymode":"icon","icon":"Exterieurs.png","icon_active":""}'

            elif type == "Rooftop1":
                params = '{ "size":"","bold":0,"italic":0,"underline": 0,"width":99, \
                    "height":92,"displaymode":"icon","icon":"Rooftop1.png","icon_active":""}'

            elif type == "Rooftop2":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop2.png","icon_active":""}'

            elif type == "Rooftop3":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop3.png","icon_active":""}'

            elif type == "Rooftop4":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop4.png","icon_active":""}'

            elif type == "Rooftop5":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop5.png","icon_active":""}'

            elif type == "Rooftop6":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop6.png","icon_active":""}'

            elif type == "Rooftop7":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop7.png","icon_active":""}'

            elif type == "Rooftop8":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop8.png","icon_active":""}'

            elif type == "Rooftop9":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop9.png","icon_active":""}'

            elif type == "Rooftop10":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop10.png","icon_active":""}'

            elif type == "Rooftop11":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop11.png","icon_active":""}'

            elif type == "Rooftop12":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":99,"height":92,\
                    "displaymode":"icon","icon":"Rooftop12.png","icon_active":""}'

            elif type == "Prog_hor":
                params = gen_parameters_v2(
                    type_objet="lien", size=47, icone_on="scheduler.svg"
                )

            elif type == "lien_texte":
                params = '{"size":20,"color":"","font":"Poppins","bold":0,"italic":0,\
                "underline":0,"width":94,"height":84,"displaymode":"value"}'

            elif type == "lien_texte_bld":
                params = '{"size":20,"color":"#008ECC","font":"Poppins","bold":1,"italic":0,\
                "underline":0,"width":94,"height":84,"displaymode":"value"}'

            elif type == "defauts_roof":
                params = gen_parameters_v2(
                    type_objet="lien", size=56, icone_on="bell-FFFFFF-0091EA.svg"
                )

            elif type == "détail_zones":
                params = gen_parameters_v2(
                    type_objet="lien", size=47, icone_on="warehouse.svg"
                )

            elif type == "icone_dali":
                params = gen_parameters_v2(
                    type_objet="lien", size=56, icone_on="weather-sun-F7FF00-0091EA.svg"
                )

            elif type == "détail_pilotages":
                params = gen_parameters_v2(
                    type_objet="lien", size=47, icone_on="Pilotages_maison.svg"
                )

            elif type == "lien_synthèse":
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":22,"height":22,\
                    "displaymode":"icon","icon":"bell-FFFFFF-0091EA.svg","icon_active":""}'

            else:  # icone "i" rouge
                params = '{"size":"","bold":0,"italic":0,"underline":0,"width":56,"height":56,\
                    "displaymode":"icon","icon":"info-D50000-0091EA.svg","icon_active":""}'

        for plan in self.plans:
            if plan.name == parent:
                for target_plan in self.plans:
                    if target_plan.name == target:
                        plan.objects.append(
                            Object(
                                object=target_plan.id,
                                type=2,
                                id=len(plan.objects) + 1,
                                floor=plan.id,
                                locx=locx,
                                locy=locy,
                                nobg=nobg,
                                cls=cls,
                                params=params,
                                name=nom_custom,
                            )
                        )

    def auto_builder(self, retour, data_translated):
        # check for unnamed objects and ignore them
        match_array = [
            ("VISU_SDV", "Salle de Vente - Pilotages"),
            ("VISU_SDV_CVC", "Salle de Vente - CVC"),
            ("VISU_RES", "Réserve - Pilotages"),
            ("VISU_RES_CVC", "Réserve - CVC"),
            ("VISU_LOC", "Locaux sociaux - Pilotages"),
            ("VISU_LOC_CVC", "Locaux sociaux - CVC"),
            ("VISU_BAT", "Bâti - Pilotages"),
            ("VISU_BAT_CVC", "Bâti - CVC"),
            ("VISU_EXT", self.data_translated["exterieur"]),
            ("VISU_JAR", "Jardin"),
            # Spain
            ("VISU_SV1", "Sala de Ventas 1"),
            ("VISU_SV2", "Sala de Ventas 2"),
            ("VISU_SV3", "Sala de Ventas 3"),
            ("VISU_SVEXT", "Sala de Ventas exterior"),
            ("VISU_ROOFTOPS", "Rooftops"),
        ]
        liste_tags_pilotages_chaufferie = (
            "VISU_CHO",
            "KING_CHAUFFERIE",
            "TEMP_DEPART",
            "HVAC_CHAUFFERIE",
        )
        liste_adresses = []
        liste_noms = []
        liste_tags = []
        for index, obj in enumerate(self.objets):
            if obj.adresse.startswith("1/1/"):  # Add location
                has_location = False
                for tag in obj.tags:
                    if tag:
                        if any(
                            tag.startswith(prefix)
                            for prefix in ("VISUB_", "VISULT_", "VISU_")
                        ) or tag in liste_tags_pilotages_chaufferie + (
                            "PARKING",
                            "ENSEIGNE",
                        ):
                            has_location = True
                            liste_tags.append(tag)
                            liste_adresses.append(obj.adresse)
                            liste_noms.append(obj.name)
                            break

                if (
                    not has_location
                    and not obj.is_sortie_generique
                    and self.client
                    not in (
                        "Carrefour",
                        "Bricoman",
                        "Fnac",
                        "Bils-Deroo",
                        "SNCF",
                        "Argan",
                        "NOZ",
                        "Daher",
                        "Cultura",
                    )
                ):
                    location = detect_location(obj.name)
                    liste_tags.append(location)
                    liste_adresses.append(obj.adresse)
                    liste_noms.append(obj.name)
        # Remove unnamed objects
        if self.client not in (
            "Carrefour",
            "Bricoman",
            "Fnac",
            "Bils-Deroo",
            "SNCF",
            "Argan",
            "NOZ",
            "Daher",
            "Rooftops",
            "Cultura",
        ):
            locations = window_location(liste_adresses, liste_noms, liste_tags)

            for obj in self.objets:
                if obj.adresse in liste_adresses:
                    index = liste_adresses.index(obj.adresse)
                    if locations[index] not in ("???", "PARKING"):
                        for tag in obj.tags:
                            if tag == liste_tags[index]:
                                obj.tags.remove(tag)
                        obj.tags.append(locations[index])

        set_chaufferies = set()

        self.create_object(
            parent=data_translated["programmes_horaires"],
            other="schedulers",
            type_other=9,
            locx=81,
            locy=113,
            type="ProgHor",
            readonly=0,
        )
        flag_chaufferie = False
        for objet in self.objets:
            flag_cvc = False
            flag_ni = False
            liste_prefixes_objets = ("1/", "3/", "4/")
            for prefix in liste_prefixes_objets:
                if re.findall(
                    r"chaufferie\s*\d*", objet.name.lower()
                ) and objet.adresse.startswith(prefix):
                    result = re.findall(r"chaufferie\s*\d*", objet.name.lower())[-1]
                    set_chaufferies.add(result.capitalize().strip())
            if objet.adresse.startswith("1/"):
                for tag in objet.tags:
                    # Si le pilotage n'est pas de la CVC et pilotage inversé :
                    if "CVC" not in tag and "NI" in tag:
                        flag_ni = True
                        type = "light"
                        print(
                            "Pilotage inversé : " + objet.adresse + " - " + objet.name
                        )
                    elif "CVC" in tag:  # Si le pilotage est de la CVC
                        flag_cvc = True
                        if "-NI" in tag:  # Si le pilotage est inversé
                            flag_ni = True
                            print(
                                "Pilotage CVC inversé : "
                                + objet.adresse
                                + " - "
                                + objet.name
                            )
                    if tag in liste_tags_pilotages_chaufferie or tag.startswith(
                        "HVAC_CHAUFFERIE"
                    ):
                        flag_chaufferie = True
                # ajout de détection d'inversion par le nom de l'objet (s'il
                # contient -NI ou NI ou -NO ou NO)
                search_ni = re.findall(r"\bNI\b", objet.name)
                search_no = re.findall(r"\bNO\b", objet.name)
                if len(search_ni) > 0 or len(search_no) > 0:
                    print(
                        'Objet inversé car son nom contient la mention "NO" ou "NI : '
                        + objet.name
                    )
                    retour += (
                        '\nObjet inversé car son nom contient la mention "NO" ou "NI : '
                        + objet.name
                    )
                    flag_ni = True

            elif objet.adresse.startswith("4/"):
                type = "temp"

            if flag_cvc:
                type = "fan"
                if flag_ni:
                    type = "fan-NI"
            elif not flag_cvc:
                type = "light"
                if flag_ni:
                    type = "light-NI"

            for tag in objet.tags:
                if any(
                    tag.startswith(prefix) for prefix in ("VISUB_", "VISULT_", "VISU_")
                ) or tag in liste_tags_pilotages_chaufferie + ("PARKING", "ENSEIGNE"):
                    # Ajouter un couple TAG - Nom de plan pour
                    # automatiquement créer une nouvelle page standard avec
                    # titre, et lien vers le plan du site (mais depuis le
                    # plan vers la page)
                    match = False
                    if tag.startswith("VISUB"):
                        page_name = (
                            tag.split("VISUB_")[1].replace("_", " ").capitalize()
                        )
                        match_array.append((tag, page_name))
                    elif tag.startswith("VISULT"):
                        page_name = (
                            tag.split("VISULT_")[1].replace("_", " ").capitalize()
                        )
                        match_array.append((tag, page_name))
                    for match_tag, match_name in match_array:
                        if match_tag == tag:
                            for plan in self.plans:
                                if plan.name == match_name:
                                    match = True
                            if not match:
                                # Création du plan si inexistant
                                self.create_plan(
                                    name=match_name,
                                    parent=self.name,
                                    background="fond_blanc.png",
                                )

                            # La disposition des objets sur le plan
                            # 'Chaufferie' est gérée par le main car elle est
                            # particulière.
                            if match_name != "Chaufferie":
                                # Création de l'objet
                                if objet.adresse.startswith("1/1"):
                                    if is_obj_boolean(objet.datatype):
                                        self.create_object(
                                            parent=match_name,
                                            knx=objet.adresse,
                                            name=objet.name,
                                            type=type,
                                        )
                                    else:
                                        ...
                                elif objet.adresse.startswith("4/1/"):
                                    for plan in self.plans:
                                        if plan.name == match_name:
                                            id = len(plan.objects) + 1
                                            locx, locy = generate_grid_coordinates(id)
                                    params_temp = ""
                                    for tag in objet.tags:
                                        if tag == "TEMPERATURE":
                                            params_temp = gen_parameters_v2(
                                                type_objet="icone_valeur",
                                                size=50,
                                                icone_on="thermo-bleu.svg",
                                                fontsize=18,
                                                font="Poppins Medium",
                                                color="#1BA3EF",
                                            )
                                        elif tag == "HUMIDITE":
                                            params_temp = gen_parameters_v2(
                                                type_objet="icone_valeur",
                                                size=50,
                                                icone_on="goutte-bleu.svg",
                                                fontsize=18,
                                                font="Poppins Medium",
                                                color="#1BA3EF",
                                            )
                                        elif tag == "CO2":
                                            params_temp = gen_parameters_v2(
                                                type_objet="icone_valeur",
                                                size=50,
                                                icone_on="nuage-bleu.svg",
                                                fontsize=18,
                                                font="Poppins Medium",
                                                color="#1BA3EF",
                                            )

                                    self.create_object(
                                        parent=match_name,
                                        knx=objet.adresse,
                                        name=objet.name,
                                        type_other=1,
                                        other=True,
                                        params_to_use=params_temp,
                                        readonly=1,
                                        locx=locx,
                                        locy=locy,
                                    )

                                elif objet.adresse.startswith("3/1/"):
                                    self.create_object(
                                        parent=match_name,
                                        knx=objet.adresse,
                                        name=objet.name,
                                        type="icone_entrees",
                                    )
                        # Exception pour le plan extérieur, activé par les
                        # tags PARKING et ENSEIGNE
                        elif tag == "PARKING" or tag == "ENSEIGNE":
                            for plan in self.plans:
                                if plan.name == "Extérieur":
                                    match = True
                            if not match and self.client not in (
                                "NOZ",
                                "Argan",
                                "Carrefour",
                                "Bricoman",
                                "Cultura",
                            ):
                                # Création du plan si inexistant
                                self.create_plan(
                                    name=self.data_translated["exterieur"],
                                    parent=self.name,
                                )
        if set_chaufferies:
            for chaufferie in set_chaufferies:
                # Création du plan si inexistant
                self.create_plan(
                    name=chaufferie, parent=self.name, background="fond_chaufferie.png"
                )
                print(
                    f"\nDétection automatique d'objets et ajout sur le plan '{chaufferie}'"
                )
        elif flag_chaufferie:
            self.create_plan(
                name="Chaufferie", parent=self.name, background="fond_chaufferie.png"
            )
            print("\nChaufferie ajoutée")

        # Ajout de liens entre pages de CVC et pilotages
        # Détection des pages nécessitant ce lien (doublons)
        listeplans = []
        listedoublons = []
        for plan in self.plans:
            name = plan.name.split(" - ")
            listeplans.append(name[0])
        listedoublons = find_duplicates(listeplans)

        for doublon in listedoublons:
            for plan in self.plans:
                if plan.name == doublon + " - Pilotages":
                    # lien de la page vers elle meme
                    self.create_link(
                        parent=plan.name,
                        target=plan.name,
                        locx=40,
                        locy=110,
                        type="bulb_on",
                    )
                    self.create_link(
                        parent=plan.name,
                        target=doublon + " - CVC",
                        locx=120,
                        locy=110,
                        type="fan_off",
                    )

                if plan.name == doublon + " - CVC":
                    # lien de la page vers elle meme
                    self.create_link(
                        parent=plan.name,
                        target=plan.name,
                        locx=120,
                        locy=110,
                        type="fan_on",
                    )
                    self.create_link(
                        parent=plan.name,
                        target=doublon + " - Pilotages",
                        locx=40,
                        locy=110,
                        type="bulb_off",
                    )

    def add_empty_cvc_pages(self):
        liste_devices_cvc = ["clim", "cta"]
        liste_devices_blocked = ["LENNOX_CLIMATIC", "ETT_"]
        locx_rt = 340
        for device in self.harmony.modbus_devices:
            slave_type_lower = device.slave_type.lower()
            if any(sub in slave_type_lower for sub in liste_devices_cvc) and not any(
                sub2.lower() in slave_type_lower for sub2 in liste_devices_blocked
            ):
                self.create_plan(
                    name=f"{device.slave_type}_{device.slave_name}",
                    parent=self.name,
                    add_return=False,
                )
                self.create_link(
                    parent=f"{device.slave_type}_{device.slave_name}",
                    target="Menu CVC",
                    locx=24,
                    locy=15,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien",
                        width=17,
                        height=32,
                        icone_on="retour.svg",
                    ),
                )
                self.create_link(
                    parent="Menu CVC",
                    cls="",
                    target=f"{device.slave_type}_{device.slave_name}",
                    locx=locx_rt,
                    locy=400,
                    type="lien_texte",
                    nobg=0,
                )
                locx_rt += 140

    def creer_pages_passerelles_cvc(self):
        """Création des pages de visualisation des passerelles CVC"""
        cpt = 0
        for device in self.harmony.passerelles_cvc_cochees:
            cpt += 1
            if re.search("cool.*master", device.nom.lower()):
                passerelle = CoolMasterNet(device=device)
            elif re.search("panasonic", device.nom.lower()):
                passerelle = Panasonic_SG_1050(device=device)
            elif re.search("daikin", device.nom.lower()) and any(
                re.search(expr, device.nom.lower()) for expr in ["diii", "d3"]
            ):
                passerelle = DaikinDIIINet(device=device)
            else:
                raise ValueError("Passerelle CVC pas encore implémentée")

            objects_to_display = [
                "On/Off",
                "Operation Mode",
                "Fan Speed",
                "Set temperature",
                "Room temperature",
                "HVAC Malfunction Code",
            ]
            mem_unite = 0
            for i in range(1, passerelle.num_pages + 1):
                compteur = 1
                locx_num = 34
                locx_nom = 137
                locx_onoff = 535
                locx_operation_mode = 747
                locx_fan_speed = 918
                locx_consigne = 1030
                locx_ambiante = 1152
                locx_error = 1267
                locy = 200
                nom_plan_actuel = (
                    f"{passerelle.device.nom} - page {i}/{passerelle.num_pages}"
                ).replace("_", " ")
                nom_plan_precedent = (
                    f"{passerelle.device.nom} - page {i-1}/{passerelle.num_pages}"
                ).replace("_", " ")
                self.create_plan(name=nom_plan_actuel, parent=self.name)
                if i == 1:
                    self.create_link(
                        parent="Menu CVC",
                        cls="",
                        target=nom_plan_actuel,
                        locx=80 + cpt * 140,
                        locy=490,
                        type="lien_texte",
                        nobg=0,
                        nom_custom=passerelle.device.nom,
                    )
                self.create_link(
                    parent=nom_plan_actuel,
                    target="Menu CVC",
                    locx=24,
                    locy=15,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien",
                        width=17,
                        height=32,
                        icone_on="retour.svg",
                    ),
                )
                if i > 1:
                    self.create_link(
                        parent=nom_plan_actuel,
                        target=nom_plan_precedent,
                        locx=340,
                        locy=80,
                        genparams=True,
                        params_to_use=gen_parameters_v2(
                            type_objet="lien",
                            size=40,
                            icone_on="retour_bleu.svg",
                        ),
                    )
                    self.create_text(
                        parent=nom_plan_actuel,
                        text=self.data_translated["page_precedente"],
                        locx=383,
                        locy=85,
                        size=18,
                    )
                    # Lien vers la page précédente
                    self.create_link(
                        parent=nom_plan_precedent,
                        target=nom_plan_actuel,
                        locx=980,
                        locy=80,
                        genparams=True,
                        params_to_use=gen_parameters_v2(
                            type_objet="lien",
                            size=40,
                            icone_on="retour_bleu_invert.svg",
                        ),
                    )

                    self.create_text(
                        parent=nom_plan_precedent,
                        text=self.data_translated["page_suivante"],
                        locx=846,
                        locy=85,
                        size=18,
                    )
                self.create_image(
                    parent=nom_plan_actuel,
                    locx=25,
                    locy=133,
                    image="passerelle_CVC_lon.png",
                    width=1319,
                    height=612,
                )

                for unite in passerelle.units:
                    list_dict = []  # future correspondance entre objets d'unités
                    # souhaitant être ajoutés à la visu et leur adresse knx
                    unite.nom = None
                    for description in objects_to_display:
                        # trouver le numéro de registre à partir de la description
                        registre = [
                            reg
                            for reg in unite.registres
                            if reg["description"] == description
                        ][0]

                        # trouver l'adresse knx à partir du numéro et du type de registre
                        # TODO: Si l'objet n'existe pas dans la table mapping,
                        # il faut avertir l'utilisateur.
                        # Pour l'instant, cela plante le programme car on tente
                        # d'indexer une liste vide.

                        def compare_register(ligne, registre):
                            for key in ["mb_reg_addr", "modbus_type", "value_bitmask"]:
                                if key not in registre:
                                    continue
                                if ligne.__dict__[key] != registre[key]:
                                    return False
                            return True

                        ligne_mapping = [
                            ligne
                            for ligne in passerelle.device.mapping
                            if compare_register(ligne, registre)
                        ]
                        if ligne_mapping:
                            ligne_mapping = ligne_mapping[0]

                            dictionnaire = {
                                "description": description,
                                "registre": registre["mb_reg_addr"],
                                "type_modbus": registre["modbus_type"],
                                "knx_read": ligne_mapping.read_knx_addr,
                                "knx_write": ligne_mapping.write_knx_addr,
                            }
                        # si on en est au 1er registre de l'unité,
                        # on en profite pour choper le nom de l'unité
                        # en utilisant le nom de l'objet KNX
                        if unite.nom is None and ligne_mapping:
                            objet = self.harmony.get_object(ligne_mapping.read_knx_addr)
                            pattern = re.search(
                                r"- ([^\-]+?)\s?-\s?[^\-]+?(?: - Lecture Modbus)?$",
                                objet.name,
                            )
                            if pattern is not None:
                                unite.nom = pattern.groups()[0]
                            else:
                                unite.nom = "Non identifié"

                                raise ValueError(
                                    "ERREUR DANS LE DETECTION DU NOM D'UNITE"
                                )

                        list_dict.append(dictionnaire)

                    if unite.num_unit > mem_unite:
                        # Numéro de l'unité
                        self.create_text(
                            parent=nom_plan_actuel,
                            text=f"Unité {unite.num_unit}",
                            locx=locx_num,
                            locy=locy,
                            size=20,
                        )

                        self.create_text(
                            parent=nom_plan_actuel,
                            text=unite.nom,
                            locx=locx_nom,
                            locy=locy,
                            size=20,
                        )
                        # Ajout des objets à la visu lorsque l'on a les adresses
                        # KNX de chaque objet
                        if self.client in ("Leroy Merlin", "Fnac"):
                            readonly_passerelle = 1
                        else:
                            readonly_passerelle = 0

                        for plan in self.plans:
                            if plan.name == nom_plan_actuel:
                                # On Off
                                params = gen_parameters(type_objet="toggle_ni")
                                plan.objects.append(
                                    Object(
                                        object=knx_to_id(
                                            list_dict[
                                                objects_to_display.index("On/Off")
                                            ]["knx_write"]
                                        ),
                                        statusobject=knx_to_id(
                                            list_dict[
                                                objects_to_display.index("On/Off")
                                            ]["knx_write"]
                                        ),
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=locx_onoff,
                                        locy=locy - 5,
                                        params=params[0],
                                        readonly=readonly_passerelle,
                                    )
                                )

                                # Operation Mode
                                params = gen_parameters(type_objet="ROOF_TEXT")
                                plan.objects.append(
                                    Object(
                                        object=knx_to_id(
                                            list_dict[
                                                objects_to_display.index(
                                                    "Operation Mode"
                                                )
                                            ]["knx_write"]
                                        ),
                                        statusobject=knx_to_id(
                                            list_dict[
                                                objects_to_display.index(
                                                    "Operation Mode"
                                                )
                                            ]["knx_write"]
                                        ),
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=locx_operation_mode,
                                        locy=locy,
                                        params=params[0],
                                        readonly=readonly_passerelle,
                                    )
                                )

                                # Fan speed
                                params = gen_parameters(type_objet="ROOF_TEXT")
                                plan.objects.append(
                                    Object(
                                        object=knx_to_id(
                                            list_dict[
                                                objects_to_display.index("Fan Speed")
                                            ]["knx_write"]
                                        ),
                                        statusobject=knx_to_id(
                                            list_dict[
                                                objects_to_display.index("Fan Speed")
                                            ]["knx_write"]
                                        ),
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=locx_fan_speed,
                                        locy=locy,
                                        params=params[0],
                                        readonly=readonly_passerelle,
                                    )
                                )

                                # Set temperature
                                params = gen_parameters(type_objet="ROOF_TEXT")
                                if list_dict[
                                    objects_to_display.index("Set temperature")
                                ]["knx_read"]:
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(
                                                list_dict[
                                                    objects_to_display.index(
                                                        "Set temperature"
                                                    )
                                                ]["knx_write"]
                                            ),
                                            statusobject=knx_to_id(
                                                list_dict[
                                                    objects_to_display.index(
                                                        "Set temperature"
                                                    )
                                                ]["knx_write"]
                                            ),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=locx_consigne,
                                            locy=locy,
                                            params=params[0],
                                            readonly=readonly_passerelle,
                                        )
                                    )

                                # Room temperature
                                params = gen_parameters(type_objet="ROOF_TEXT")
                                if list_dict[
                                    objects_to_display.index("Room temperature")
                                ]["knx_read"]:
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(
                                                list_dict[
                                                    objects_to_display.index(
                                                        "Room temperature"
                                                    )
                                                ]["knx_read"]
                                            ),
                                            statusobject=knx_to_id(
                                                list_dict[
                                                    objects_to_display.index(
                                                        "Room temperature"
                                                    )
                                                ]["knx_read"]
                                            ),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=locx_ambiante,
                                            locy=locy,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                # HVAC Malfunction Code
                                params = gen_parameters(type_objet="ROOF_TEXT")
                                plan.objects.append(
                                    Object(
                                        object=knx_to_id(
                                            list_dict[
                                                objects_to_display.index(
                                                    "HVAC Malfunction Code"
                                                )
                                            ]["knx_read"]
                                        ),
                                        statusobject=knx_to_id(
                                            list_dict[
                                                objects_to_display.index(
                                                    "HVAC Malfunction Code"
                                                )
                                            ]["knx_read"]
                                        ),
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=locx_error,
                                        locy=locy,
                                        params=params[0],
                                        readonly=1,
                                    )
                                )

                        mem_unite = unite.num_unit
                        locy += 56
                        compteur += 1
                        if compteur > passerelle.units_per_page:
                            break

    def create_chaufferie_regin(self):
        """Création des pages de visualisation des chaufferies Regin"""
        for device in self.harmony.devices:
            if device.type_connexion == "Modbus" and "REGIN" in device.nom:
                regin_synoptique = "Chaufferie - Synoptique"
                regin_param1 = "Chaufferie - Paramètres Circuit Primaire"
                regin_param2 = "Chaufferie - Paramètres Circuit Secondaire"

                if self.regin_double_loop:
                    self.create_plan(
                        name=regin_synoptique,
                        parent=self.name,
                        background="Regin_double_loop.png",
                    )
                    self.create_plan(
                        name=regin_param1,
                        parent=self.name,
                        background="Chaufferie_ParamtresPrimaire.png",
                    )
                    self.create_plan(
                        name=regin_param2,
                        parent=self.name,
                        background="page.png",
                    )
                    self.build_regin_page_from_data(DATA_BG, regin_synoptique)
                    self.build_regin_page_from_data(DATA_PRIMAIRE_BG, regin_param1)
                    self.build_regin_page_from_data(DATA_SECONDAIRE_BG, regin_param2)
                elif self.regin_single_loop:
                    self.create_plan(
                        name=regin_synoptique,
                        parent=self.name,
                        background="Regin_single_loop.png",
                    )
                    self.create_plan(
                        name=regin_param1,
                        parent=self.name,
                        background="Chaufferie_ParamtresPrimaire.png",
                    )
                    self.create_plan(
                        name=regin_param2,
                        parent=self.name,
                        background="page.png",
                    )
                    self.build_regin_page_from_data(DATA_FRAIZE, regin_synoptique)
                    self.build_regin_page_from_data(DATA_PRIMAIRE_FRAIZE, regin_param1)
                    self.build_regin_page_from_data(
                        DATA_SECONDAIRE_FRAIZE, regin_param2
                    )
                elif self.regin_ham:
                    self.create_plan(
                        name=regin_synoptique,
                        parent=self.name,
                        background="Chaufferie_HB1_P1_HS1_P1Cst_HS2_P1P2Cst.png",
                    )
                    self.create_plan(
                        name=regin_param1,
                        parent=self.name,
                        background="Chaufferie_ParamtresPrimaire.png",
                    )
                    self.create_plan(
                        name=regin_param2,
                        parent=self.name,
                        background="page.png",
                    )
                    self.build_regin_page_from_data(DATA_HAM, regin_synoptique)
                    self.build_regin_page_from_data(DATA_PRIMAIRE_HAM, regin_param1)
                    self.build_regin_page_from_data(DATA_SECONDAIRE_HAM, regin_param2)
                elif self.regin_gargenville:
                    self.create_plan(
                        name=regin_synoptique,
                        parent=self.name,
                        background="Chaufferie_HS1_P1Cst_HS2_P1Reg.png",
                    )
                    self.create_plan(
                        name=regin_param2,
                        parent=self.name,
                        background="page.png",
                    )
                    self.build_regin_page_from_data(DATA_GARGENVILLE, regin_synoptique)
                    self.build_regin_page_from_data(
                        DATA_SECONDAIRE_GARGENVILLE, regin_param2
                    )

    def build_regin_page_from_data(self, data_boucle, nomduplan):
        params_to_use = None
        for text_obj in data_boucle["textes"]:
            self.create_text(
                parent=nomduplan,
                text=text_obj["text"],
                locx=text_obj["locx"],
                locy=text_obj["locy"],
                size=text_obj["size"],
                color=text_obj["color"],
                font=text_obj["font"],
            )

        for link_obj in data_boucle["liens"]:
            if link_obj["type"] == "lien_texte":
                params_to_use = gen_parameters_v2(
                    type_objet="lien_texte",
                    fontsize=link_obj["paramsV2"]["fontsize"],
                    color=link_obj["paramsV2"]["color"],
                    font=link_obj["paramsV2"]["font"],
                )
            elif link_obj["type"] == "lien":
                params_to_use = gen_parameters_v2(
                    type_objet="lien",
                    width=link_obj["paramsV2"]["width"],
                    height=link_obj["paramsV2"]["height"],
                    icone_on=link_obj["paramsV2"]["icone_on"],
                )
            self.create_link(
                parent=nomduplan,
                target=link_obj["target"],
                locx=link_obj["locx"],
                locy=link_obj["locy"],
                nobg=link_obj.get("nobg", 1),
                nom_custom=link_obj.get("name", ""),
                genparams=True,
                params_to_use=params_to_use,
            )

        for device in self.harmony.devices:
            if device.type_connexion == "Modbus" and "REGIN" in device.nom:
                for obj in data_boucle["objets"]:
                    adresse = ""
                    chosen_one = None
                    if "knx" in obj:
                        adresse = obj["knx"]
                    else:
                        for ligne in device.mapping:
                            if ligne.read_object.name.split(" - ")[1].endswith(
                                obj["identifier"]
                            ):
                                if obj["type"] == "read":
                                    chosen_one = ligne.read_object
                                    break
                                if ligne.write_object:
                                    chosen_one = ligne.write_object
                                    break
                                print("no object found for this line")

                        # Cas d'un objet smart cvc absent du mapping modbus
                        for objet_autre in self.objets:
                            if objet_autre.name.endswith(obj["identifier"]):
                                chosen_one = objet_autre
                        if chosen_one:
                            adresse = chosen_one.adresse
                    if adresse != "":
                        if obj["paramsV2"]["type_objet"] == "valeur":
                            params_to_use = gen_parameters_v2(
                                type_objet=obj["paramsV2"]["type_objet"],
                                color=obj["paramsV2"]["color"],
                                font=obj["paramsV2"]["font"],
                                fontsize=obj["paramsV2"]["fontsize"],
                            )
                        elif obj["paramsV2"]["type_objet"] == "onoff":
                            if "send_fixed_value" in obj["paramsV2"]:
                                send_fixed_value = obj["paramsV2"]["send_fixed_value"]
                            else:
                                send_fixed_value = ""
                            params_to_use = gen_parameters_v2(
                                type_objet=obj["paramsV2"]["type_objet"],
                                icone_on=obj["paramsV2"]["icone_on"],
                                icone_off=obj["paramsV2"]["icone_off"],
                                width=obj["paramsV2"]["width"],
                                height=obj["paramsV2"]["height"],
                                send_fixed_value=send_fixed_value,
                            )
                        elif obj["paramsV2"]["type_objet"] == "icones_add":
                            params_to_use = gen_parameters_v2(
                                type_objet=obj["paramsV2"]["type_objet"],
                                icone_default=obj["paramsV2"]["icone_default"],
                                icones_add=obj["paramsV2"]["icones_add"],
                                width=obj["paramsV2"]["width"],
                                height=obj["paramsV2"]["height"],
                            )

                        self.create_object(
                            parent=nomduplan,
                            type_other=1,
                            knx=adresse,
                            locx=obj["locx"],
                            locy=obj["locy"],
                            params_to_use=params_to_use,
                            other=True,
                            readonly=obj["readonly"],
                        )
                    else:
                        print("adresse non trouvée pour", obj["identifier"])

    def create_rooftops(self, nom_visu: str, magasin: str):
        """Ajoute les pages relatives aux Rooftops"""
        # Rooftops
        set_noms_rt = set()  # Lister les noms de tous les rooftops
        liste_objets_roof = []  # regrouper les objets de rooftops
        flag_sdv_cvc = False
        flag_menu_roof = False

        for objet in [obj for obj in self.objets if obj.name is not None]:
            nom = objet.name.split(" - ")
            # Itère sur les noms de tous les objets pour trouver tous les
            # objets de Rooftops.
            if (
                objet.name.startswith(("ETT_", "LENNOX_"))
                and "bridge" not in objet.name.lower()
                and "ISMA" not in objet.name
            ) or objet.adresse == "4/1/255":
                # Ajoute la partie du nom de l'objet qui contient le nom du
                # rooftop (première partie) pour recenser tous les rooftops
                set_noms_rt.add(str(nom[0]))
                liste_objets_roof.append(objet)

        if len(set_noms_rt) > 0 and not (
            len(set_noms_rt) == 1
            and next(iter(set_noms_rt)) != "Température extérieure"
        ):
            print(f"\nNombre de Rooftops détectés : {len(set_noms_rt)}")
            print("set_noms_rt: ", set_noms_rt)
            MESSAGE = f"\nNombre de Rooftops détectés : {len(set_noms_rt)}\n"
            if magasin == "Fnac":
                self.create_link(
                    parent="Menu",
                    target=self.data_translated["menu_rt"],
                    locx=62,
                    locy=539,
                    genparams=True,
                    params_to_use=gen_parameters_v2(
                        type_objet="lien", size=56, icone_on="fan-FFFFFF-0091EA.svg"
                    ),
                )

                self.create_text(
                    parent="Menu",
                    text=self.data_translated["menu_rt"],
                    size=20,
                    locx=138,
                    locy=553,
                )
        else:
            print("Aucun Rooftop n'a été détecté")
            return "Aucun Rooftop n'a été détecté"

        for plan in self.plans:
            if plan.name == self.data_translated["menu_rt"]:
                flag_menu_roof = True
            if plan.name == "Salle de Vente - CVC":  # Si la page SDV-CVC existe,
                # y placer les raccourcis vers les RT. Sinon, ils seront placés
                # sur SDV-Pilotages
                flag_sdv_cvc = True

        # Création des pages des rooftops
        set_noms_rt = list(set_noms_rt)
        set_noms_rt.sort(key=natural_keys)

        # Localisation/identification des rooftops
        liste_noms_rt = clean_rt_name(set_noms_rt)
        self.rooftops_names = liste_noms_rt
        locx_rt = 80
        for index, roof in enumerate(set_noms_rt):
            self.create_plan(
                name="Visu Rooftop " + str(index + 1),
                parent=nom_visu,
                background="fond_rooftop_new.png",
            )
            for plan in self.plans:
                target = "Plan du site"
                if plan.name == f"Visu Rooftop {index + 1}":
                    nom_rt = f"Rooftop {index + 1} : {self.rooftops_names[index]}"

                    for plan_menu in self.plans:
                        if plan_menu.name == "Salle de Vente - CVC":
                            target = plan_menu.name
                        elif plan_menu.name == "Menu CVC":
                            target = plan_menu.name
                            break
                    self.create_link(
                        parent=plan.name,
                        target=target,
                        locx=24,
                        locy=15,
                        type="vide_RT",
                        genparams=True,
                        params_to_use=gen_parameters_v2(
                            type_objet="lien",
                            width=17,
                            height=32,
                            icone_on="retour.svg",
                        ),
                    )
                    parents = []
                    if flag_menu_roof:
                        parents.append(self.data_translated["menu_rt"])

                    if flag_sdv_cvc:
                        parents.append("Salle de Vente - CVC")

                    else:
                        parents.append("Salle de Vente - Pilotages")

                    for parent in parents:
                        self.create_link(
                            parent=parent,
                            cls="",
                            target=plan.name,
                            locx=locx_rt,
                            locy=600,
                            type="lien_texte",
                            nobg=0,
                            nom_custom=plan.name.split("Visu ")[1],
                        )

            locx_rt += 140  # décale l'icône
            if index == 12:  # Afficher le message une seule fois
                print(
                    "\nPlus de 12 Rooftops ont été détectés, veuillez ajouter "
                    "manuellement les icônes correspondantes sur la page 'Salle "
                    "de vente - CVC'"
                )
                MESSAGE += (
                    "\nPlus de 12 Rooftops ont été détectés, veuillez ajouter "
                    "manuellement les icônes correspondantes sur la page 'Salle "
                    "de vente - CVC'"
                )

        # Création des pages de défaut :
        for plan in self.plans:
            if plan.name.find("Visu Rooftop") != -1:  # page de rooftop
                # trouve le numéro du rooftop
                numero = re.findall(r"\d+", plan.name)[0]
                if numero:
                    self.create_plan(name=f"Défauts Rooftop {numero}", parent=nom_visu)
        # Ajout des liens vers les pages de défauts
        for i in range(1, len(set_noms_rt) + 1):
            # Lien vers la page de défauts
            self.create_link(
                parent=f"Visu Rooftop {i}",
                target=f"Défauts Rooftop {i}",
                locx=61,
                locy=175,
                type="defauts_roof",
            )
            self.create_text(
                parent=f"Visu Rooftop {i}",
                text=self.data_translated["detail_defauts"],
                locx=127,
                locy=190,
                size=22,
            )

        # Ajout des défauts sur les pages défauts rooftops :
        numero_plan = 0
        # Pour chaque RT détecté
        for rooftop in set_noms_rt:
            numero_plan += 1
            liste_defauts = []
            for objet in liste_objets_roof:
                # Si l'objet appartient au rooftop en question
                if objet.name.find(rooftop) != -1:
                    # conditions pour ajouter l'objet aux défauts
                    if (
                        (
                            objet.name.lower().find("défaut") != -1
                            or objet.name.lower().find("defaut") != -1
                            or objet.name.lower().find("alarm") != -1
                        )
                        and objet.name.lower().split(" - ")[1].find("seuil") != 0
                        and not "- Commande Harmony" in objet.name
                        and objet.name.lower().find("#") == -1
                        or "ENSLG_ROOF_DEFAUT" in objet.tags
                    ):
                        liste_defauts.append(objet)

            if len(liste_defauts) < 38:
                start_locy = 150
                locx_icone = 180
                locy_icone = start_locy
                locx_texte = locx_icone + 30

                increment_colonne = 650
                limite = 700
            else:
                start_locy = 120
                locx_icone = 60
                locy_icone = start_locy
                locx_texte = locx_icone + 30

                increment_colonne = 460
                limite = 700

            for plan in self.plans:
                if plan.name == f"Défauts Rooftop {numero_plan}":
                    liste_defauts = [defaut.adresse for defaut in liste_defauts]
                    plan.placer_liste(liste_defauts, "defaut_rt", None, None, plan.name)
                    # TODO ajouter retour vers synthèse défaut

        id_plan_roof_init = None
        # Ajout des objets
        for plan in self.plans:
            if plan.name.find("Visu Rooftop") != -1:
                id_plan_roof_init = plan.id
                break

        for i, nom_rt in enumerate(set_noms_rt):  # Pour chaque RT détecté
            for plan in self.plans:
                if plan.id == id_plan_roof_init + i:
                    for objet_roof in liste_objets_roof:  # pour chaque objet
                        if objet_roof.adresse == "4/1/255":
                            params = gen_parameters(type_objet="text_20")
                            plan.objects.append(
                                Object(
                                    name=self.data_translated["moyenne"],
                                    type=6,
                                    id=len(plan.objects) + 1,
                                    floor=plan.id,
                                    locx=33,
                                    locy=112,
                                    params=params[0],
                                    nobg=1,
                                )
                            )
                            params = gen_parameters(type_objet="ROOF_TEXT")
                            plan.objects.append(
                                Object(
                                    object=knx_to_id(objet_roof.adresse),
                                    statusobject=knx_to_id(objet_roof.adresse),
                                    id=len(plan.objects) + 1,
                                    floor=plan.id,
                                    locx=318,
                                    locy=112,
                                    params=params[0],
                                    readonly=1,
                                )
                            )

                        if objet_roof.name.find(nom_rt) == 0:
                            # recherche des objets par nom avant de le faire par
                            # tags
                            if objet_roof.name.lower().find("mode machine") != -1:
                                self.create_text(
                                    parent=plan.name,
                                    text="Mode machine :",
                                    locx=31,
                                    locy=628,
                                    size=20,
                                    gras=1,
                                    color="#008ECC",
                                )
                                params = gen_parameters(type_objet="ROOF_TEXT")
                                plan.objects.append(
                                    Object(
                                        object=knx_to_id(objet_roof.adresse),
                                        statusobject=knx_to_id(objet_roof.adresse),
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=200,
                                        locy=628,
                                        params=params[0],
                                        readonly=1,
                                    )
                                )
                            # Acquittements
                            pattern = re.compile(
                                r"(r.armement|acquittement.*alarmes|reset.*alarme)",
                                re.IGNORECASE,
                            )
                            end_pattern = re.compile(
                                r"Commande Harmony$", re.IGNORECASE
                            )
                            if pattern.search(objet_roof.name) and end_pattern.search(
                                objet_roof.name
                            ):
                                print(f"Acquittement trouvé : {objet_roof.name}")
                                params = gen_parameters(type_objet="text_20")
                                plan.objects.append(
                                    Object(
                                        name=self.data_translated["ack_def"],
                                        type=6,
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=107,
                                        locy=688,
                                        params=params[0],
                                        nobg=1,
                                    )
                                )
                                if is_obj_boolean(objet_roof.datatype):
                                    params = gen_parameters_v2(
                                        type_objet="onoff",
                                        size=53,
                                        icone_on="alarm-D50000-0091EA.svg",
                                        icone_off="alarm-383838-0091EA.svg",
                                        readonly=0,
                                    )
                                else:
                                    params = gen_parameters_v2(
                                        type_objet="icones_add",
                                        size=53,
                                        icone_default="alarm-383838-0091EA.svg",
                                        icones_add=[
                                            [0, "alarm-383838-0091EA.svg"],
                                            [1, "alarm-D50000-0091EA.svg"],
                                        ],
                                        readonly=0,
                                    )
                                plan.objects.append(
                                    Object(
                                        object=knx_to_id(objet_roof.adresse),
                                        statusobject=knx_to_id(objet_roof.adresse),
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=47,
                                        locy=675,
                                        params=params[0],
                                        readonly=0,
                                    )
                                )

                            if objet_roof.name.lower().find("code erreur") != -1:
                                params = gen_parameters(type_objet="ROOF_TEXT")
                                plan.objects.append(
                                    Object(
                                        object=knx_to_id(objet_roof.adresse),
                                        statusobject=knx_to_id(objet_roof.adresse),
                                        id=len(plan.objects) + 1,
                                        floor=plan.id,
                                        locx=277,
                                        locy=582,
                                        params=params[0],
                                        readonly=1,
                                    )
                                )

                            for tag in objet_roof.tags:
                                if tag in ("STOCKLIGHT-NI", "OnOffPhysical"):
                                    readonly = (
                                        1
                                        if magasin
                                        in ["Leroy Merlin", "Carrefour", "Bricoman"]
                                        else 0
                                    )
                                    if is_obj_boolean(objet_roof.datatype):
                                        params = gen_parameters(
                                            type_objet="ROOF_TOGGLE"
                                        )
                                    else:
                                        params = (
                                            gen_parameters_v2(
                                                type_objet="icones_add",
                                                width=143,
                                                height=44,
                                                icone_default="ToggleONblue.png",
                                                icones_add=[
                                                    [0, "ToggleOFFgrey.png"],
                                                    [1, "ToggleONblue.png"],
                                                ],
                                            ),
                                            1,
                                        )

                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=147,
                                            locy=466,
                                            params=params[0],
                                            readonly=readonly,
                                        )
                                    )

                                if (
                                    tag == "ENSLG_ROOF_TAMB" or tag == "HVACSDV1_TAMB"
                                ):  # Température ambiante
                                    params = gen_parameters(
                                        type_objet="temperature_texte"
                                    )  # icône
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=1015,
                                            locy=598,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                    params = gen_parameters(type_objet="text_20")
                                    plan.objects.append(
                                        Object(
                                            name=self.data_translated[
                                                "temp_ambiante_rt"
                                            ],
                                            type=6,
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=737,
                                            locy=624,
                                            params=params[0],
                                            nobg=1,
                                        )
                                    )

                                if (
                                    tag == "ENSLG_ROOF_TEXT" or tag == "HVACSDV1_TEXT"
                                ):  # Température
                                    # extérieure
                                    params = gen_parameters(type_objet="ROOF_TEXT")
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=188,
                                            locy=400,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                if (
                                    tag == "ENSLG_ROOF_TCONS_2"
                                    or tag == "HVACSDV1_TECONS_JE"
                                ):  # consigne de
                                    # température été
                                    params = gen_parameters(type_objet="ROOF_CONS_ETE")
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=179,
                                            locy=504,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                if (
                                    tag == "ENSLG_ROOF_TCONS_3"
                                    or tag == "HVACSDV1_TECONS_JH"
                                ):  # Consigne hiver
                                    params = gen_parameters(
                                        type_objet="ROOF_CONS_HIVER"
                                    )
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=94,
                                            locy=504,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                if (
                                    tag == "ENSLG_ROOF_DEFAUT"
                                    or tag == "HVACSDV1_ALARME_SYNTHESE"
                                ):  # Synthèse défaut
                                    if is_obj_boolean(objet_roof.datatype):
                                        params = gen_parameters(
                                            type_objet="ROOF_DEFAUT"
                                        )
                                        params_small = gen_parameters_v2(
                                            type_objet="onoff",
                                            size=49,
                                            icone_on="bell_on.svg",
                                            icone_off="bell_off.svg",
                                            readonly=1,
                                        )
                                    else:
                                        params = gen_parameters_v2(
                                            type_objet="icones_add",
                                            size=76,
                                            icone_default="AlarmaOff.png",
                                            icones_add=[
                                                [0, "AlarmaOff.png"],
                                                [1, "AlarmaOn.png"],
                                            ],
                                            readonly=1,
                                        )
                                        params_small = gen_parameters_v2(
                                            type_objet="icones_add",
                                            size=49,
                                            icone_default="bell_off.svg",
                                            icones_add=[
                                                [0, "bell_off.svg"],
                                                [1, "bell_on.svg"],
                                            ],
                                            readonly=1,
                                        )
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=270,
                                            locy=504,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )
                                    # Ajout sur la page SDV CVC pour avoir la synthèse
                                    # du roof sous chaque lien

                                    for plan_a_utiliser in self.plans:
                                        if plan_a_utiliser.name in (
                                            "Salle de Vente - CVC",
                                            self.data_translated["menu_rt"],
                                        ):
                                            plan_a_utiliser.objects.append(
                                                Object(
                                                    object=knx_to_id(
                                                        objet_roof.adresse
                                                    ),
                                                    statusobject=knx_to_id(
                                                        objet_roof.adresse
                                                    ),
                                                    id=99 + i,
                                                    floor=plan_a_utiliser.id,
                                                    locx=100 + (140 * i),
                                                    locy=645,
                                                    params=params_small[0],
                                                    readonly=1,
                                                )
                                            )

                                if (
                                    tag == "ENSLG_ROOF_TREPR" or tag == "HVACSDV1_TREPR"
                                ):  # Température reprise
                                    params = gen_parameters(type_objet="ROOF_TEXT")
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=452,
                                            locy=626,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                if (
                                    tag == "ENSLG_ROOF_TSOUFFL"
                                    or tag == "HVACSDV1_TSOUFFL"
                                ):  # Température
                                    # soufflage
                                    params = gen_parameters(type_objet="ROOF_TEXT")
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=580,
                                            locy=626,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                # Soufflage (Etat)
                                if tag in (
                                    "VISU_ROOF_SOUFFL",
                                    "HVACSDV1_MA_SOUFFL",
                                    "ENSLG_ROOF_MA",
                                ):
                                    # Icône flèche extraction41
                                    if is_obj_boolean(objet_roof.datatype):
                                        params = gen_parameters(
                                            type_objet="ROOF_EXTRACT"
                                        )
                                    else:
                                        params = gen_parameters_v2(
                                            type_objet="icones_add",
                                            width=95,
                                            height=70,
                                            icone_default="Carrevide.png",
                                            icones_add=[
                                                [0, "Carrevide.png"],
                                                [1, "entree-air-crop.gif"],
                                            ],
                                            readonly=1,
                                        )
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=282,
                                            locy=348,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                    # Icône flèche soufflage
                                    if is_obj_boolean(objet_roof.datatype):
                                        params = gen_parameters(
                                            type_objet="ROOF_SOUFFL"
                                        )
                                    else:
                                        params = gen_parameters_v2(
                                            type_objet="icones_add",
                                            width=20,
                                            height=68,
                                            icone_default="Carrevide.png",
                                            icones_add=[
                                                [0, "Carrevide.png"],
                                                [1, "sortie-air-crop.gif"],
                                            ],
                                            readonly=1,
                                        )
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=600,
                                            locy=552,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                    # Icône ventilateur soufflage
                                    if is_obj_boolean(objet_roof.datatype):
                                        params = gen_parameters(
                                            type_objet="ROOF_VENTIL"
                                        )
                                    else:
                                        params = gen_parameters_v2(
                                            type_objet="icones_add",
                                            width=114,
                                            height=126,
                                            icone_default="Carrevide.png",
                                            icones_add=[
                                                [0, "Carrevide.png"],
                                                [1, "Ventilateurcentrifuge.gif"],
                                            ],
                                            readonly=1,
                                        )
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=574,
                                            locy=414,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                # Reprise (État)
                                if tag in ("VISU_ROOF_REPR", "HVACSDV1_MA_REPR"):
                                    # Icône fleche reprise
                                    params = gen_parameters(type_objet="ROOF_REPRISE")
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=472,
                                            locy=562,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                # Air neuf
                                if tag == "ENSLG_ROOF_AIR_NEUF":
                                    # Texte
                                    params = gen_parameters(type_objet="ROOF_TEXT")
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=430,
                                            locy=429,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )

                                if tag == "MBS_STATS":
                                    if self.client == "Carrefour":
                                        classe_custom = "stat"
                                    else:
                                        classe_custom = ""
                                    # Texte
                                    params = gen_parameters(type_objet="ROOF_TEXT")
                                    plan.objects.append(
                                        Object(
                                            object=knx_to_id(objet_roof.adresse),
                                            statusobject=knx_to_id(objet_roof.adresse),
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=823,
                                            locy=688,
                                            cls=classe_custom,
                                            params=params[0],
                                            readonly=1,
                                        )
                                    )
                                    params = gen_parameters(type_objet="text_20")
                                    plan.objects.append(
                                        Object(
                                            name=self.data_translated["statistiques"],
                                            type=6,
                                            id=len(plan.objects) + 1,
                                            floor=plan.id,
                                            locx=447,
                                            locy=688,
                                            params=params[0],
                                            nobg=1,
                                        )
                                    )

                                # Ventilateur condensateur circuit n°X (4
                                # circuits normalement)
                                if tag == "VISU_ROOF_VENTIL_CONDENS":
                                    nom = objet_roof.name.split(" - ")[1]
                                    if nom.find("1") != -1:
                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_TOP"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=698,
                                                locy=93,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_ARROW"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=1099,
                                                locy=409,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                    elif nom.find("2") != -1:
                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_TOP"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=795,
                                                locy=93,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_ARROW"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=1099,
                                                locy=316,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                    elif nom.find("3") != -1:
                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_TOP"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=891,
                                                locy=93,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_ARROW"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=1099,
                                                locy=229,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                    elif nom.find("4") != -1:
                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_TOP"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=988,
                                                locy=93,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                        params = gen_parameters(
                                            type_objet="ROOF_CONDENS_ARROW"
                                        )
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=1099,
                                                locy=139,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                # Compresseurs
                                if (
                                    tag.find("VISU_ROOF_COMPR") == 0
                                    or tag == "ENSLG_ROOF_MA_COMP"
                                    or tag == "HVACSDV1_MA_COMP"
                                ):
                                    if is_obj_boolean(objet_roof.datatype):
                                        params = gen_parameters(type_objet="ROOF_COMP")
                                    else:
                                        params = gen_parameters_v2(
                                            type_objet="icones_add",
                                            width=58,
                                            height=94,
                                            icone_default="Carrevide.png",
                                            icones_add=[
                                                [0, "Carrevide.png"],
                                                [1, "Compresseur.gif"],
                                            ],
                                            readonly=1,
                                        )
                                    # Si le nom contient un 1 --> compresseur 1,
                                    # etc...
                                    if objet_roof.name.split(" - ")[1].find("1") != -1:
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=718,
                                                locy=458,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                    if objet_roof.name.split(" - ")[1].find("2") != -1:
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=814,
                                                locy=458,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                    if objet_roof.name.split(" - ")[1].find("3") != -1:
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=904,
                                                locy=458,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )

                                    if objet_roof.name.split(" - ")[1].find("4") != -1:
                                        plan.objects.append(
                                            Object(
                                                object=knx_to_id(objet_roof.adresse),
                                                statusobject=knx_to_id(
                                                    objet_roof.adresse
                                                ),
                                                id=len(plan.objects) + 1,
                                                floor=plan.id,
                                                locx=1000,
                                                locy=458,
                                                params=params[0],
                                                readonly=1,
                                            )
                                        )
        return MESSAGE

    def creer_chambres_froides(self):
        """
        Create chambre froides based on the tags of the objects.
        The function loops through each object and its tags to identify if it starts with "VISUCF_".

        Next, the function iterates through each element in the list and creates a plan with the name of the page.
        It also adds standard elements to the page such as text, images, and more.
        Finally, the function adds the objects to the pages.
        """
        liste_objets_cf = []
        set_noms = set()
        for obj in self.objets:
            if (
                obj.name.startswith("DANFOSS")
                and obj.name.split(" - ")[0] not in set_noms
            ):
                set_noms.add(obj.name.split(" - ")[0])

            for tag in obj.tags:
                if tag.startswith("VISUCF_"):
                    item = dict().fromkeys(("page", "device", "nom"))
                    nom_page = tag.split("VISUCF_")[1].replace("_", " ")
                    nom_objet = obj.name
                    item["page"] = nom_page
                    item["device"] = nom_objet.split(" - ")[0]
                    item["nom"] = process_name(nom_objet)
                    liste_objets_cf.append(item)

        # Ajout des pages
        set_pages = set()
        for element in liste_objets_cf:
            set_pages.add(element["page"])

        for nom_page in set_pages:
            self.create_plan(name=nom_page, parent=self.name)
            # Ajout des éléments standards de la page
            self.create_text(
                parent=nom_page, text="Elemento", locx=110, locy=137, size=20
            )
            self.create_text(
                parent=nom_page, text="Temperatura", locx=382, locy=137, size=20
            )
            self.create_text(
                parent=nom_page, text="Alarmas", locx=600, locy=137, size=20
            )
            self.create_text(
                parent=nom_page, text="Leyenda", locx=983, locy=127, size=26
            )
            self.create_text(
                parent=nom_page,
                text="Danfoss",
                locx=579,
                locy=194,
                size=20,
                color="#2e75b6",
            )
            self.create_text(
                parent=nom_page,
                text="Leyenda",
                locx=670,
                locy=194,
                size=20,
                color="#2e75b6",
            )
            self.create_image(
                parent=nom_page,
                image="leyenda.png",
                locx=818,
                locy=170,
                width=428,
                height=387,
            )

            # Ajout des objets sur les pages
            # Trouver tous les devices de la page
            locy_cf = 240
            for item in liste_objets_cf:
                device_objects = []
                if item["page"] == nom_page:
                    # Récupération de tous les objets du device
                    for obj in self.objets:
                        if obj.name.find(item["device"]) == 0:
                            device_objects.append(obj)

                    # Ajout des objets à la page
                    LOCX_NOM = 80
                    LOCX_TEMP = 434
                    LOCX_ALARM1 = 600
                    LOCX_ALARM2 = 685
                    INCREMENT_LOCY = 50
                    self.create_text(
                        parent=nom_page,
                        text=item["nom"],
                        locx=LOCX_NOM,
                        locy=locy_cf,
                        size=20,
                    )
                    for obj in device_objects:
                        if obj.name.endswith("Temperatura aire"):
                            self.create_object(
                                parent=nom_page,
                                knx=obj.adresse,
                                locx=LOCX_TEMP,
                                locy=locy_cf,
                                other=True,
                                params_to_use=gen_parameters_v2(
                                    type_objet="valeur",
                                    fontsize=18,
                                ),
                                readonly=1,
                                type_other=1,
                            )
                            self.create_object(
                                parent=nom_page,
                                knx=obj.adresse,
                                other=True,
                                locx=LOCX_ALARM2,
                                locy=locy_cf,
                                type_other=1,
                                readonly=1,
                                params_to_use=gen_parameters_v2(
                                    type_objet="icones_add",
                                    width=36,
                                    height=36,
                                    icone_default="bell-383838-0091EA.svg",
                                    icones_add=[
                                        [-9999, 4, "bell-383838-0091EA.svg"],
                                        [5, 9999, "bell-D50000-0091EA.svg"],
                                    ],
                                ),
                            )
                        elif obj.name.endswith("Alarma de alta temperatura"):
                            self.create_object(
                                parent=nom_page,
                                type_other=1,
                                knx=obj.adresse,
                                locx=LOCX_ALARM1,
                                locy=locy_cf,
                                other=True,
                                params_to_use=gen_parameters_v2(
                                    type_objet="onoff",
                                    size=36,
                                    icone_on="AlarmaOn.png",
                                    icone_off="AlarmaOff.png",
                                ),
                                readonly=1,
                            )

                    locy_cf += INCREMENT_LOCY

    def create_rtd_net(self, nom_visu):
        set_rtd_net = set()
        index = 2
        x_lien = 80
        y_lien = 320
        liste_obj_rtd = []
        liste_noms_plans = []
        data_rtd_net = {  # "Nom de l'objet" : (locx, locy, [readonly])
            "Global - Mode de mise à jour - Commande Harmony": (299, 354),
            "Mode de fonctionnement de la télécommande": (228, 479),
            "Groupe - Moyenne température de reprise": (326, 550),
            "Statistiques Modbus": (631, 154),
            "Commande GTC Marche/Arrêt - Commande Harmony": (1110, 166, 0),
            "Groupe - Nombre d'unités sur le réseau": (1155, 219),
            "Vitesse de ventilation - Commande Harmony": (1145, 272),
            "Groupe - Synthèse d'état de dégivrage (toutes unités)": (1135, 325),
            "Mode de fonctionnement - Commande Harmony": (1053, 431),
            "Groupe - Synthèse d'alarme (toutes unités)": (1126, 532),
            "Groupe - Synthèse d'alarme filtre (toutes unités)": (1126, 576),
            "Consigne de température - Commande Harmony": (1141, 656),
        }
        for obj in self.objets:
            if obj.name.startswith("RTD_NET_DAIKIN"):
                set_rtd_net.add(obj.name.split(" - ")[0])
                liste_obj_rtd.append(obj)

        for nom in set_rtd_net:
            formatted_name = "Système Daikin " + " ".join(
                nom.split("RTD_NET_DAIKIN_")[1].split("_")[:-1]
            )
            if formatted_name in liste_noms_plans:
                formatted_name += f" {index}"
                index += 1
            else:
                index = 2
            liste_noms_plans.append(formatted_name)
            print(f"Création de la page: {formatted_name}")
            self.create_plan(
                name=formatted_name, parent=nom_visu, background="Daikin2.png"
            )

            self.create_link(
                parent=formatted_name,
                target=self.data_translated["menu_rt"],
                locx=24,
                locy=15,
                genparams=True,
                params_to_use=gen_parameters_v2(
                    type_objet="lien", width=17, height=32, icone_on="retour.svg"
                ),
            )
            self.create_link(
                parent=self.data_translated["menu_rt"],
                cls="",
                target=formatted_name,
                locx=x_lien,
                locy=y_lien,
                type="lien_texte",
                nobg=0,
            )
            y_lien += 60

            for obj_rtd_net in liste_obj_rtd:
                if obj_rtd_net.name.startswith(nom):
                    for item in data_rtd_net.items():
                        if item[0] in obj_rtd_net.name:
                            try:
                                readonly = item[1][2]
                            except IndexError:
                                readonly = 1
                            if (
                                "Statistiques Modbus" in obj_rtd_net.name
                                and self.client == "Carrefour"
                            ):
                                cls = "stat"
                            else:
                                cls = "pop-no-shadow"
                            self.create_object(
                                parent=formatted_name,
                                type_other=1,
                                knx=obj_rtd_net.adresse,
                                locx=item[1][0],
                                locy=item[1][1],
                                params_to_use=gen_parameters_v2(
                                    type_objet="valeur",
                                    font="Poppins",
                                    fontsize=24,
                                    color="#1BA3EF",
                                    bold=1,
                                ),
                                other=True,
                                readonly=readonly,
                                cls=cls,
                            )
                            break
