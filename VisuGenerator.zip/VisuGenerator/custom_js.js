//La fonction ci-dessous permet de revenir au menu de la visualisation en cliquant sur la petite icone "home" depuis la page scheduler (et non pas revenir au /apps)

$(function () {
    if (window.history.length > 1) {
        $('.btn-home').click(function (e) {
            e.preventDefault();
            window.location = '/scada-vis';
        });
    }
});


$(document).ready(function () {
    function updateElement(element) {
        var value = parseFloat($(element).text().replace('%', ''));
        if (value == 0) {
            $(element).addClass('red');
        } else {
            $(element).removeClass('red');
        }
    }

    // Initial update for each element
    $('.stat').each(function () {
        updateElement(this);
    });

    // Create a MutationObserver to watch for changes
    var observer = new MutationObserver(function (mutationsList) {
        for (var mutation of mutationsList) {
            if (mutation.type === 'childList' || mutation.type === 'characterData') {
                updateElement(mutation.target);
            }
        }
    });

    // Observe each .test element for changes
    $('.stat').each(function () {
        observer.observe(this, { childList: true, characterData: true, subtree: true });
    });
});