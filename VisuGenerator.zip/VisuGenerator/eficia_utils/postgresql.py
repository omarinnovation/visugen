"""Module eficia_utils.postgresql
Contient les fonctions permettant d'interagir avec une base de données
PostgreSQL.
"""
from __future__ import annotations

import os
import time
from typing import Any
from typing import TYPE_CHECKING

import psycopg2.extras
from psycopg2 import sql
from psycopg2.extensions import connection

if TYPE_CHECKING:
    pass

_PARAMS_SQL = {}

for param_name in ["host", "dbname", "port", "user", "password"]:
    param_value = os.getenv("DB_" + param_name.upper())
    if param_value is not None:
        _PARAMS_SQL[param_name] = param_value


def ouvrir_connexion(
    application_name: str = "Gestion parc Harmony",
    autocommit: bool = True,
    client_encoding: str = "UTF8",
    retries: int = 10,
    retry_delay: int = 10,
    params: dict[Any] = None,
) -> connection:
    """
    Retourne une connexion BDD.
    :param retry_delay: Nombre de secondes entre chaque tentative de connexion.
    :param autocommit: activer l'autocommit.
    :param client_encoding: encodage de caractères.
    :param retries: Nombre d'essais de connexion à la base de données.
    :param params: dictionnaire contenant les paramètres de connexion à la BDD.
        Par exemple :
        params = {
            'host': 'localhost',
            'dbname': 'postgres',
            'port': 5432,
            'user': 'postgres',
            'password': 'postgres',
            'application_name': 'myapp'
        }
    :return: Connexion à la BDD.
    """
    if params is None:
        params = _PARAMS_SQL
    connection_success = False
    i = 0
    while i < retries and not connection_success:
        try:
            conn = psycopg2.connect(application_name=application_name, **params)
            connection_success = True
        except Exception:
            i += 1
            time.sleep(retry_delay)
    if not connection_success:
        raise ConnectionError("Impossible de se connecter à la base de données.")
    conn.autocommit = autocommit
    conn.set_client_encoding(client_encoding)
    return conn


def executer(
    conn: psycopg2.extensions.connection, requete: str, args: tuple | dict = None
) -> None:
    """
    Execute SQL query.

    Ouvre un curseur sur la connexion SQL et exécute via ce curseur
    la requête SQL passée en entrée. La requête peut être une
    requête acceptant des paramètres, dans ce cas passés dans le
    paramètre args.

    Par exemple si args est un tuple (liste de valeurs entre parenthèses) :
    requete = "INSERT INTO test (num, data) VALUES (%s, %s)"
    args = (100, "abc'def")
    executer(conn, requete, args)

    Par exemple si args est un dictionnaire :
        requete = "INSERT INTO some_table
        (an_int, a_date, another_date, a_string)
        VALUES (%(int)s, %(date)s, %(date)s, %(str)s);"
        args = {'int': 10,
                'str': "O'Reilly",
                'date': datetime.date(2005, 11, 18)
                }
        executer(conn, requete, args)

    Parameters
    ----------
    conn : psycopg2.connection
        connexion à la BDD.
    requete : str
        Requête SQL contenant éventuellement des paramètres non-nommés %s
        ou des paramètres nommés %(alias)s.
    args : tuple or dict, optional
        Ensemble de paramètres à éventuellement passer à la requête SQL.
        Si les paramètres sont non-nommés %s, il faut passer un tuple,
        c'est-à-dire une liste de valeurs entre parenthèses.
        Si les paramètres sont nommés %(nom1)s, %(nom2)s, ..., il faut
        passer un dictionnaire de valeurs dont les clés sont les noms
        des paramètres : {'nom1': valeur1, 'nom2': valeur2, ...}
        The default is None.

    Returns
    -------
    None.

    """
    cur = conn.cursor()
    if args is None:
        cur.execute(requete)
    else:
        cur.execute(requete, args)
    cur.close()


def executer_script_sql(script: str, conn: psycopg2.extensions.connection) -> None:
    """
    Exécute un script SQL entier.

    Parameters
    ----------
    script : str
        Nom du fichier sql, par exemple "mon_script.sql".
    conn : psycopg2.connection
        Connexion à la BDD PostgreSQL.

    Returns
    -------
    None.

    """
    with open(script, "r", encoding="utf-8") as fichier:
        requete_sql = fichier.read()
    executer(conn, requete_sql)


def insertion(
    list_dicts: list[dict[Any]],
    conn: psycopg2.extensions.connection,
    schema: str,
    table: str,
) -> None:
    """
    Insère une liste de dictionnaires dans une table SQL.

    Parameters
    ----------
    list_dicts : list(dict)
        Données, liste de dictionnaires, 1 dictionnaire = 1 ligne.
    conn : psycopg2.connection
        Connexion à une base PostgreSQL.
    schema : str
        Nom du schéma.
    table : str
        Nom de la table.

    Returns
    -------
    None.

    """
    if len(list_dicts) == 0:
        return
    cols = set.union(*[set(dic.keys()) for dic in list_dicts])
    col_sql = [sql.Identifier(x) for x in cols]
    requete_modele = sql.SQL("INSERT INTO {0}.{1}({2}) VALUES %s;")
    requete = requete_modele.format(
        sql.Identifier(schema), sql.Identifier(table), sql.SQL(", ").join(col_sql)
    )
    template = "(" + ", ".join(f"%({col})s" for col in cols) + ")"
    data = [{key: dico.get(key) for key in cols} for dico in list_dicts]
    cur = conn.cursor()
    psycopg2.extras.execute_values(cur, requete, data, template, page_size=1000)
    cur.close()


def select(
    conn: psycopg2.extensions.connection, requete: str, args: tuple | dict = None
) -> list[dict[Any]]:
    """
    Exécute une requête SELECT et retourne les résultats.

    Parameters
    ----------
    conn : psycopg2.connection
        Connexion à une base PostgreSQL.
    requete : str
        Requête à exécuter.
    args : tuple or dict, optional
        Ensemble de paramètres à éventuellement passer à la requête SQL.
        Si les paramètres sont non-nommés %s, il faut passer un tuple,
        c'est-à-dire une liste de valeurs entre parenthèses.
        Si les paramètres sont nommés %(nom1)s, %(nom2)s, ..., il faut
        passer un dictionnaire de valeurs dont les clés sont les noms
        des paramètres : {'nom1': valeur1, 'nom2': valeur2, ...}
        The default is None.

    Returns
    -------
    toreturn : list(dict)
        Résultats de la requête SELECT.

    """
    cur = conn.cursor()
    if args is None:
        cur.execute(requete)
    else:
        cur.execute(requete, args)
    data = [list(v) for v in list(cur.fetchall())]
    cols = [k[0] for k in cur.description]
    toreturn = [dict(zip(cols, ligne)) for ligne in data]
    return toreturn
