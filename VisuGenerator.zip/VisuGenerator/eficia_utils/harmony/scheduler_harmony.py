"""Package harmony, module harmony.scheduler_harmony
Contient les classes permettant de gérer les programmes horaires Harmony.
"""

from __future__ import annotations

from typing import Any
from typing import TYPE_CHECKING
import urllib.parse
import json

from ..utils import find_obj_by_attr_value

if TYPE_CHECKING:
    from .harmony import Harmony
    from .objet_harmony import ObjetHarmony
    from .evenement_scheduler import EvenementScheduler


class SchedulerHarmony:
    """Classe représentant un programme horaire Harmony."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles_schedulers = [
            "object",
            "active",
            "id",
            "category",
            "end_day",
            "sortorder",
            "start_day",
            "start_month",
            "name",
            "end_month",
            "controlobject",
        ]
        self.id: int = None
        self.active: int = None
        self.harmony: Harmony = harmony
        self.name: str = ""
        self.events: list[EvenementScheduler] = []
        self.object: ObjetHarmony = None
        for cle in cles_schedulers:
            setattr(self, cle, dict_cles.get(cle))
        self.objet = self.get_object()

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return self.name

    def get_object(self) -> ObjetHarmony:
        """
        Trouve l'objet sur lequel porte le programme horaire.

        Returns
        -------
        obj : ObjetHarmony
            Objet que le programme horaire courant pilote.

        """
        obj = find_obj_by_attr_value(self.harmony.objects, "id", self.object)
        if obj:
            obj.schedulers.append(self)
        return obj

    def enable(self) -> None:
        """
        Active le programme horaire s'il n'est pas actif.

        Returns
        -------
        None.

        """
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        if self.active == 0 or self.active is None:
            self.harmony.requete_http(
                "scada-main/schedulers/status", methode="POST", data=encoded_data
            )
            self.active = 1

    def disable(self) -> None:
        """
        Désactive le programme horaire s'il n'est pas inactif.

        Returns
        -------
        None.

        """
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        if self.active == 1:
            self.harmony.requete_http(
                "scada-main/schedulers/status", methode="POST", data=encoded_data
            )
            self.active = 0
