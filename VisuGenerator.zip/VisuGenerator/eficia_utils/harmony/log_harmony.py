"""Module eficia_utils.harmony.log_harmony
Contient la classe LogHarmony, représentant une ligne du journal d'événements.
"""

from __future__ import annotations

import datetime
from typing import Any
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .harmony import Harmony


class LogHarmony:
    """Représente une ligne du journal d'événements."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles = ["id", "scriptname", "log", "logtime"]
        self.harmony = harmony
        self.logtime = None
        for cle in cles:
            setattr(self, cle, dict_cles.get(cle))
        if self.logtime is not None:
            self.logtime = datetime.datetime.fromtimestamp(self.logtime)
