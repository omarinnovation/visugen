"""Module eficia_utils.harmony.harmony
Contient la classe Harmony, qui représente un automate Harmony."""
from __future__ import annotations

import datetime
import json
import re
import time
import urllib.parse
from typing import Any
from functools import cached_property

import requests
from urllib3.util import url

from .alerte_harmony import AlerteHarmony
from .connected_device import DeviceModbus, LigneMappingModbus, ConnectedDevice
from .date_params_harmony import DateParamsHarmony
from .error_harmony import ErrorHarmony
from .evenement_scheduler import EvenementScheduler
from .ligne_reactor import LigneReactor
from .log_harmony import LogHarmony
from .network_params_harmony import NetworkParamsHarmony
from .objet_harmony import ObjetHarmony
from .scheduler_harmony import SchedulerHarmony
from .script_harmony import ScriptHarmony
from .userlib import UserLib
from ..utils import (
    find_obj_by_attr_value,
    int_to_knx_address,
    separer_port,
    request2,
    knx_address_to_int,
    read_file_in_script_subfolder,
)


class Harmony:
    """Représente un automate Harmony."""

    def __init__(
        self,
        ip: str,
        scheme: str = "http",
        username: str = "admin",
        password: str = "annapurna8091!",
        timeout_requests: tuple[int, int] = (10, 300),
        retry_requests: int = 3,
    ) -> None:
        """
        Constructeur.

        Parameters
        ----------
        ip : str
            Adresse IP de l'Harmony, par exemple :
                'iot.ensylog.com:12345'
                '10.128.135.129'
                '192.168.1.111'

        Returns
        -------
        None.

        """
        self.ip = ip
        self.host, self.port = separer_port(ip)
        self.requetes_executees = []
        self.scheme = scheme
        self.username = username
        self.password = password
        self.tag_relance = None
        self.name = None
        self.model = None
        self.version = None
        self.reactor_version = None
        self.date_texte_scripts = None
        self.anomalies_checklist = []
        self.timeout_requests = timeout_requests
        self.retry_requests = retry_requests
        dict_config = self.get_config()
        cles_config_harmony = [
            "nopassword",
            "brand",
            "version",
            "logobjects",
            "loglogs",
            "homepage",
            ".name",
            "autorange",
            "viscenter",
            "authdays",
            "time",
            "authsave",
            "visswipe",
            "fullscreen",
            "model",
            "visdimopacity",
            "fullversion",
            "logerrors",
            "redissave",
            "language",
            "remotegrpfilter",
            "autoadd",
            "firstday",
            "languages",
            ".type",
            "autorangevirtual",
            "visanim",
            "appsauth",
            "localrequest",
            ".anonymous",
            "userauth",
            "logread",
            "updatetime",
            "useralerts",
            "visframe",
            "perpage",
            "timezones",
            "remote",
            "visautogrow",
            "visdark",
            "logpolicy",
            "hidehomebtn",
            "tabsize",
            "logalerts",
            "visnoanim",
            "blockly",
            # Clés rajoutées manuellement (cf méthode get_config())
            "name",
            "reactor_version",
        ]
        for cle in cles_config_harmony:
            setattr(self, cle, dict_config.get(cle))
        # TODO: convertir time et updatetime en datetime Python
        # ne pas oublier de changer les types de colonnes dans la BDD
        if self.model is not None:
            self.model = self.model.replace("\x00", "")
        self.date_requete = datetime.datetime.now()

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return f"{self.name} ({self.ip})"

    def build_url(self, path: str) -> url.Url:
        """
        Construit une URL d'une requête à exécuter sur l'Harmony.

        Parameters
        ----------
        path : str
            chemin de la requête, par exemple
                'scada-main/scripting/main'

        Returns
        -------
        url_to_build : str
            URL de la requête.

        """
        url_to_build = url.Url(
            self.scheme, f"{self.username}:{self.password}", self.host, self.port, path
        )
        return url_to_build

    def requete_http(
        self,
        path: str,
        methode: str = "GET",
        headers: dict = None,
        **kwargs,
    ) -> requests.Response:
        """
        Exécute une requête HTTP sur l'Harmony.

        Parameters
        ----------
        path : str
            chemin de la requête, par exemple
                'scada-main/scripting/save'
        methode : str, optional
            Méthode de la requête HTTP. The default is 'GET'.
        **kwargs : divers
            autres arguments pouvant être passés à requests.request().

        Returns
        -------
        req : requests.request
            Requête HTTP.

        """
        if headers is None:
            headers = {"X-Requested-With": "XMLHttpRequest"}
        debut = datetime.datetime.now()
        passerelle_retried = False
        while True:
            try:
                req = request2(
                    self.retry_requests,
                    method=methode,
                    url=self.build_url(path),
                    headers=headers,
                    timeout=self.timeout_requests,
                    **kwargs,
                )
                duree = (datetime.datetime.now() - debut).total_seconds()
                data_to_append = {"path": path, "methode": methode, "duree": duree}
                for _, value in kwargs.items():
                    if isinstance(value, dict) and value.get("sql_query"):
                        data_to_append["sql_query"] = value["sql_query"]
                self.requetes_executees.append(data_to_append)
                return req
            except FileNotFoundError as err:
                if err.args[0] == "passerelle_db.lp n'est pas présent sur Harmony":
                    if not passerelle_retried:
                        self.creer_passerelle_db()
                        passerelle_retried = True
                    else:
                        raise FileNotFoundError(
                            "Impossible de créer passerelle_db.lp"
                        ) from err
                    continue
                raise err

    def get_config(self) -> dict[Any]:
        """
        Renvoie la config de l'Harmony en requêtant la page de base.

        Returns
        -------
        None.

        """
        data = {}
        req = self.requete_http("scada-main")
        expr = r'<script type="text/javascript">Config = (\{.+\});</script>'
        test = re.search(expr, req.text)
        if test.groups():
            json_data = test.groups()[0]
            data = json.loads(json_data)
        expr = "<title>(.+)</title>"
        test = re.search(expr, req.text)
        if test.groups():
            data["name"] = test.groups()[0]
        expr = r"(reactor.+?|rctl|ex)\.js"
        test = re.search(expr, req.text)
        if test is not None:
            data["reactor_version"] = test.groups()[0]
        return data

    @cached_property
    def networkparams(self) -> NetworkParamsHarmony:
        """
        Requête les paramètres réseau (IP) de l'Harmony.

        Raises
        ------
        ValueError
            Erreur s'ils ne sont pas trouvés.

        Returns
        -------
        NetworkParamsHarmony
            Objet représentant les paramètres réseau de l'automate.

        """
        raw_data = {"id": "eth0"}
        encoded_data = urllib.parse.quote(json.dumps(raw_data))
        req = self.requete_http(
            "flashsys/interfaces/form", "POST", data=f"data={encoded_data}"
        )
        tofind = r"data = (\{.+\})"
        matches = re.search(tofind, req.text)
        if not matches:
            raise ValueError("Configuration IP non trouvée")
        ip_params = json.loads(matches.groups()[0])["values"]
        return NetworkParamsHarmony(self, ip_params)

    @cached_property
    def dateparams(self) -> DateParamsHarmony:
        """
        Renvoie les "date parameters" de l'Harmony.

        Returns
        -------
        DateParamsHarmony
            Objet représentant les paramètres de date/heure de l'automate.

        """
        req = self.requete_http("scada-main/general/datetime-form", "POST")
        liste = req.json()["data"]
        return DateParamsHarmony(self, liste)

    @cached_property
    def scripts(self) -> list[ScriptHarmony]:
        """
        Retourne une liste des scripts de l'Harmony.

        Returns
        -------
        liste : list(dict)
            Liste des scripts de l'Harmony.

        """
        requete = """SELECT * FROM scripting"""
        results = self.execute_sql(requete)["data"]
        liste = [ScriptHarmony(self, ligne) for ligne in results]
        return liste

    @cached_property
    def libraries(self) -> list[UserLib]:
        req = self.requete_http("scada-main/scripting/main")
        scripts = [
            script for script in req.json()["data"] if script.get("type") == "user"
        ]

        regex = re.compile(r"\$S = (\{.+});")
        librairies = []
        for script in scripts:
            req = self.requete_http(
                "scada-main/main/editor", params={"id": script["id"]}
            )
            matches = re.search(regex, req.text)
            dic = json.loads(matches.groups()[0])["data"]
            lib = UserLib(self, dic)
            librairies.append(lib)
        return librairies

    @cached_property
    def fonctions_communes(self) -> str:
        """
        Renvoie le texte des "fonctions communes" de l'Harmony.

        Returns
        -------
        str
            Texte des fonctions communes.

        """
        cles = {"id": "userlib"}
        userlib = ScriptHarmony(self, cles)
        userlib_text = userlib.get_text()
        return userlib_text

    def set_userlib(self, new_text: str) -> None:
        """
        Envoie le texte des "fonctions communes" de l'Harmony.

        Parameters
        ----------
        texte : str
            Texte des fonctions communes.

        Returns
        -------
        None.

        """
        data_prefix = {
            "id": "userlib",
            "scriptonly": "true",
            "script": None,
            "scada-help-search": "",
        }
        quoted_data = urllib.parse.quote(json.dumps(data_prefix))
        quoted_text = urllib.parse.quote(new_text)
        encoded_data = f"data={quoted_data}&script={quoted_text}"
        req = self.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        response = req.json()
        if not response["success"]:
            matches = re.search(r"""\[.+\]:(\d+): (.+)""", response["errors"]["script"])
            (ligne, message_erreur) = matches.groups()
            error_text = f"Erreur ligne {ligne} : {message_erreur}"
            raise ValueError(error_text)
        self.__dict__["fonctions_communes"] = new_text

    @cached_property
    def script_demarrage(self) -> str:
        """
        Renvoie le texte du script de démarrage de l'Harmony.

        Returns
        -------
        str
            Texte du script de démarrage.

        """
        cles = {"id": "initscript"}
        initscript = ScriptHarmony(self, cles)
        initscript_text = initscript.get_text()
        return initscript_text

    def set_initscript(self, new_text: str) -> None:
        """
        Envoie le texte de l'initscript de l'Harmony.

        Parameters
        ----------
        texte : str
            Texte des fonctions communes.

        Returns
        -------
        None.

        """
        data_prefix = {
            "id": "initscript",
            "scriptonly": "true",
            "script": None,
            "scada-help-search": "",
        }
        quoted_data = urllib.parse.quote(json.dumps(data_prefix))
        quoted_text = urllib.parse.quote(new_text)
        encoded_data = f"data={quoted_data}&script={quoted_text}"
        req = self.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        response = req.json()
        if not response["success"]:
            matches = re.search(r"""\[.+\]:(\d+): (.+)""", response["errors"]["script"])
            (ligne, message_erreur) = matches.groups()
            error_text = f"Erreur ligne {ligne} : {message_erreur}"
            raise ValueError(error_text)
        self.__dict__["script_demarrage"] = new_text

    @cached_property
    def objects(self) -> list[ObjetHarmony]:
        """
        Retourne la liste des objets de l'Harmony.

        Returns
        -------
        liste2 : list(dict)
            Liste des objets de l'Harmony.

        """
        req = self.requete_http("scada-main/objects/main")
        liste = req.json()["data"]
        return [ObjetHarmony(self, elem) for elem in liste]

    def get_script(self, lookup: int | str) -> ScriptHarmony:
        """
        Trouve un script sur Harmony à partir d'une valeur recherchée.

        Parameters
        ----------
        lookup : int or str
            ID ou nom du script à rechercher.

        Raises
        ------
        ValueError
            Erreur si lookup n'est ni un entier, ni un string.

        Returns
        -------
        toreturn : ScriptHarmony
            Script recherché.

        """
        if isinstance(lookup, int):
            lookup_field = "id"
        elif isinstance(lookup, str):
            lookup_field = "name"
        else:
            raise ValueError(
                "lookup doit être un entier (ID script) "
                "ou un string (nom script)"
                f"{lookup} {type(lookup)}"
            )
        toreturn = find_obj_by_attr_value(self.scripts, lookup_field, lookup)
        return toreturn

    def get_library(self, lookup: str) -> UserLib:
        """
        Trouve une librairie utilisateur sur Harmony par son nom.

        Parameters
        ----------
        lookup : str
            nom de la librairie à rechercher.

        Raises
        ------
        ValueError
            Erreur si lookup n'est ni un entier, ni un string.

        Returns
        -------
        toreturn : ScriptHarmony
            Script recherché.

        """
        assert isinstance(lookup, str), "lookup doit être un string"
        toreturn = find_obj_by_attr_value(self.libraries, "name", lookup)
        return toreturn

    def get_object(self, lookup: int | str) -> ObjetHarmony:
        """
        Trouve un objet sur Harmony à partir d'une valeur recherchée.

        Parameters
        ----------
        lookup : int or str
            ID ou adresse de l'objet à rechercher.

        Raises
        ------
        ValueError
            Erreur si lookup n'est ni un entier, ni un string.

        Returns
        -------
        toreturn : ObjetHarmony
            Objet recherché.

        """
        if isinstance(lookup, int):
            lookup_field = "address"
        elif isinstance(lookup, str):
            lookup_field = "adresse"
        else:
            raise ValueError(
                "lookup doit être un entier (ID objet) "
                "ou un string (adresse de groupe)"
                f"{lookup} {type(lookup)}"
            )
        toreturn = find_obj_by_attr_value(self.objects, lookup_field, lookup)
        return toreturn

    @cached_property
    def reactor(self) -> list[LigneReactor]:
        """
        Retourne le reactor de l'Harmony.

        Returns
        -------
        liste : list(dict)
            Liste des objets du reactor de l'Harmony.

        """
        path = "scada-main/general/plugin"
        plugin = self.reactor_version
        if plugin == "ex":
            plugin = "_ex"
        params = {"plugin": plugin, "request": "main"}
        req = self.requete_http(path, params=params)
        liste = req.json()["data"]
        return [LigneReactor(self, ligne) for ligne in liste]

    @cached_property
    def devices(self) -> list[ConnectedDevice]:
        """
        Renvoie la liste des devices Modbus/BACnet/Lora associés.

        Returns
        -------
        liste_toreturn : list(ConnectedDevice)
            Liste des devices Modbus/BACnet/Lora connectés à l'automate.

        """
        liste_toreturn = []
        for obj in self.objects:
            dev_bacnet = obj.device_bacnet()
            dev_lora = obj.device_lora()

            if dev_lora and not any(
                dev_lora.deveui == d.deveui
                for d in liste_toreturn
                if d.type_connexion == "LoRa"
            ):
                liste_toreturn.append(dev_lora)
            elif dev_bacnet:
                liste_toreturn.append(dev_bacnet)
        for modbus_device in self.modbus_devices:
            liste_toreturn.append(modbus_device)
        return liste_toreturn

    @cached_property
    def modbus_devices(self) -> list[DeviceModbus]:
        """
        Retourne la liste des devices modbus de l'Harmony.

        ...en consultant la base de données

        Returns
        -------
        liste_modbus : list(DeviceModbus)
            Devices Modbus connectés à l'Harmony.

        """
        requete_modbus = """SELECT * FROM table_modbus_parameters_eficia"""
        liste_modbus = []
        try:
            data_sql = self.execute_sql(requete_modbus)
            modbus_parameters = data_sql["data"]
            liste_modbus = [
                DeviceModbus(harmony=self, dict_device=row, mapping_eficia=True)
                for row in modbus_parameters
            ]
        except ValueError as err:
            if "no such table" in str(err):
                pass
            else:
                raise err

        # On ajoute les devices modbus de l'ancienne base de données
        for dev in self.old_modbus_devices:
            final_dict = {
                "mb_slave_addr": dev["slave"],
                "slave_type": dev["profile"],
                "slave_name": dev["name"],
                "id_old_modbus": dev["id"],
            }
            if dev["proto"] == "tcp":
                final_dict["protocol_or_ip"] = dev["settings"]
                for key in ["baudrate", "parity", "stopbits", "databits", "duplex"]:
                    final_dict[key] = None
            elif dev["proto"] == "rtu":
                match_num_port = re.match(r"RTU (\d+)", dev["group"])
                if match_num_port is not None:
                    num_port = int(match_num_port.group(1))
                elif dev["group"] == "RTU":
                    num_port = 1
                else:
                    raise ValueError("Group value not recognized")

                if num_port == 1:
                    suffix = ""
                else:
                    suffix = f"_{num_port - 1}"

                final_dict["baudrate"] = int(self.modbus_ports["baudrate" + suffix])
                final_dict["duplex"] = self.modbus_ports["duplex" + suffix]
                final_dict["protocol_or_ip"] = self.modbus_ports["port" + suffix]
                final_dict["databits"] = int(self.modbus_ports["databits"])

                current_parity = self.modbus_ports["parity" + suffix]
                if current_parity == "0":
                    final_dict["parity"] = "N"
                    final_dict["stopbits"] = 1
                elif current_parity == "1":
                    final_dict["parity"] = "O"
                    final_dict["stopbits"] = 1
                elif current_parity == "2":
                    final_dict["parity"] = "E"
                    final_dict["stopbits"] = 1
                elif current_parity == "3":
                    final_dict["parity"] = "N"
                    final_dict["stopbits"] = 2
                else:
                    raise ValueError("Parity value not recognized")
            else:
                raise ValueError("Le protocole doit être tcp ou rtu")
            liste_modbus.append(
                DeviceModbus(harmony=self, dict_device=final_dict, mapping_eficia=False)
            )

        return liste_modbus

    @cached_property
    def raw_mapping_modbus(self) -> list[dict]:
        """
        Retourne la liste des lignes du mapping Modbus de l'Harmony.

        Returns
        -------
        liste_mapping : list(dict)
            Liste des lignes du mapping Modbus de l'Harmony.

        """
        requete_mapping = """SELECT * FROM table_mapping_eficia"""
        liste_mapping = []
        try:
            liste_mapping = self.execute_sql(requete_mapping)["data"]
        except ValueError:
            pass
        return liste_mapping

    @cached_property
    def mapping_modbus(self) -> list[LigneMappingModbus]:
        """
        Retourne la liste des lignes du mapping Modbus de l'Harmony.

        Returns
        -------
        liste_mapping : list(LigneMappingModbus)
            Liste des lignes du mapping Modbus de l'Harmony.

        """
        result = []
        for dev in self.modbus_devices:
            for ligne in dev.mapping:
                result.append(ligne)
        return result

    def synchroniser(self) -> requests.Response:
        """
        Equivalent d'appuyer sur le bouton "synchroniser les objets".

        (en bas à droite de la LogicMachine)

        Returns
        -------
        None.

        """
        req = self.requete_http("scada-main/general/sync")
        return req

    @cached_property
    def schedulers(self) -> list[SchedulerHarmony]:
        """
        Renvoie la liste des SchedulerHarmony de l'automate.

        Returns
        -------
        list(SchedulerHarmony)
            Programmes horaires de l'automate.

        """
        req = self.requete_http("scada-main/schedulers/main")
        liste = req.json()["data"]
        return [SchedulerHarmony(self, ligne) for ligne in liste]

    @cached_property
    def events(self) -> list[EvenementScheduler]:
        """
        Renvoie la liste des événements de programmes horaires.

        Returns
        -------
        list(EvenementScheduler)
            Liste des événements de programmes horaires.

        """
        req = self.requete_http("scada-main/schedulers/events-main")
        liste = req.json()["data"]
        return [EvenementScheduler(self, ligne) for ligne in liste]

    @cached_property
    def errors(self) -> list[ErrorHarmony]:
        """
        Requête les erreurs de l'Harmony.

        Returns
        -------
        data : list(ErrorHarmony)
            Liste des erreurs.

        """
        requete = """SELECT * FROM errors"""
        data = []
        try:
            results = self.execute_sql(requete)["data"]
            data = [ErrorHarmony(self, dic) for dic in results]
        except ValueError:
            pass
        return data

    @cached_property
    def logs(self) -> list[LogHarmony]:
        """
        Requête les logs de l'Harmony.

        Returns
        -------
        data : list(LogHarmony)
            Liste des logs.

        """
        requete = """SELECT * FROM logs"""
        data = []
        try:
            results = self.execute_sql(requete)["data"]
            data = [LogHarmony(self, dic) for dic in results]
        except ValueError:
            pass
        return data

    @cached_property
    def alerts(self) -> list[AlerteHarmony]:
        """
        Requête les alertes de l'Harmony.

        Returns
        -------
        data : list(AlerteHarmony)
            Liste des alertes.

        """
        requete = """SELECT * FROM alerts"""
        data = []
        try:
            results = self.execute_sql(requete)["data"]
            data = [AlerteHarmony(self, dic) for dic in results]
        except ValueError:
            pass
        return data

    def scripts_without_text(self):
        req = self.requete_http("scada-main/scripting/main")
        liste = req.json()["data"]
        return liste

    def execute_sql(self, sql_query: str) -> dict[Any]:
        """
        exécute une requête SQL sur la base de données de l'Harmony.

        Parameters
        ----------
        sql_query : str
            Requête SQL à exécuter.

        Raises
        ------
        ValueError
            Erreur éventuellement envoyée par l'exécution de la requête.

        Returns
        -------
        returned : json
            JSON avec :
                - "num_rows" = nombre de lignes lues/supprimées
                /insérées/modifiées selon que la requête
                soit SELECT/DELETE/INSERT/UPDATE.
                - "data" = données lues si c'est une requête SELECT.
        """
        params = {"sql_query": sql_query}
        req = self.requete_http("/user/passerelle_db.lp", params=params)
        returned = req.json()
        if returned.get("error"):
            raise ValueError(returned["error"])
        return returned

    def next_free_object(self, addr_debut: str, addr_fin: str) -> str:
        """
        Retourne la première adresse KNX dispo sur une certaine plage.

        Parameters
        ----------
        addr_debut : str
            Adresse KNX de début de la plage.
        addr_fin : str
            Adresse KNX de fin de la plage.

        Raises
        ------
        ValueError
            Erreur si la plage est pleine.

        Returns
        -------
        str
            Première adresse disponible dans la plage.

        """
        encoded_debut = knx_address_to_int(addr_debut)
        encoded_fin = knx_address_to_int(addr_fin)
        current = encoded_debut
        found = False
        while current <= encoded_fin:
            if self.get_object(current) is None:
                found = True
                break
            current += 1
        if not found:
            raise ValueError(
                "aucun objet disponible entre " f"{addr_debut} et {addr_fin}"
            )
        return int_to_knx_address(current)

    def tagged_objects(
        self, tag_list: list[str], mode: str = "or"
    ) -> list[ObjetHarmony]:
        """
        Retourne tous les objets ayant une certaine liste de tags.

        Parameters
        ----------
        tag_list : list(str)
            Liste de tags.
        mode : str, optional
            Si 'or', retourne tous les objets ayant AU MOINS UN
            des tags de la liste.
            Si 'and', retourne tous les objets ayant TOUS les tags de la liste.
            The default is 'or'.

        Raises
        ------
        ValueError
            Erreur si le mode n'est ni "or" ni "and".

        Returns
        -------
        found_objects : list(ObjetHarmony)
            Liste des objets trouvés.

        """
        if mode not in ["or", "and"]:
            raise ValueError(f"Mode incorrect : {mode}")
        found_objects = []
        for obj in self.objects:
            if mode == "or":
                found = any(tag in obj.tags for tag in tag_list)
            elif mode == "and":
                found = all(tag in obj.tags for tag in tag_list)
            if found:
                found_objects.append(obj)
        return found_objects

    def upload_graphics(self, filename: str, mode: str) -> None:
        """
        Upload des images ou des icônes sur l'Harmony.
        :param filename: Nom du fichier ZIP contenant les images/icônes
        :param mode: "icon" ou "image"
        :return: None
        """
        file_stream = open(filename, "rb")
        self.requete_http(
            "scada-main/visgraphics/save",
            methode="POST",
            files={"file": file_stream},
            data={"mode": mode},
        )
        file_stream.close()

    def delete_multiple_objects(self, obj_list: list[ObjetHarmony]) -> None:
        """
        Supprime plusieurs objets en une seule requête.
        :param obj_list: Liste des objets à supprimer
        :return: None
        """
        obj_ids = [obj.id for obj in obj_list]
        dico = {"ids": obj_ids}
        encoded_data = f"data={urllib.parse.quote(json.dumps(dico))}"
        self.requete_http(
            "scada-main/objects/delete", methode="POST", data=encoded_data
        )

    def update_multiple_objects(
        self,
        obj_list: list[ObjetHarmony],
        tags: list[str] = None,
        units: str = None,
        comment: str = None,
        datatype: str = None,
    ) -> None:
        """
        Met à jour plusieurs objets en une seule requête.
        :param obj_list: Liste des objets à mettre à jour
        :return: None
        """
        obj_ids = [str(obj.id) for obj in obj_list]
        dico = {"id": "", "address_list": ",".join(obj_ids)}
        if tags is not None:
            dico["tags"] = ", ".join(tags)
        if units is not None:
            dico["units"] = units
        if comment is not None:
            dico["comment"] = comment
        if datatype is not None:
            dico["datatype"] = datatype
        keys_list = ["tags", "units", "comment", "datatype"]
        present_keys = [key for key in keys_list if key in dico]
        if len(present_keys) == 0:
            raise ValueError("Aucun paramètre à mettre à jour")
        dico["field_list"] = ",".join(present_keys)
        encoded_data = f"data={urllib.parse.quote(json.dumps(dico))}"
        self.requete_http("scada-main/objects/save", methode="POST", data=encoded_data)

    def reboot(self) -> None:
        """
        Redémarre l'Harmony.
        :return: None
        """
        self.requete_http("flashsys/reboot/reboot", methode="POST", data={})

    @cached_property
    def storage(self) -> dict:
        """
        Récupère le storage de l'Harmony.
        :return: dict
        """
        headers = {
            "Referer": f"{self.scheme}://{self.ip}/apps/",
        }
        req = self.requete_http(
            path="/apps/localbus.lp?", methode="POST", headers=headers
        )
        if req.text == "":
            res = {}
            self.storage_ok = False
        else:
            res = req.json()["storage"]
            self.storage_ok = True
            if res == []:
                res = {}
        return res

    @cached_property
    def packages(self) -> list[dict]:
        """Retourne la liste des packages installés sur l'Harmony."""
        req = self.requete_http(
            path="flashsys/packages/main", methode="POST", params={"data": {}}
        )
        regex_find = re.search(
            r"""data\s=\s\[((\["[a-z\-0-9\._]+","[a-z0-9\.\-]+"\],?)+)\]""", req.text
        )

        if regex_find is not None:
            liste_packages = regex_find.group(1)
            regex_2 = re.findall(r"\[(.+?)\]", liste_packages)
            packages = []
            for ligne in regex_2:
                name, version = re.match(
                    r"""\"([^\",]+)\",\"([^\",]+)\"""", ligne
                ).groups()
                packages.append({"name": name, "version": version})
            return packages

        # Si la regex n'a pas fonctionné, on essaie avec une autre
        # Valable pour les Harmony avec un firmware ancien (2016 voire 2017)
        regex_find = re.search(
            r"""data\s=\s\[((\"[a-z\-0-9\._]+\s\-\s[a-z\-0-9\._]+\",?)+),\"{2}\]""",
            req.text,
        )
        if regex_find is not None:
            liste_packages = regex_find.group(1)
            regex_2 = re.findall(r"\"([^\"\s]+)\s\-\s([^\"\s]+)\"", liste_packages)
            packages = []
            for ligne in regex_2:
                packages.append({"name": ligne[0], "version": ligne[1]})
            return packages

        raise ValueError("Impossible de récupérer la liste des packages")

    @cached_property
    def sysinfo(self) -> dict:
        """Récupère les informations système de l'Harmony."""
        req = self.requete_http(path="flashsys/sysinfo/main", methode="POST", data={})

        regex_match = re.findall(r"data = (\{.+?\});", req.text)
        data = json.loads(regex_match[0])

        # gestion de cpuinfo et de meminfo
        for key in ["cpuinfo", "meminfo"]:
            new_dict = {}
            for elem in data[key]:
                # matches = re.findall(r"(.+?)\s*:\s(.+)", elem)
                matches = re.findall(r"(.+?)\s*:\s+(.+)", elem)
                if len(matches) > 0:
                    new_dict[matches[0][0]] = matches[0][1]
            data[key] = new_dict

        # gestion de partitions
        partition_keys = ["name", "size", "used", "avail", "mount"]
        new_partitions = []
        for part in data["partitions"]:
            new_partitions.append(dict(zip(partition_keys, part)))
        data["partitions"] = new_partitions

        # gestion de serial
        serial_keys = ["name", "description"]
        new_serial = []
        for ser in data["serial"]:
            new_serial.append(dict(zip(serial_keys, ser)))
        data["serial"] = new_serial

        # gestion de loadavg
        loadavg_keys = ["1min", "5min", "15min", "running", "total", "last_pid"]
        numbers = re.split(r"[\s\/]", data["loadavg"].strip())
        for i in range(3):
            numbers[i] = float(numbers[i])
        for i in range(3, 6):
            numbers[i] = int(numbers[i])
        data["loadavg"] = dict(zip(loadavg_keys, numbers))

        # gestion de kernel
        data["kernel"] = data["kernel"].replace("\n", "")

        # gestion de uptime
        uptime_keys = ["uptime", "idle"]
        numbers = data["uptime"].split(" ")
        numbers = [float(n) for n in numbers]
        data["uptime"] = dict(zip(uptime_keys, numbers))

        return data

    @cached_property
    def processes(self) -> list[dict]:
        """Récupère les processus en cours d'exécution sur l'Harmony."""
        req = self.requete_http(path="flashsys/processes/main", methode="POST", data={})
        regex_match = re.findall(r"data = \[(\[.+\])\]", req.text)
        if len(regex_match) > 0:
            processes = []
            for elem in re.findall(r"\[(\d+),\"(.+?)\"\]", regex_match[0]):
                if len(elem) > 0:
                    processes.append(
                        {
                            "pid": int(elem[0]),
                            "command": elem[1].strip().replace(r"\/", "/"),
                        }
                    )
            return processes

        # Si la regex n'a pas fonctionné, on essaie avec une autre
        # Valable pour les Harmony avec un firmware ancien (2016 voire 2017)
        regex_old = re.findall(r"""data = \[(".+",?)+,\"{2}\]""", req.text)
        if len(regex_old) > 0:
            processes = []
            for ligne in re.findall(
                r"""\"\s*(\d+)\s(\w+)\s*(\d+)\s+([A-Z<]+)\s+(.+?)\"""", regex_old[0]
            ):
                if ligne[2] == "0":
                    continue
                if ligne[0] == "1" and ligne[4] == "init":
                    continue
                processes.append(
                    {"pid": int(ligne[0]), "command": ligne[4].replace(r"\/", "/")}
                )
            return processes
        raise ValueError("Impossible de récupérer la liste des processus")

    @cached_property
    def neighbours(self):
        """Renvoie la liste des produits voisins"""
        final = []
        req = self.requete_http(path="scada-main/general/neighbours", methode="GET")
        raw = req.json()["neighbours"]
        for elem in raw:
            to_delete = f" ({elem['ip']})"
            final.append(
                {"ip": elem["ip"], "name": elem["name"].replace(to_delete, "").strip()}
            )
        return final

    def get_scheduler(self, lookup: str) -> SchedulerHarmony:
        """
        Trouve un événement sur Harmony via son nom

        Parameters
        ----------
        lookup : str
            nom de l'événement à rechercher.

        Returns
        -------
        toreturn : SchedulerHarmony
            Scheduler recherché.

        """
        toreturn = find_obj_by_attr_value(self.schedulers, "name", lookup)
        return toreturn

    @cached_property
    def sql_tables(self) -> list[dict]:
        """Renvoie la liste des tables de la base de données
        SQLite de l'Harmony."""
        requete_tables = """SELECT name, sql, rootpage
FROM sqlite_master
WHERE type='table'"""
        tables = self.execute_sql(requete_tables)
        return tables["data"]

    @cached_property
    def modbus_ports(self) -> list[dict]:
        req = self.requete_http(
            path="scada-main/general/plugin",
            methode="POST",
            params={"plugin": "modbus", "request": "config-form"},
        )
        return req.json()["data"]

    @cached_property
    def old_modbus_devices(self) -> list[dict]:
        req = self.requete_http(
            path="scada-main/general/plugin",
            methode="GET",
            params={"plugin": "modbus", "request": "device-list"},
        )
        return req.json()["data"]

    def creer_passerelle_db(self):
        """Crée le fichier passerelle.db s'il n'existe pas dans l'automate."""
        now = int(datetime.datetime.timestamp(datetime.datetime.now()))
        nom_script = f"{now} Création passerelle_db.lp"
        script_params = {
            "name": nom_script,
            "type": "resident",
            "active": 0,
            "category": "SYSTEM",
            "description": "script créé automatiquement depuis Python",
            "params": "60",
            "id": "",
        }
        encoded_data = "data=" + urllib.parse.quote(json.dumps(script_params))
        self.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )

        for elem in self.scripts_without_text():
            if elem["name"] == nom_script:
                script_id = elem["id"]
                break
        else:
            raise ValueError("Impossible de trouver le script création passerelle_db")

        data_prefix = {"id": script_id, "scriptonly": "true"}
        quoted_data = urllib.parse.quote(json.dumps(data_prefix))
        quoted_text = urllib.parse.quote(
            read_file_in_script_subfolder("creation_passerelle_db.lua")
        )
        encoded_data = f"data={quoted_data}&script={quoted_text}"
        req = self.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        response = req.json()
        if not response["success"]:
            matches = re.search(r"""\[.+\]:(\d+): (.+)""", response["errors"]["script"])
            (ligne, message_erreur) = matches.groups()
            error_text = f"Erreur ligne {ligne} : {message_erreur}"
            raise ValueError(error_text)

        data_to_send = {"id": script_id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        self.requete_http(
            "scada-main/scripting/status", methode="POST", data=encoded_data
        )
        time.sleep(5)
        self.requete_http(
            "scada-main/scripting/delete", methode="POST", data=encoded_data
        )

    def parse_ssh_command(self):
        """Parse la commande SSH pour extraire les informations utiles."""
        regex_tunnel_ssh = re.compile(r"0\.0\.0\.0:(\d+):((?:\d+\.?){4}):(\d+)")
        liste_tunnels = []
        for ssh_command in self.storage["ssh_command"]:
            for match in regex_tunnel_ssh.finditer(ssh_command):
                distant_port = int(match.group(1))
                local_ip = match.group(2)
                local_port = int(match.group(3))
                liste_tunnels.append(
                    {
                        "local_ip": local_ip,
                        "local_port": local_port,
                        "distant_port": distant_port,
                    }
                )
        return liste_tunnels

    @cached_property
    def old_modbus_profiles(self):
        path = "/scada-main/general/plugin"
        params = {"plugin": "modbus", "request": "profile-list"}
        req = self.requete_http(path, params=params)

        profile_list = req.json()["data"]
        for profile in profile_list:
            req = self.requete_http(
                path=path,
                methode="GET",
                params={
                    "plugin": "modbus",
                    "request": "profile-download",
                    "profile": profile["name"],
                },
            )
            cleaned_zeroes = re.sub(
                r"""\"address\":\s0+(\d+)""", r""""address": \1""", req.text
            )
            profile["mapping"] = json.loads(cleaned_zeroes)["mapping"]
        return profile_list
