"""Module eficia_utils.harmony.objet_harmony
Contient la classe ObjetHarmony, représentant un objet KNX sur Harmony.
"""
from __future__ import annotations

import datetime
import json
import re
import urllib.parse
from typing import Any
from typing import TYPE_CHECKING

import requests

from .connected_device import DeviceBacnet, DeviceLora
from ..utils import (
    int_to_knx_address,
    find_obj_by_attr_value,
    sqlite_escape,
    knx_address_to_int,
)

if TYPE_CHECKING:
    from .harmony import Harmony


class ObjetHarmony:
    """Classe représentant un objet KNX sur Harmony."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles_objets = [
            "filter_tp",
            "id",
            "disablelog",
            "datahex",
            "units",
            "comment",
            "visparams",
            "updatetime",
            "datatype",
            "datadec",
            "address",
            "readoninit",
            "name",
            "highpriolog",
            "export",
            "pollinterval",
            "covincr",
            "filter_ip",
            "adresse",
        ]
        self.harmony = harmony
        self.units = None
        self.comment = None
        self.name = None
        self.updatetime = None
        self.address = None
        self.id = None
        self.ligne_reactor = None
        self.softlink = None
        self.is_sortie_generique = False
        self.is_compteur_generique = False
        self.is_entree_generique = False
        self.datadec = None
        self.enums = None
        self.disablelog = None
        self.export = None
        self.pollinterval = None
        self.adresse = None
        self.schedulers = []
        for cle in cles_objets:
            setattr(self, cle, dict_cles.get(cle))
        if self.address is not None and self.adresse is None:
            self.adresse = int_to_knx_address(self.address)
        elif self.adresse is not None and self.address is None:
            self.address = knx_address_to_int(self.adresse)
            self.id = self.address
        if dict_cles.get("tags") is not None:
            self.tags = dict_cles["tags"]
        elif dict_cles.get("tagcache") == "" or not dict_cles.get("tagcache"):
            self.tags = []
        else:
            self.tags = dict_cles.get("tagcache").split(", ")
        if dict_cles.get("enums") == "" or dict_cles.get("enums") is None:
            self.enums = {}
        elif isinstance(dict_cles.get("enums"), str):
            self.enums = json.loads(dict_cles["enums"])
        elif isinstance(dict_cles.get("enums"), dict):
            self.enums = dict_cles["enums"]
        if self.units is None:
            self.units = ""
        if self.comment is None:
            self.comment = ""
        if self.pollinterval is None:
            self.pollinterval = ""
        self.tags_pilotage = self.get_tags_pilotage()
        if self.name:
            self.is_sortie_generique = bool(re.match(r"^Sortie #\d+$", self.name))
            self.is_compteur_generique = bool(re.match(r"^Comptage #\d+$", self.name))
            self.is_entree_generique = bool(re.match(r"^Entr[ée]e #\d+$", self.name))
        if self.updatetime:
            self.date_maj = datetime.datetime.fromtimestamp(self.updatetime)

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return f"{self.adresse} {self.name}"

    def create(self) -> None:
        """
        Crée l'objet sur l'Harmony.

        Raises
        ------
        ValueError
            Erreur s'il existe déjà un objet au nom ou à l'adresse
            spécifiée.

        Returns
        -------
        None.

        """
        existing_object = self.harmony.get_object(self.adresse)
        if existing_object:
            raise ValueError("Un objet à cette adresse existe déjà")
        if find_obj_by_attr_value(self.harmony.objects, "name", self.name):
            raise ValueError("Un objet portant ce nom existe déjà")
        keys = ["name", "datatype", "units", "pollinterval", "comment"]
        dico = {key: getattr(self, key) for key in keys}
        dico["address"] = self.adresse
        dico["tags"] = ", ".join(self.tags)
        if self.disablelog == 0:
            dico["disablelog"] = "on"
        if self.export == 1:
            dico["export"] = "on"
        encoded_data = f"data={urllib.parse.quote(json.dumps(dico))}"
        self.harmony.requete_http(
            "scada-main/objects/save", methode="POST", data=encoded_data
        )
        self.harmony.objects.append(self)

    def delete(self) -> None:
        """
        Supprime l'objet de l'Harmony.

        Returns
        -------
        None

        """
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        self.harmony.requete_http(
            "scada-main/objects/delete", methode="POST", data=encoded_data
        )
        # puis après suppression,
        # on met à jour la liste des objets de l'Harmony
        del self.harmony.__dict__["objects"]

    def get_tags_pilotage(self) -> list[str]:
        """
        Trouve tous les tags de pilotage sur un objet.

        Returns
        -------
        liste_tags : list(str)
            Liste des tags de pilotage sur l'objet.

        """
        liste_tags_pilotage = [
            "STOCKLIGHT",
            "STOCKLIGHT-NI",
            "STOCKLIGHT_OFF",
            "STOCKLIGHT_OFF-NI",
            "STOCKLIGHT_PULSE",
            "STOCKLIGHT_PULSE-NI",
            "TRADELIGHT",
            "TRADELIGHT-NI",
            "TRADELIGHT2",
            "TRADELIGHT2-NI",
            "TRADELIGHT3",
            "TRADELIGHT3-NI",
            "TRADELIGHT4",
            "TRADELIGHT4-NI",
            "TRADELIGHT5",
            "TRADELIGHT5-NI",
            "TRADELIGHT6",
            "TRADELIGHT6-NI",
            "TRADELIGHT7",
            "TRADELIGHT7-NI",
            "SMARTONOFF",
            "SMARTONOFF-NI",
            "PARKING",
            "PARKING-NI",
            "PARKING_TRADE",
            "PARKING_TRADE-NI",
            "RAC",
            "RAC-NI",
            "ENSEIGNE",
            "ENSEIGNE-NI",
            "RONDE",
            "RONDE-NI",
            "CONTACT_CVC",
            "CONTACT_CVC-NI",
            "CONTACT_CVC_CHAUD",
            "CONTACT_CVC_CHAUD-NI",
            "CONTACT_CVC_FROID",
            "CONTACT_CVC_FROID-NI",
            "CONTACT_CVC_RESERVE",
            "CONTACT_CVC_RESERVE-NI",
            "CONTACT_CVC_CHAUD_HYDRAU",
            "CONTACT_CVC_CHAUD_HYDRAU-NI",
            "HVAC_CHAUFFERIE_BRULEUR",
            "HVAC_CHAUFFERIE_GEG",
            "HVAC_CHAUFFERIE_POMPE",
            "HVAC_CHAUFFERIE_POMPE_CHAUD",
            "HVAC_CHAUFFERIE_POMPE_GEG",
            "HVAC_CHAUFFERIE_AEROTHERME",
            "HVAC_CHAUFFERIE_AEROTHERME_RESERVE",
            "HVAC_CHAUFFERIE_RAC",
            "ONH24",
            "ONH24-NI",
            "OFFH24",
            "OFFH24-NI",
        ]

        liste_tags = [tag for tag in self.tags if tag in liste_tags_pilotage]
        return liste_tags

    def device_bacnet(self) -> DeviceBacnet:
        """
        Retourne le device BACnet associé.

        Returns
        -------
        new_device : DeviceBacnet
            Device Bacnet correspondant.

        """
        new_device = None
        if self.name and (
            "BCN_STATS" in self.tags
            or re.search(r"\-\sStatistiques BACnet$", self.name)
        ):
            match_string = re.search(
                r"^(.+)_(\d+)\s\-\sStatistiques BACnet$", self.name
            )
            if match_string:
                device_name = match_string.groups()[0]
                new_device = DeviceBacnet(self.harmony, device_name)
        return new_device

    def device_lora(self) -> DeviceLora:
        """
        Retourne le device LoRa associé.

        Returns
        -------
        new_device : DeviceLora
            DeviceLora associé à l'objet courant.

        """
        new_device = None
        if self.name and any(re.search("^DEVEUI_", tag) for tag in self.tags):
            for tag in self.tags:
                found_deveui = re.search("^DEVEUI_([A-Fa-f0-9]{16})", tag)
                if found_deveui:
                    deveui = found_deveui.groups()[0]
                    break
            match_adeunis = re.search(r"Adeunis DRY CONTACT_(\d+)", self.name)

            match_mcf88 = re.search(r"MCF88_(\d+)", self.name)

            match_elsys_ers = re.search(r"^A81758FFF", deveui)
            cas_prevu = True
            if match_adeunis:
                nom = "Adeunis Dry Contact"
                numero = match_adeunis.groups()[0]
            elif match_mcf88:
                nom = "MCF88"
                numero = match_mcf88.groups()[0]
            elif match_elsys_ers:
                nom = "Elsys ERS"
                numero = None
            else:
                cas_prevu = False
            if cas_prevu:
                new_device = DeviceLora(self.harmony, nom, deveui, numero)
        return new_device

    def connexion_softlink(self) -> tuple[str]:
        """
        Retourne la connexion SOFTLINK de l'objet.

        Si l'objet a une connexion SOFTLINK/LINKIO vers un device Modbus/LoRa,
        retourne le numéro de ce device et le type de connexion


        Returns
        -------
        toreturn : tuple
            tuple contenant le numéro du device et le type de connexion.
            par exemple, si l'objet a les tags SOFTLINK, LINKIO_1006DO3
            cette fonction retourne le tuple (1006, 'DO3')
        """
        toreturn = None
        num_device = None
        linkio_target = None
        if "SOFTLINK" in self.tags:
            for tag in self.tags:
                match_linkio = re.search(r"LINKIO_(\d*)([A-Z\d]+)", tag)
                if match_linkio:
                    num_device, linkio_target = match_linkio.groups()
                    break
            if linkio_target and not num_device:
                match_num = re.match(r".+_(\d+)\s\-\s.+", self.name)
                if match_num:
                    num_device = match_num.groups()[0]
            toreturn = (num_device, linkio_target)
        # TODO: gérer le cas des LINK_x/y/z, notamment en BACnet
        return toreturn

    def ecrire_valeur(self, valeur: Any) -> requests.Response:
        """
        Ecrit une nouvelle valeur sur l'objet.

        Parameters
        ----------
        valeur : any
            Valeur à écrire dans l'objet KNX.

        Returns
        -------
        req : requests.request
            Requête HTTP envoyée à l'Harmony.

        """
        params = {
            "r": "grp",
            "fn": "write",
            "value": valeur,
            "alias": self.adresse,
            "m": "json",
        }
        req = self.harmony.requete_http("scada-remote", params=params)
        self.datadec = valeur
        del self.harmony.__dict__["objects"]
        return req

    def renommer(self, new_name: str) -> None:
        """
        Renomme l'objet sur Harmony.

        Parameters
        ----------
        new_name : str
            Nouveau nom pour l'objet.

        Raises
        ------
        ValueError
            Erreur si l'Harmony a déjà un autre objet avec ce nom.

        Returns
        -------
        None.

        """
        conflict_object = find_obj_by_attr_value(self.harmony.objects, "name", new_name)
        if conflict_object:
            raise ValueError(
                f"Impossible de renommer le {self.adresse} en "
                f"{new_name} : un autre objet "
                f"({conflict_object.adresse}) porte "
                "déjà ce nom !"
            )
        # TODO: passer plutôt par une requête HTTP
        escaped = sqlite_escape(new_name)
        sql_query = f"UPDATE objects SET name = {escaped} " f"WHERE id = {self.id}"
        self.harmony.execute_sql(sql_query)
        self.name = new_name

    def update_enums(self) -> None:
        """
        Met à jour dans l'Harmony les "custom values" de l'objet.

        Returns
        -------
        None.

        """
        data_to_encode = {"id": self.id, "enums": json.dumps(self.enums)}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_encode))}"
        self.harmony.requete_http(
            "scada-main/objects/setenums", "POST", data=encoded_data
        )

    def add_tags(self, tags: list[str]) -> None:
        """
        Ajoute des tags à l'objet et l'enregistre sur Harmony.

        Parameters
        ----------
        tags : list(str)
            Liste de tags à ajouter à l'objet.

        Raises
        ------
        ValueError
            Erreur si l'objet n'existe pas encore dans l'automate.

        Returns
        -------
        None.

        """
        existing_object = self.harmony.get_object(self.adresse)
        if not existing_object:
            raise ValueError("L'objet n'existe pas encore")
        change = False
        for new_tag in tags:
            if new_tag not in self.tags:
                change = True
                self.tags.append(new_tag)
        if change:
            keys = ["name", "datatype", "units", "pollinterval", "comment", "id"]
            dico = {key: getattr(self, key) for key in keys}
            dico["tags"] = ", ".join(self.tags)
            if self.disablelog == 0:
                dico["disablelog"] = "on"
            if self.export == 1:
                dico["export"] = "on"
            encoded_data = f"data={urllib.parse.quote(json.dumps(dico))}"
            self.harmony.requete_http(
                "scada-main/objects/save", methode="POST", data=encoded_data
            )

    def remove_tags(self, tags: list[str]) -> None:
        """
        Retire des tags de l'objet et l'enregistre sur Harmony.

        Parameters
        ----------
        tags : list(str)
            Liste de tags à supprimer de l'objet.

        Raises
        ------
        ValueError
            Erreur si l'objet n'existe pas encore dans l'automate.

        Returns
        -------
        None.

        """
        existing_object = self.harmony.get_object(self.adresse)
        if not existing_object:
            raise ValueError("L'objet n'existe pas encore")
        change = False
        for tag_to_remove in tags:
            if tag_to_remove in self.tags:
                change = True
                self.tags.remove(tag_to_remove)
        if change:
            keys = ["name", "datatype", "units", "pollinterval", "comment", "id"]
            dico = {key: getattr(self, key) for key in keys}
            dico["tags"] = ", ".join(self.tags)
            if self.disablelog == 0:
                dico["disablelog"] = "on"
            if self.export == 1:
                dico["export"] = "on"
            encoded_data = f"data={urllib.parse.quote(json.dumps(dico))}"
            self.harmony.requete_http(
                "scada-main/objects/save", methode="POST", data=encoded_data
            )
