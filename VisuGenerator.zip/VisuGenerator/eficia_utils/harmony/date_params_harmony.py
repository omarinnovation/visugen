"""Module eficia_utils.harmony.date_params_harmony
Contient la classe DateParamsHarmony, représentant les paramètres de date/heure
"""
from __future__ import annotations

import datetime
from typing import Any
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .harmony import Harmony


class DateParamsHarmony:
    """
    Paramètres de date/heure.

    Un objet DateParamsHarmony représente l'ensemble des paramètres
    de date/heure d'un Harmony, accessibles en consultant le menu date/heure
    de l'automate.
    """

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles_dateparams = [
            "longitude",
            "latitude",
            "timeh",
            "ntp",
            "times",
            "current",
            "date",
            "timem",
            "firstday",
            "timezone",
        ]
        self.harmony = harmony
        self.current = None
        for cle in cles_dateparams:
            setattr(self, cle, dict_cles.get(cle))
        correct_datetime = self.current.replace("  ", " 0")
        self.date_harmony = datetime.datetime.strptime(
            correct_datetime, "%a %b %d %H:%M:%S %Y"
        )
