"""Module eficia_utils.harmony.network_params_harmony
Contient la classe NetworkParamsHarmony, représentant les paramètres réseau
d'un Harmony."""
from __future__ import annotations

from typing import Any
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .harmony import Harmony


class NetworkParamsHarmony:
    """paramètres IP d'un Harmony."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]):
        self.ipaddr: str = None
        cles_networkparams = ["ipaddr", "netmask", "gateway", "dns", "dns_alt"]
        self.harmony = harmony
        for cle in cles_networkparams:
            setattr(self, cle, dict_cles.get(cle))
