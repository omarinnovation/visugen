"""Module eficia_utils.harmony.ligne_reactor
Contient la classe LigneReactor, représentant une ligne du Reactor
d'un Harmony."""
from __future__ import annotations

from typing import Any
from typing import TYPE_CHECKING

from ..utils import find_obj_by_attr_value

if TYPE_CHECKING:
    from .harmony import Harmony
    from .objet_harmony import ObjetHarmony


class LigneReactor:
    """Classe représentant une ligne du Reactor d'un Harmony."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles_reactor = [
            "value",
            "param_5",
            "id",
            "updatetime",
            "param_6",
            "pid",
            "address",
            "param_1",
            "type",
            "param_2",
            "bus_write",
            "param_3",
            "name",
            "param_4",
            "address_add_4",
            "address_add_1",
            "address_add_3",
            "address_lock",
            "address_stat",
            "address_add_2",
            "address_add_5",
            "address_add",
        ]
        self.harmony = harmony
        self.address = None
        self.param_1 = None
        self.id = None
        self.name = None
        for cle in cles_reactor:
            setattr(self, cle, dict_cles.get(cle))
        if self.address == "":
            self.address = None
        self.objet = self.associer_objet()

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return f"{self.id} {self.name}"

    def associer_objet(self) -> ObjetHarmony:
        """
        Retourne l'objet associé.

        Si la ligne du Reactor n'est pas vierge (i.e. si elle est associée
        à un ObjetHarmony), retourne cet objet ; et met à jour l'attribut
        "ligne_reactor" de cet objet également.

        Returns
        -------
        to_return : ObjetHarmony
            Objet associé à la ligne du Reactor.

        """
        to_return = None
        if self.address is not None:
            to_return = find_obj_by_attr_value(self.harmony.objects, "id", self.address)
            if to_return is not None:
                to_return.ligne_reactor = self
        return to_return
