"""Module harmony.script_harmony
Contient les classes permettant de gérer les scripts Harmony.
"""

from __future__ import annotations

import json
import re
import urllib.parse
from typing import Any
from typing import TYPE_CHECKING

from ..utils import find_obj_by_attr_value

if TYPE_CHECKING:
    from .harmony import Harmony


class ScriptHarmony:
    """Classe représentant un script Harmony."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles_scripts = [
            "description",
            "active",
            "category",
            "id",
            "type",
            "params",
            "name",
            "subparams",
            "source",
        ]
        self.harmony = harmony
        self.name = ""
        self.id = None
        self.type = None
        self.active = None
        self.params = None
        for cle in cles_scripts:
            setattr(self, cle, dict_cles.get(cle))
        if "script" in dict_cles:
            self.text = dict_cles["script"]
        elif "text" in dict_cles:
            self.text = dict_cles["text"]

    def __str__(self) -> str:
        """
        représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return self.name

    def get_text(self) -> str:
        """
        Va requêter en direct sur Harmony le texte du script, et le retourne.

        Returns
        -------
        script_text : str
            Texte intégral du script.

        """
        req = self.harmony.requete_http(
            "scada-main/main/editor", params={"id": self.id}
        )
        page_text = req.text
        if re.search(r"\$S = (\{\"data\":)?(\[\])(,\"success\":true\})?;", page_text):
            raise ValueError("SCRIPT NOT FOUND")
        html_code = re.search(r"\$S = (\{.+\});", page_text).group(1)
        script_text = json.loads(html_code)["data"]["script"]
        return script_text

    def update_text(self) -> None:
        """
        Requête le texte du script en direct sur Harmony.

        Returns
        -------
        None.

        """
        self.text = self.get_text()

    def delete(self) -> None:
        """
        Supprime le script de l'Harmony.

        Returns
        -------
        None

        """
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        self.harmony.requete_http(
            "scada-main/scripting/delete", methode="POST", data=encoded_data
        )
        # puis après suppression,
        # on invalide le cache de la liste des scripts de l'Harmony
        if "scripts" in self.harmony.__dict__:
            del self.harmony.__dict__["scripts"]

    def create_empty(self) -> None:
        """
        Si le script n'existe pas encore sur Harmony, le crée vide.

        Raises
        ------
        ValueError
            Erreur si la création échoue.

        Returns
        -------
        None.

        """
        self.check_params_creation()
        included_keys = (
            "name",
            "params",
            "active",
            "subparams",
            "category",
            "description",
            "id",
            "type",
            "source",
        )
        script_params = self.__dict__
        script_params["id"] = ""
        script_params = {
            k: script_params[k]
            for k in included_keys
            if k in script_params and script_params[k] is not None
        }
        if script_params.get("active") == 1:
            script_params["active"] = "on"
        if script_params.get("subparams") == "1":
            script_params["subparams"] = "on"
        if script_params.get("source") is True:
            script_params["source"] = "on"
        elif script_params.get("source") is False:
            script_params.pop("source")
        if script_params["type"] == "user":
            script_params["name"] = script_params["name"].replace("user.", "")
            script_params["description"] = ""
        encoded_data = "data=" + urllib.parse.quote(json.dumps(script_params))
        self.harmony.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        del self.harmony.__dict__["scripts"]
        new_script = find_obj_by_attr_value(
            self.harmony.scripts, "name", self.name
        )
        if not new_script:
            raise ValueError("La création du script semble avoir échoué")
        self.id = new_script.id
        self.harmony.scripts.append(self)

    def edit(self, new_text: str) -> None:
        """
        Change le texte du script sur l'Harmony.

        Parameters
        ----------
        new_text : str
            Nouveau texte du script.

        Raises
        ------
        ValueError
            Les éventuelles erreurs à l'enregistrement du script sur Harmony.

        Returns
        -------
        None.

        """
        data_prefix = {"id": self.id, "scriptonly": "true"}
        if self.type == "user":
            data_prefix["script"] = None
            data_prefix["scada-help-search"] = ""
        quoted_data = urllib.parse.quote(json.dumps(data_prefix))
        quoted_text = urllib.parse.quote(new_text)
        encoded_data = f"data={quoted_data}&script={quoted_text}"
        req = self.harmony.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        response = req.json()
        if not response["success"]:
            matches = re.search(r"""\[.+\]:(\d+): (.+)""", response["errors"]["script"])
            (ligne, message_erreur) = matches.groups()
            error_text = f"Erreur ligne {ligne} : {message_erreur}"
            raise ValueError(error_text)
        self.text = new_text

    def create_and_save(self) -> None:
        """
        Crée le script vierge sur l'harmony puis modifie son texte.

        Raises
        ------
        ValueError
            Erreur si le script est fourni sans texte.

        Returns
        -------
        None.

        """
        if not self.text:
            raise ValueError("Le texte du script doit être renseigné")
        self.create_empty()
        self.edit(self.text)

    def check_params_creation(self) -> None:
        """
        Vérification des paramètres du script avant création.

        Avant de créer un nouveau script sur Harmony, vérification que les
        paramètres du script sont valides, et que l'Harmony ne possède pas
        déjà un script portant ce nom.

        Raises
        ------
        ValueError
            Erreur si les paramètres du script sont invalides ou si l'Harmony
            a déjà un script portant ce nom.

        Returns
        -------
        None.

        """
        if not self.name:
            raise ValueError("Impossible de créer un script sans nom")
        if self.harmony.get_script(self.name):
            raise ValueError("Un script portant ce nom existe déjà")
        if not self.type:
            raise ValueError("Impossible de créer un script sans type")
        if self.type not in ("event", "scheduled", "resident", "user"):
            raise ValueError(f"Type de script invalide : {self.type}")
        if not (self.params or self.type == "user"):
            raise ValueError("Impossible de créer un script sans paramètres")
        if self.type == "event":
            if not isinstance(self.params, str):
                raise ValueError(
                    "Pour un script sur événement, params doit être "
                    "une chaîne de caractères"
                )
        if self.type == "resident":
            if not re.match(r"^\d{1,2}$", self.params):
                raise ValueError(
                    "Pour un script cyclique, params doit être "
                    "un nombre entier entre 0 et 60"
                )
            if int(self.params) not in range(61):
                raise ValueError(
                    "Pour un script cyclique, params doit être "
                    "un nombre entier entre 0 et 60"
                )
        if self.type == "scheduled":
            pat = r"^(((\d+(\-\d+)?,)*\d+(\-\d+)?|\*(/\d+)?)\s){4}"
            pat = pat + r"(((\d+(\-\d+)?,)*\d+(\-\d+)?|\*(/\d+)?))$"
            if not isinstance(self.params, str):
                raise ValueError(
                    "Pour un script planifié, params doit être "
                    "une chaîne de caractères"
                )
            if not re.search(pat, self.params):
                raise ValueError(
                    "Syntaxe incorrecte pour les params du script planifié : "
                    f'"{self.params}"'
                )

    def enable(self) -> None:
        """
        Active le script s'il n'est pas actif.

        Returns
        -------
        None.

        """
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        if self.active == 0 or self.active is None:
            self.harmony.requete_http(
                "scada-main/scripting/status", methode="POST", data=encoded_data
            )
            self.active = 1

    def disable(self) -> None:
        """
        Désactive le script s'il n'est pas inactif.

        Returns
        -------
        None.

        """
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        if self.active == 1:
            self.harmony.requete_http(
                "scada-main/scripting/status", methode="POST", data=encoded_data
            )
            self.active = 0

    def run(self) -> None:
        """
        Démarre le script (script planifié).

        Returns
        -------
        None.

        """
        assert self.type == "scheduled", (
            f'"{self}" is not a scheduled script, so the run() method '
            "can't be used on it"
        )
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        req = self.harmony.requete_http(
            "scada-main/scripting/run", methode="POST", data=encoded_data
        )
        response = req.json()
        assert response["success"], (
            f'Script "{self}" not launched, probably because '
            "an instance is already running."
        )

    def change_params(self, new_params: dict) -> None:
        """Change les paramètres du script et sauvegarde sur l'Harmony."""
        included_keys = (
            "name",
            "params",
            "active",
            "subparams",
            "category",
            "description",
            "id",
            "type",
        )
        for key in included_keys:
            if key not in new_params:
                new_params[key] = self.__dict__[key]
        if new_params.get("active") == 1:
            new_params["active"] = "on"
        if new_params.get("subparams") == "1":
            new_params["subparams"] = "on"
        if "description" not in new_params or new_params["description"] is None:
            new_params["description"] = ""
        encoded_data = "data=" + urllib.parse.quote(json.dumps(new_params))
        self.harmony.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        self.__dict__.update(new_params)
