"""Module eficia_utils.harmony.connected_device
Contient les classes permettant de gérer les devices connectés à un Harmony.
(Modbus, Lora, Bacnet)
"""

from __future__ import annotations

import re
from typing import Any
from typing import TYPE_CHECKING

from ..utils import find_obj_by_attr_value, int_to_knx_address

if TYPE_CHECKING:
    from .harmony import Harmony
    from .objet_harmony import ObjetHarmony


class ConnectedDevice:
    """Représente un device Modbus/BACnet/LoRa connecté à un Harmony."""

    def __init__(
        self, harmony: Harmony, nom: str, type_connexion: str, numero: str
    ) -> None:
        self.harmony: Harmony = harmony
        self.nom: str = nom
        self.type_connexion: str = type_connexion
        self.numero: str = numero


class DeviceModbus(ConnectedDevice):
    """Représente un device Modbus connecté à un Harmony."""

    def __init__(
        self,
        harmony: Harmony,
        dict_device: dict[Any],
        mapping_eficia: bool,
        nom: str = None,
        numero: str = None,
    ) -> None:
        super().__init__(harmony, nom, "Modbus", numero)
        self.slave_name: str = None
        self.slave_type: str = None
        self.protocol_or_ip: str = None
        self.mb_slave_addr: int = None
        self.id_old_modbus: int = None
        self.mapping_eficia: bool = mapping_eficia
        cles_device = [
            "protocol_or_ip",
            "mb_slave_addr",
            "slave_type",
            "slave_name",
            "baudrate",
            "parity",
            "stopbits",
            "databits",
            "duplex",
            "id_old_modbus",
        ]
        for cle in cles_device:
            setattr(self, cle, dict_device.get(cle))
        self.mapping = []
        if self.slave_name is not None and self.slave_type is not None:
            matches = re.search(r"^(.+)_(\d+)$", self.slave_name)
            if matches:
                self.emplacement, self.numero = matches.groups()
                self.nom = f"{self.slave_type}_{self.emplacement}"
            else:
                self.emplacement = None
                self.numero = None
                self.nom = f"{self.slave_type}_{self.slave_name}"
        if self.mapping_eficia:
            for ligne in self.harmony.raw_mapping_modbus:
                if (
                    ligne["protocol_or_ip"] == self.protocol_or_ip
                    and ligne["mb_slave_addr"] == self.mb_slave_addr
                ):
                    self.mapping.append(LigneMappingModbus(self, ligne))
        else:
            # Cas où le mapping est "ancien style" (dans la table "mapping_modbus")
            req = self.harmony.requete_http(
                path="/scada-main/general/plugin",
                methode="POST",
                params={"plugin": "modbus", "request": "mapping-list"},
                data={"id": self.id_old_modbus},
            )
            raw_mapping = req.json()["data"]
            for ligne in raw_mapping:
                if "bus_address" not in ligne or ligne["bus_address"] == "":
                    continue
                dic = {
                    "protocol_or_ip": self.protocol_or_ip,
                    "mb_slave_addr": self.mb_slave_addr,
                    "modbus_type": ligne["type"],
                    "mb_reg_addr": ligne["address"],
                    "modbus_datatype": ligne.get("datatype", None),
                    "value_multiplier": ligne.get("multiplier", None),
                    "value_bitmask": ligne.get("bitmask", None),
                    "read_length": ligne.get("read_count", None),
                    "read_swap": ligne.get("read_swap", None),
                    "read_knx_addr": int_to_knx_address(ligne["bus_address"]),
                }
                if "writable" in ligne and ligne["writable"] > 0:
                    dic["write_mode"] = "harmony"
                    dic["write_knx_addr"] = dic["read_knx_addr"]
                self.mapping.append(LigneMappingModbus(self, dic))

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return f"{self.type_connexion} - {self.numero} - {self.nom}"


class LigneMappingModbus:
    """Représente une ligne du mapping Modbus d'un Harmony."""

    def __init__(self, device_modbus: DeviceModbus, dict_cles: dict[Any]) -> None:
        cles_lignes_mapping = [
            "protocol_or_ip",
            "mb_slave_addr",
            "modbus_type",
            "mb_reg_addr",
            "read_knx_addr",
            "write_knx_addr",
            "value_multiplier",
            "value_bitmask",
            "read_length",
            "read_swap",
            "modbus_datatype",
            "read_freq",
            "delta_tolerance_read",
            "write_mode",
        ]
        self.device: DeviceModbus = device_modbus
        self.read_knx_addr: str = None
        self.write_knx_addr: str = None
        self.write_mode: str = None
        self.protocol_or_ip: str = None
        self.mb_slave_addr: int = None
        self.read_object: ObjetHarmony = None
        self.write_object: ObjetHarmony = None
        for cle in cles_lignes_mapping:
            setattr(self, cle, dict_cles.get(cle))
        if self.read_knx_addr is not None:
            self.read_object = find_obj_by_attr_value(
                self.device.harmony.objects, "adresse", self.read_knx_addr
            )
            if self.read_object is not None:
                self.read_object.device_modbus = self.device
        if self.write_knx_addr is not None:
            self.write_object = find_obj_by_attr_value(
                self.device.harmony.objects, "adresse", self.write_knx_addr
            )
            if self.write_object is not None:
                self.write_object.device = self.device
        if (
            self.write_mode == "statistiques_lecture"
            and self.device is not None
            and self.device.nom is None
            and self.read_object is not None
            and self.read_object.name is not None
        ):
            matches = re.search(
                r"^(.+)_(.+)\s\-\sStatistiques Modbus$", self.read_object.name
            )
            if matches:
                self.device.nom, self.device.numero = matches.groups()


class DeviceBacnet(ConnectedDevice):
    """Représente un device BACnet connecté à un Harmony."""

    def __init__(self, harmony: Harmony, nom: str, numero: str = None) -> None:
        super().__init__(harmony, nom, "BACnet", numero)

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return f"{self.type_connexion} - {self.nom}"


class DeviceLora(ConnectedDevice):
    """Représente un device LoRa connecté à un Harmony."""

    def __init__(
        self, harmony: Harmony, nom: str, deveui: str, numero: str = None
    ) -> None:
        super().__init__(harmony, nom, "LoRa", numero)
        self.deveui: str = deveui

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return f"{self.type_connexion} - {self.deveui} - {self.nom}"
