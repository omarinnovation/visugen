"""Module eficia_utils.harmony.alerte_harmony
Contient la classe AlerteHarmony, représentant une ligne du journal d'alertes.
"""
from __future__ import annotations

import datetime
from typing import Any
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .harmony import Harmony


class AlerteHarmony:
    """Représente une ligne du journal d'alertes."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles = ["id", "scriptname", "alert", "alerttime"]
        self.harmony: Harmony = harmony
        self.alerttime: datetime.datetime = None
        for cle in cles:
            setattr(self, cle, dict_cles.get(cle))
        if self.alerttime is not None:
            self.alerttime = datetime.datetime.fromtimestamp(self.alerttime)
