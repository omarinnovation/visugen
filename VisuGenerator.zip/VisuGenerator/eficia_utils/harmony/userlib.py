"""Package harmony
Module harmony.userlib
Contient les classes permettant de gérer les bibliothèques utilisateur.
"""
from __future__ import annotations

import json
import re
import urllib.parse
from typing import Any
from typing import TYPE_CHECKING

from ..utils import find_obj_by_attr_value

if TYPE_CHECKING:
    from .harmony import Harmony


class UserLib:
    """Classe représentant une bibliothèque utilisateur."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles_userlib = ["script", "id", "source", "load", "name", "description"]
        self.name = ""
        self.id = None
        self.script = None
        self.harmony = harmony
        for cle in cles_userlib:
            setattr(self, cle, dict_cles.get(cle))

    def __str__(self) -> str:
        """
        représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return self.name

    def check_params_creation(self) -> None:
        """
        Vérification des paramètres de la librairie avant création.

        Avant de créer une nouvelle librairie sur Harmony, vérification que les
        paramètres de la librairie sont valides, et que l'Harmony ne possède
        pas déjà une librairie portant ce nom.

        Raises
        ------
        ValueError
            Erreur si les paramètres de la librairie sont invalides ou
            si l'Harmony a déjà une librairie portant ce nom.

        Returns
        -------
        None.

        """
        assert self.name, "Impossible de créer une librairie sans nom"
        assert not self.harmony.get_library(
            self.name
        ), "Une librairie portant ce nom existe déjà"

    def create_empty(self) -> None:
        """
        Si la librairie n'existe pas encore sur Harmony, la crée vide.

        Raises
        ------
        ValueError
            Erreur si la création échoue.

        Returns
        -------
        None.

        """
        self.check_params_creation()
        included_keys = ("name", "description", "id", "type", "source")
        script_params = self.__dict__
        script_params["id"] = ""
        script_params["type"] = "user"
        script_params = {
            k: script_params[k]
            for k in included_keys
            if k in script_params and script_params[k] is not None
        }
        if script_params.get("source") is True:
            script_params["source"] = "on"
        elif script_params.get("source") is False:
            script_params.pop("source")
        if "description" not in script_params:
            script_params["description"] = ""
        encoded_data = "data=" + urllib.parse.quote(json.dumps(script_params))
        self.harmony.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        new_library = find_obj_by_attr_value(
            self.harmony.get_all_libraries(), "name", self.name
        )
        assert new_library, "La création de la librairie semble avoir échoué"
        self.id = new_library.id
        self.harmony.libraries.append(self)

    def edit(self, new_text: str) -> None:
        """
        Change le texte de la librairie sur l'Harmony.

        Parameters
        ----------
        new_text : str
            Nouveau texte du script.

        Raises
        ------
        ValueError
            Les éventuelles erreurs à l'enregistrement du script sur Harmony.

        Returns
        -------
        None.

        """
        data_prefix = {
            "id": self.id,
            "scriptonly": "true",
            "script": None,
            "scada-help-search": "",
        }
        quoted_data = urllib.parse.quote(json.dumps(data_prefix))
        quoted_text = urllib.parse.quote(new_text)
        encoded_data = f"data={quoted_data}&script={quoted_text}"
        req = self.harmony.requete_http(
            "scada-main/scripting/save", methode="POST", data=encoded_data
        )
        response = req.json()
        if not response["success"]:
            matches = re.search(r"""\[.+\]:(\d+): (.+)""", response["errors"]["script"])
            (ligne, message_erreur) = matches.groups()
            error_text = f"Erreur ligne {ligne} : {message_erreur}"
            raise ValueError(error_text)
        self.script = new_text

    def create_and_save(self) -> None:
        """
        Crée le script vierge sur l'harmony puis modifie son texte.

        Raises
        ------
        ValueError
            Erreur si le script est fourni sans texte.

        Returns
        -------
        None.

        """
        if not self.script:
            raise ValueError("Le texte du script doit être renseigné")
        self.create_empty()
        self.edit(self.script)

    def delete(self) -> None:
        """
        Supprime la librairie de l'Harmony.

        Returns
        -------
        None

        """
        data_to_send = {"id": self.id}
        encoded_data = f"data={urllib.parse.quote(json.dumps(data_to_send))}"
        self.harmony.requete_http(
            "scada-main/scripting/delete", methode="POST", data=encoded_data
        )
        # après la suppression,
        # on met à jour la liste des librairies de l'Harmony
        self.harmony.libraries = self.harmony.get_all_libraries()
