"""Module eficia_utils.harmony.evenement_scheduler
Contient la classe EvenementScheduler, représentant un événement de programme
horaire.
"""
from __future__ import annotations

from typing import Any
from typing import TYPE_CHECKING
import urllib
import json
from ..utils import find_obj_by_attr_value

if TYPE_CHECKING:
    from .harmony import Harmony
    from .scheduler_harmony import SchedulerHarmony


class EvenementScheduler:
    """Classe représentant un événement de programme horaire Harmony."""

    # TODO: faire dépendre la classe EvenementScheduler de la classe SchedulerHarmony
    # et non de la classe Harmony
    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles_events = [
            "active",
            "daysofmonth",
            "daysofweek",
            "dayweeknrs",
            "holidays",
            "id",
            "months",
            "name",
            "offset_hour",
            "offset_min",
            "scheduler",
            "start_date",
            "start_days",
            "start_hour",
            "start_min",
            "type",
            "value",
            "year",
        ]
        self.active: int = None
        self.scheduler = None
        self.harmony = harmony
        self.name = ""
        for cle in cles_events:
            setattr(self, cle, dict_cles.get(cle))
        self.prog_horaire = self.get_scheduler()

    def __str__(self) -> str:
        """
        Représentation textuelle.

        Returns
        -------
        str
            Représentation textuelle.

        """
        return self.name

    def get_scheduler(self) -> SchedulerHarmony:
        """
        Trouve le programme horaire dont l'événement courant fait partie.

        Returns
        -------
        prog_horaire : SchedulerHarmony
            Programme horaire dont l'événement fait partie.

        """
        prog_horaire = find_obj_by_attr_value(
            self.harmony.schedulers, "id", self.scheduler
        )
        if prog_horaire:
            prog_horaire.events.append(self)
        return prog_horaire

    def get_data(self) -> dict:
        keys = [
            "name",
            "type",
            "start_hour",
            "start_min",
            "offset_hour",
            "offset_min",
            "year",
            "holidays",
            "id",
            "value",
            "daysofweek",
            "dayweeknrs",
            "daysofmonth",
            "months",
            "scheduler",
        ]
        dico = {key: getattr(self, key) for key in keys}
        if self.active == 1:
            dico["active"] = "on"
        return dico

    def create(self) -> None:
        """Crée l'événement dans le programme horaire."""
        dico = self.get_data()
        encoded_data = f"data={urllib.parse.quote(json.dumps(dico))}"
        self.harmony.requete_http(
            "scada-main/schedulers/events-save",
            methode="POST",
            data=encoded_data,
        )
