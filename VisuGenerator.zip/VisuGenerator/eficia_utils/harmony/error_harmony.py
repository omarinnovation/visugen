"""Module eficia_utils.harmony.erreur_harmony
Contient la classe ErrorHarmony, représentant une ligne du journal d'erreurs.
"""
from __future__ import annotations

import datetime
from typing import Any
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .harmony import Harmony


class ErrorHarmony:
    """Représente une ligne du journal d'erreurs."""

    def __init__(self, harmony: Harmony, dict_cles: dict[Any]) -> None:
        cles = ["id", "errortime", "errortext", "scriptname"]
        self.harmony = harmony
        self.errortime = None
        for cle in cles:
            setattr(self, cle, dict_cles.get(cle))
        if self.errortime is not None:
            self.errortime = datetime.datetime.fromtimestamp(self.errortime)
