"""Package eficia_utils
Contient les packages suivants :
- ensylog : outils pour récupérer les clients et sites depuis Ensylog
- harmony : outils pour gérer la récupération des données Harmony
Contient les modules suivants :
- postgresql : outils pour interagir avec une base PostgreSQL
- utils : fonctions utilitaires
"""
