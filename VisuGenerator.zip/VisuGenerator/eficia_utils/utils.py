"""Module eficia_utils.utils
Fonctions utilitaires diverses.
"""

from __future__ import annotations

import inspect
import os
import re
import sqlite3
import time
from typing import Any

import requests
import urllib3.exceptions
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry


def requests_retry_session(
    retries: int = 3,
    backoff_factor: float = 0.3,
    status_forcelist: tuple[str] = (500, 502, 504),
    session=None,
) -> requests.Session:
    """
    Fonction pour permettre plusieurs nouveaux essais avec requests.

    Parameters
    ----------
    retries : TYPE, optional
        DESCRIPTION. The default is 3.
    backoff_factor : TYPE, optional
        DESCRIPTION. The default is 0.3.
    status_forcelist : TYPE, optional
        DESCRIPTION. The default is (500, 502, 504).
    session : TYPE, optional
        DESCRIPTION. The default is None.

    Returns
    -------
    session : TYPE
        DESCRIPTION.

    """
    session = session or requests.Session()
    retry = Retry(
        total=retries,
        read=retries,
        connect=retries,
        backoff_factor=backoff_factor,
        status_forcelist=status_forcelist,
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session


def request2(
    retries: int, *args, retries_reset_connection: int = 20, **kwargs
) -> requests.Response:
    """
    Amélioration de requests.request utilisant la fonction précédente.

    Parameters
    ----------
    *args : TYPE
        DESCRIPTION.
    **kwargs : TYPE
        DESCRIPTION.

    Returns
    -------
    response : TYPE
        DESCRIPTION.
        :param retries_reset_connection:
        :param retries:

    """
    current_try = 1
    success = False
    # en cas d'erreur 10054, se produisant régulièrement sur les requêtes
    # vers des Harmony GiFi, on réessaye jusqu'à ce que ça marche
    while current_try <= retries_reset_connection and not success:
        try:
            response = requests_retry_session(retries=retries).request(*args, **kwargs)
            success = True
            response.raise_for_status()
            response.encoding = "UTF-8"
        except (
            requests.exceptions.ConnectionError,
            requests.exceptions.ChunkedEncodingError,
        ) as err:
            handled = False
            if isinstance(err, requests.exceptions.ChunkedEncodingError):
                handled = True
            elif isinstance(err.args[0], urllib3.exceptions.ProtocolError):
                if isinstance(err.args[0].args[1], ConnectionResetError):
                    if err.args[0].args[1].errno == 10054:
                        handled = True
            if not handled:
                raise err
            current_try += 1
        except (requests.exceptions.HTTPError, requests.exceptions.RetryError) as err:
            if (
                isinstance(err, requests.exceptions.RetryError)
                and isinstance(err.args[0], urllib3.exceptions.MaxRetryError)
                and "Max retries exceeded with url: /user/passerelle_db.lp"
                in err.args[0].args[0]
            ) or (
                isinstance(err, requests.exceptions.HTTPError)
                and err.args[0].startswith("404 Client Error: Not Found")
                and "/user/passerelle_db.lp" in err.args[0]
            ):
                raise FileNotFoundError(
                    "passerelle_db.lp n'est pas présent sur Harmony"
                ) from err
            raise err
    if not success:
        raise ConnectionError(
            f"Impossible d'exécuter après {retries_reset_connection} essais"
        )
    return response


def separer_port(adresse: str) -> tuple[str, str]:
    """
    Sépare un nom de domaine et un port.

    Permet de séparer un nom de domaine éventuellement
    donné avec un port, par exemple :
    'iot.ensylog.com:15558' -> 'iot.ensylog.com', '15558'

    Parameters
    ----------
    adresse : str
        Adresse constituée d'un nom de domaine (ou une IP)
        éventuellement suivie d'un port, séparé avec ":".

    Raises
    ------
    ValueError
        Erreur si la chaîne de caractères contient ":" plus
        d'une fois.

    Returns
    -------
    host : str
        Nom de domaine *sans* le port derrière.
    port : str
        port, s'il y en a un.

    """
    adresse = clean_url(adresse)  # remove http://
    parsed = adresse.split(":")
    host = parsed[0]
    port = None
    if len(parsed) == 2:
        port = parsed[1]
    elif len(parsed) > 2:
        raise ValueError("L'IP n'est pas au format a[:b]")
    return host, port


def find_obj_by_attr_value(list_out: list[Any], field: str, search_value: Any) -> Any:
    """
    Trouve un objet dans une liste d'objets.

    On a une liste d'objets (list_out) et on veut, parmi cette liste,
    trouver le dictionnaire pour lequel un certain attribut (field)
    est égal à une certaine valeur (search_value).

    Cette fonction retourne l'objet recherché.

    Attention, si plusieurs objets dans la liste ont l'attribut "field"
    égale à la valeur "search_value", cette fonction ne retournera que le
    premier d'entre eux.

    Parameters
    ----------
    list_out : list(object)
        Liste d'objets sur laquelle on mène la recherche.
    field : str
        Attribut sur laquelle on mène la recherche.
    search_value : any
        Valeur recherchée.

    Returns
    -------
    found_object : object
        Retourne le premier objet de la liste "list_out", pour lequel
        l'attribut "field" est égal à "search_value".

    """
    found_object = next(
        (obj for obj in list_out if getattr(obj, field) == search_value), None
    )
    return found_object


def int_to_knx_address(number: int) -> str:
    """
    Convertit un nombre entier en l'adresse KNX correspondante.

    Convertit une adresse de groupe d'objet KNX donnée sous forme d'entier
    en adresse de groupe avec des slashs


    par exemple : int_to_knx_address('21385') = '10/3/137'
    Parameters
    ----------
    number : int
        entier entre 0 et 65535.

    Returns
    -------
    str
        Adresse de groupe KNX de la forme a/b/c.

    """
    binary_form = f"{number:017b}"
    groups = [
        str(int(binary_form[0:6], 2)),
        str(int(binary_form[6:9], 2)),
        str(int(binary_form[9:], 2)),
    ]
    return "/".join(groups)


def knx_address_to_int(knx_address: str) -> int:
    """
    Convertit une adresse de groupe en le nombre entier correspondant.

    Parameters
    ----------
    knx_address : str
        adresse de groupe d'objet KNX.

    Raises
    ------
    TypeError
        si l'argument fourni n'est pas un str.
    ValueError
        si le str fourni n'est pas au format A/B/C avec A,B,C trois
        nombres, B sur un seul chiffre.

    Returns
    -------
    toreturn : int
        Adresse KNX encodée en nombre entier.

    """
    if not isinstance(knx_address, str):
        raise TypeError("L'adresse de groupe doit être un string")
    parse_address = re.search(r"^(\d+)/(\d)/(\d+)$", knx_address)
    if not parse_address:
        raise ValueError("L'adresse de groupe n'est pas au format a/b/c")
    nums = [int(num) for num in parse_address.groups()]
    powers = [11, 8, 0]
    toreturn = sum(num * (2**power) for (num, power) in zip(nums, powers))
    return toreturn


def sqlite_escape(stringvalue: str) -> str:
    """
    Permet d'échapper une chaîne de caractères en SQLite.

    Parameters
    ----------
    stringvalue : str
        Chaîne de caractères à échapper.

    Returns
    -------
    res : str
        Chaîne de caractères échappée.

    """
    conn = sqlite3.connect(":memory:")
    cur = conn.cursor()
    res = cur.execute(
        "SELECT quote(:stringvalue)", {"stringvalue": stringvalue}
    ).fetchone()[0]
    conn.close()
    return res


def replace_empty_string(string: str) -> str or None:
    """
    Si une chaîne de caractères est vide, la remplace par None.

    Parameters
    ----------
    string : TYPE
        DESCRIPTION.

    Returns
    -------
    str or None
        DESCRIPTION.

    """
    if string == "":
        res = None
    else:
        res = string
    return res


def read_file_in_script_subfolder(*paths) -> str:
    """
    Lit un fichier texte dans un sous-dossier du dossier du script
    Python qui a appelé cette fonction.

    Parameters
    ----------
    *paths : str, str, ...

    Returns
    -------
    str
        Contenu du fichier.

    """
    stack = inspect.stack()
    caller_frame = stack[1]
    caller_module = inspect.getmodule(caller_frame[0])
    calling_file = os.path.realpath(caller_module.__file__)
    path = os.path.join(os.path.dirname(calling_file), *paths)
    with open(path, "r", encoding="utf-8") as f:
        texte = f.read()
    return texte


def time_method(some_method):
    def wrapper(self, *args, **kwargs):
        start_time = time.time()
        toreturn = some_method(self, *args, **kwargs)
        end_time = time.time()
        duration = end_time - start_time
        if not hasattr(self, "exec_times"):
            self.exec_times = []
        self.exec_times.append(
            {
                "method": some_method.__name__,
                "duration": duration,
                "args": args,
                "kwargs": kwargs,
            }
        )
        return toreturn

    return wrapper


def clean_url(ip) -> str:
    """
    Supprime "http(s)://" s'il est présent devant l'adresse ip,
    ainsi que le chemin de l'url s'il existe

    """
    ip = ip.replace("https://", "")
    ip = ip.replace("http://", "")
    return ip.split("/")[0]
